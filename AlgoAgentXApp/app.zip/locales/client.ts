import { createI18nClient } from 'next-international/client';

export const {
  useI18n,
  useScopedI18n,
  I18nProviderClient,
  useChangeLocale,
  useCurrentLocale,
} = createI18nClient({
  en: () => import('./en'),
  hi: () => import('./hi'),
  fr: () => import('./fr'),
  ar: () => import('./ar'),
});