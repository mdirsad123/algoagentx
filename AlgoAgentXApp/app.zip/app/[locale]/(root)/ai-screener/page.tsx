"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import DatePicker from "@/components/ui/date-picker";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableBody, TableHead, TableCell, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw, ExternalLink, Calendar as CalendarIcon, Play, PlayCircle } from "lucide-react";
import { format } from "date-fns";
import { useTranslation } from "@/hooks/use-translations";
import { toast } from "sonner";
import { StatusBar } from "@/components/ai-screener/StatusBar";

// Import types and API
import { NewsItem, AnnouncementItem } from "@/types/ai-screener";
import { aiScreenerApi } from "@/lib/api/ai-screener";
import { PageHeader } from "@/components/ui/page-header";
import { StandardCard, StandardCardHeader, StandardCardTitle, StandardCardDescription, StandardCardContent } from "@/components/ui/standard-card";
import { CardSkeleton, TableSkeleton } from "@/components/ui/loading-skeleton";

interface NewsTableProps {
  title: string;
  sentimentType: "positive" | "negative";
  loading: boolean;
  data: NewsItem[];
  onRefresh: () => void;
}

interface AnnouncementsTableProps {
  loading: boolean;
  data: AnnouncementItem[];
  onRefresh: () => void;
}

interface SearchTableProps {
  loading: boolean;
  data: NewsItem[];
  query: string;
  onSearch: (query: string) => void;
  onRefresh: () => void;
}

export default function AiScreenerPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("news");
  const [date, setDate] = useState<Date>(new Date());
  const [exchangeFilter, setExchangeFilter] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState<string>("");

  // Helper function to navigate to backtest page with symbol
  const handleBacktest = (symbol: string) => {
    router.push(`/backtest?symbol=${encodeURIComponent(symbol)}`);
  };
  
  // News data
  const [positiveNews, setPositiveNews] = useState<NewsItem[]>([]);
  const [negativeNews, setNegativeNews] = useState<NewsItem[]>([]);
  const [newsLoading, setNewsLoading] = useState(false);
  
  // Announcements data
  const [announcements, setAnnouncements] = useState<AnnouncementItem[]>([]);
  const [announcementsLoading, setAnnouncementsLoading] = useState(false);
  
  // Search data
  const [searchResults, setSearchResults] = useState<NewsItem[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  const { t } = useTranslation();

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Fetch news data
  const fetchNewsData = async () => {
    setNewsLoading(true);
    try {
      const dateStr = format(date, "yyyy-MM-dd");
      
      const [positiveRes, negativeRes] = await Promise.all([
        aiScreenerApi.getTopPositiveNews(dateStr, 10),
        aiScreenerApi.getTopNegativeNews(dateStr, 10)
      ]);
      
      setPositiveNews(positiveRes.items);
      setNegativeNews(negativeRes.items);
    } catch (error) {
      console.error("Error fetching news:", error);
      toast.error("Failed to fetch news data");
    } finally {
      setNewsLoading(false);
    }
  };

  // Fetch announcements data
  const fetchAnnouncementsData = async () => {
    setAnnouncementsLoading(true);
    try {
      const dateStr = format(date, "yyyy-MM-dd");
      const res = await aiScreenerApi.getLatestAnnouncements(dateStr, 50);
      setAnnouncements(res.items);
    } catch (error) {
      console.error("Error fetching announcements:", error);
      toast.error("Failed to fetch announcements");
    } finally {
      setAnnouncementsLoading(false);
    }
  };

  // Fetch search data
  const fetchSearchData = async (query: string) => {
    if (!query.trim()) return;
    
    setSearchLoading(true);
    try {
      const dateStr = format(date, "yyyy-MM-dd");
      const res = await aiScreenerApi.searchNews(query, dateStr);
      setSearchResults(res.items);
    } catch (error) {
      console.error("Error fetching search results:", error);
      toast.error("Failed to fetch search results");
    } finally {
      setSearchLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchNewsData();
    fetchAnnouncementsData();
  }, [date]);

  // Search data fetch
  useEffect(() => {
    fetchSearchData(debouncedSearchQuery);
  }, [debouncedSearchQuery, date]);

  // Filter announcements by exchange
  const filteredAnnouncements = announcements.filter(item => {
    if (exchangeFilter === "All") return true;
    return item.exchange === exchangeFilter;
  });

  const NewsTable = ({ title, sentimentType, loading, data, onRefresh }: NewsTableProps) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">{title}</CardTitle>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : data.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No {sentimentType} news found for {format(date, "MMM dd, yyyy")}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Sentiment</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">
                    <Badge variant="outline" className="bg-gray-50 text-gray-900 border-gray-200">
                      {item.symbol}
                    </Badge>
                  </TableCell>
                  <TableCell>{format(new Date(item.date), "MMM dd, yyyy")}</TableCell>
                  <TableCell className="max-w-md">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 hover:underline flex items-center"
                    >
                      <span className="truncate block max-w-xs">{item.title}</span>
                      <ExternalLink className="h-4 w-4 ml-1 flex-shrink-0" />
                    </a>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={sentimentType === "positive" ? "default" : "secondary"}
                      className={sentimentType === "positive" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                    >
                      {sentimentType.toUpperCase()}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className={sentimentType === "positive" ? "text-green-600" : "text-red-600"}>
                      {item.sentiment_score.toFixed(2)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        View
                      </a>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleBacktest(item.symbol)}
                        className="flex items-center gap-2 text-gray-700 hover:bg-gray-50 hover:border-gray-300"
                      >
                        <PlayCircle className="w-4 h-4" />
                        Backtest
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const AnnouncementsTable = ({ loading, data, onRefresh }: AnnouncementsTableProps) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Announcements (NSE/BSE)</CardTitle>
        <div className="flex items-center space-x-4">
          <Select value={exchangeFilter} onValueChange={setExchangeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by Exchange" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Exchanges</SelectItem>
              <SelectItem value="NSE">NSE</SelectItem>
              <SelectItem value="BSE">BSE</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : data.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No announcements found for {format(date, "MMM dd, yyyy")}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Exchange</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Link</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">
                    <Badge variant="outline" className="bg-gray-50 text-gray-900 border-gray-200">
                      {item.symbol}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={item.exchange === "NSE" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-orange-50 text-orange-700 border-orange-200"}>
                      {item.exchange}
                    </Badge>
                  </TableCell>
                  <TableCell>{format(new Date(item.date), "MMM dd, yyyy")}</TableCell>
                  <TableCell className="max-w-md">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 hover:underline flex items-center"
                    >
                      <span className="truncate block max-w-xs">{item.title}</span>
                      <ExternalLink className="h-4 w-4 ml-1 flex-shrink-0" />
                    </a>
                  </TableCell>
                  <TableCell>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 text-sm"
                    >
                      View
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const SearchTable = ({ loading, data, query, onSearch, onRefresh }: SearchTableProps) => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Search Results</CardTitle>
        <div className="flex flex-col sm:flex-row gap-4 mt-4">
          <div className="flex-1">
            <Input
              placeholder="Search by symbol or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onSearch(searchQuery)}
              disabled={loading || !searchQuery.trim()}
            >
              Search
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : data.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            {query ? `No results found for "${query}"` : "Enter a search query to get started"}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Summary</TableHead>
                <TableHead>Sentiment</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">
                    <Badge variant="outline" className="bg-gray-50 text-gray-900 border-gray-200">
                      {item.symbol}
                    </Badge>
                  </TableCell>
                  <TableCell>{format(new Date(item.date), "MMM dd, yyyy")}</TableCell>
                  <TableCell className="max-w-md">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 hover:underline flex items-center"
                    >
                      <span className="truncate block max-w-xs">{item.title}</span>
                      <ExternalLink className="h-4 w-4 ml-1 flex-shrink-0" />
                    </a>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">{item.summary}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={item.sentiment_label === "positive" ? "default" : "secondary"}
                      className={item.sentiment_label === "positive" ? "bg-green-100 text-green-800" : item.sentiment_label === "negative" ? "bg-red-100 text-red-800" : "bg-gray-100 text-gray-800"}
                    >
                      {item.sentiment_label.toUpperCase()}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className={item.sentiment_label === "positive" ? "text-green-600" : item.sentiment_label === "negative" ? "text-red-600" : "text-gray-600"}>
                      {item.sentiment_score.toFixed(2)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        View
                      </a>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleBacktest(item.symbol)}
                        className="flex items-center gap-2 text-gray-700 hover:bg-gray-50 hover:border-gray-300"
                      >
                        <PlayCircle className="w-4 h-4" />
                        Backtest
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <PageHeader 
        title="AI Screener"
        subtitle="Analyze market news, announcements, and search for specific information"
      />

      {/* Status Bar */}
      <StatusBar />

      {/* Date Selector */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CalendarIcon className="h-5 w-5 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Date:</span>
              <span className="text-sm text-gray-600">{format(date, "MMM dd, yyyy")}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDate(new Date())}
              >
                Today
              </Button>
              <DatePicker
                selected={date}
                onSelect={(newDate: Date | undefined) => newDate && setDate(newDate)}
                placeholder="Select date"
              />
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="news">Latest News Analysis</TabsTrigger>
          <TabsTrigger value="announcements">Announcements (NSE/BSE)</TabsTrigger>
          <TabsTrigger value="search">Search</TabsTrigger>
        </TabsList>

        <TabsContent value="news">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <NewsTable
              title="Top 10 Strong Positive"
              sentimentType="positive"
              loading={newsLoading}
              data={positiveNews}
              onRefresh={fetchNewsData}
            />
            <NewsTable
              title="Top 10 Strong Negative"
              sentimentType="negative"
              loading={newsLoading}
              data={negativeNews}
              onRefresh={fetchNewsData}
            />
          </div>
        </TabsContent>

        <TabsContent value="announcements">
          <AnnouncementsTable
            loading={announcementsLoading}
            data={filteredAnnouncements}
            onRefresh={fetchAnnouncementsData}
          />
        </TabsContent>

        <TabsContent value="search">
          <SearchTable
            loading={searchLoading}
            data={searchResults}
            query={searchQuery}
            onSearch={fetchSearchData}
            onRefresh={() => fetchSearchData(debouncedSearchQuery)}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}