"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Cookies from "js-cookie";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyProfileRedirectPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const handleRedirect = () => {
      const loggedinuserid = Cookies.get("loggedinuserid");
      
      if (!loggedinuserid) {
        // User is not logged in, redirect to login
        router.push("/auth/login");
      } else {
        // User is logged in, redirect to their profile page
        router.push(`/myprofile/${loggedinuserid}`);
      }
    };

    // Handle redirect after a brief delay to show loading state
    const timer = setTimeout(() => {
      setIsLoading(false);
      handleRedirect();
    }, 500);

    return () => clearTimeout(timer);
  }, [router]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-md border-gray-200 dark:border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">
              Redirecting...
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
            <div className="space-y-3">
              <Skeleton className="h-4 w-3/4 mx-auto bg-gray-200 dark:bg-gray-700" />
              <Skeleton className="h-4 w-1/2 mx-auto bg-gray-200 dark:bg-gray-700" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}