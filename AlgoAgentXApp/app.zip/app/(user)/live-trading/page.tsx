"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Eye, Pause, Play, Plus, ShieldAlert, ShieldCheck, Square, Trash2, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/GlassCard";
import { PageHeader } from "@/components/ui/PageHeader";
import { PageShell } from "@/components/ui/PageShell";
import { EmptyState } from "@/components/shared/EmptyState";
import { useToast } from "@/components/shared/toast";
import { liveTradingApi } from "@/lib/api/live-trading";
import type { LiveDeploymentSummary, StrategyCatalogItem, StrategyDeployment } from "@/types/live-trading";
import { formatDateTimeIST } from "@/lib/timezone";

const formatMoney = (value: unknown, currency = "USD") => {
  const amount = Number(value || 0);
  const code = String(currency || "USD").toUpperCase();
  if (["USD", "INR", "EUR", "GBP"].includes(code)) {
    return new Intl.NumberFormat(code === "INR" ? "en-IN" : "en-US", {
      style: "currency",
      currency: code,
      maximumFractionDigits: 2,
    }).format(amount);
  }
  return `${amount.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${code}`;
};

const date = (value?: string | null) => formatDateTimeIST(value);
const canDeleteDeployment = (status?: string | null) => ["DRAFT", "STOPPED", "ERROR"].includes(String(status || "").toUpperCase());

type LiveAccessStatus = {
  allowed: boolean;
  requires_subscription: boolean;
  code?: string | null;
  message?: string;
  recommended_coupon?: string | null;
  subscription?: Record<string, unknown> | null;
};

const extractGateDetail = (error: any): LiveAccessStatus | null => {
  const detail = error?.response?.data?.detail;
  if (detail && typeof detail === "object" && detail.code === "SUBSCRIPTION_REQUIRED") {
    return {
      allowed: false,
      requires_subscription: true,
      code: detail.code,
      message: detail.message || "Active subscription required to deploy live strategies.",
      recommended_coupon: detail.recommended_coupon || null,
    };
  }
  return null;
};

const errorMessage = (error: any, fallback: string) => {
  const detail = error?.response?.data?.detail;
  if (typeof detail === "string") return detail;
  if (detail?.message) return detail.message;
  return error?.message || fallback;
};

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    RUNNING: "border-lime-400/30 bg-lime-400/20 text-lime-100",
    PAUSED: "border-yellow-400/30 bg-yellow-400/20 text-yellow-100",
    STOPPED: "border-slate-400/30 bg-slate-400/20 text-slate-100",
    ERROR: "border-red-400/30 bg-red-400/20 text-red-100",
    DRAFT: "border-purple-300/30 bg-purple-400/20 text-purple-100",
  };
  return <Badge className={map[status] || map.DRAFT}>{status}</Badge>;
}

export default function LiveTradingPage() {
  const { showToast } = useToast();
  const router = useRouter();
  const [deployments, setDeployments] = useState<StrategyDeployment[]>([]);
  const [summaries, setSummaries] = useState<Record<string, LiveDeploymentSummary>>({});
  const [strategies, setStrategies] = useState<StrategyCatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<StrategyDeployment | null>(null);
  const [accessStatus, setAccessStatus] = useState<LiveAccessStatus | null>(null);
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [deploymentFilter, setDeploymentFilter] = useState<"ALL" | "STANDARD" | "FUNDED">("ALL");

  const strategyName = (id: string) => strategies.find((s) => s.id === id)?.name || summaries[id]?.deployment?.strategy_name || id;

  const load = async () => {
    try {
      setLoading(true);
      const [deploymentRows, strategyRows, access] = await Promise.all([
        liveTradingApi.listDeployments(),
        liveTradingApi.listStrategies(),
        liveTradingApi.getLiveAccessStatus().catch(() => null),
      ]);
      if (access) setAccessStatus(access);
      setDeployments(deploymentRows);
      setStrategies(strategyRows);
      const pairs = await Promise.all(
        deploymentRows.map(async (d) => {
          try {
            return [d.id, await liveTradingApi.getDeploymentSummary(d.id, { refreshBroker: false })] as const;
          } catch {
            return [d.id, null] as const;
          }
        }),
      );
      setSummaries(Object.fromEntries(pairs.filter(([, value]) => value)) as Record<string, LiveDeploymentSummary>);
    } catch (error: any) {
      showToast(errorMessage(error, "Failed to load live trading dashboard"), "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const runAction = async (id: string, action: "start" | "pause" | "stop") => {
    try {
      setBusyId(id);
      if (action === "start") await liveTradingApi.startDeployment(id);
      if (action === "pause") await liveTradingApi.pauseDeployment(id);
      if (action === "stop") await liveTradingApi.stopDeployment(id);
      showToast(`Deployment ${action} action completed`, "success");
      await load();
    } catch (error: any) {
      const gate = extractGateDetail(error);
      if (gate) {
        setAccessStatus(gate);
        setShowSubscribeModal(true);
      } else {
        showToast(errorMessage(error, `Failed to ${action} deployment`), "error");
      }
    } finally {
      setBusyId(null);
    }
  };

  const deleteDeployment = async () => {
    if (!deleteTarget) return;
    try {
      setBusyId(deleteTarget.id);
      await liveTradingApi.deleteDeployment(deleteTarget.id);
      showToast("Deployment deleted", "success");
      setDeleteTarget(null);
      await load();
    } catch (error: any) {
      showToast(errorMessage(error, "Failed to delete deployment"), "error");
    } finally {
      setBusyId(null);
    }
  };

  const filteredDeployments = useMemo(() => {
    if (deploymentFilter === "ALL") return deployments;
    return deployments.filter((deployment) => String(deployment.account_policy_type || "STANDARD").toUpperCase() === deploymentFilter);
  }, [deploymentFilter, deployments]);

  const filterCounts = useMemo(() => ({
    ALL: deployments.length,
    STANDARD: deployments.filter((deployment) => String(deployment.account_policy_type || "STANDARD").toUpperCase() !== "FUNDED").length,
    FUNDED: deployments.filter((deployment) => String(deployment.account_policy_type || "STANDARD").toUpperCase() === "FUNDED").length,
  }), [deployments]);

  const summary = useMemo(() => {
    const rows = Object.values(summaries);
    return {
      running: deployments.filter((d) => d.status === "RUNNING").length,
      openPositions: rows.reduce((sum, s) => sum + Number(s.metrics?.open_positions || 0), 0),
      todayPnl: rows.reduce((sum, s) => sum + Number(s.metrics?.today_pnl || 0), 0),
      currency: rows.find((s) => s.metrics?.currency)?.metrics?.currency || "USD",
      todaySignals: rows.reduce((sum, s) => sum + Number(s.metrics?.signals_today || 0), 0),
      todayOrders: rows.reduce((sum, s) => sum + Number(s.metrics?.orders_today || 0), 0),
    };
  }, [deployments, summaries]);

  return (
    <PageShell>
      <PageHeader
        title="Live Trading"
        subtitle="Monitor DEMO and approved LIVE broker deployments."
        actions={accessStatus?.allowed === false ? (
          <Button onClick={() => setShowSubscribeModal(true)} className="gap-2 border-0 bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white hover:from-fuchsia-400 hover:to-blue-400"><Plus className="h-4 w-4" />New Deployment</Button>
        ) : (
          <Link href="/live-trading/new"><Button className="gap-2 border-0 bg-gradient-to-r from-lime-400 to-emerald-500 text-slate-950 hover:from-lime-300 hover:to-emerald-400"><Plus className="h-4 w-4" />New Deployment</Button></Link>
        )}
      />

      <GlassCard className={`mb-6 rounded-3xl border p-5 ${accessStatus?.allowed === false ? "border-amber-300/25 bg-amber-400/10" : "border-lime-300/20 bg-lime-400/10"}`} hoverEffect={false}>
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-3">
            {accessStatus?.allowed === false ? <ShieldAlert className="mt-1 h-5 w-5 text-amber-200" /> : <ShieldCheck className="mt-1 h-5 w-5 text-lime-200" />}
            <div>
              <h3 className="font-semibold text-white">{accessStatus?.allowed === false ? "Subscription required for deployment" : "Live trading access enabled"}</h3>
              <p className="mt-1 text-sm text-purple-100/75">
                {accessStatus?.allowed === false
                  ? `Live trading deployment is available for active subscribers.${accessStatus.recommended_coupon ? ` Use coupon ${accessStatus.recommended_coupon} for discount.` : ""}`
                  : "Your live trading controls are available. Viewing, pausing, stopping, logs, and broker status remain safe at all times."}
              </p>
            </div>
          </div>
          {accessStatus?.allowed === false && <Button onClick={() => router.push("/pricing")} className="rounded-xl bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white">View Plans</Button>}
        </div>
      </GlassCard>

      <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-5">
        <GlassCard className="p-5"><p className="text-sm text-purple-200">Running deployments</p><p className="mt-2 text-3xl font-bold text-lime-300">{summary.running}</p></GlassCard>
        <GlassCard className="p-5"><p className="text-sm text-purple-200">Open positions</p><p className="mt-2 text-3xl font-bold text-white">{summary.openPositions}</p></GlassCard>
        <GlassCard className="p-5"><p className="text-sm text-purple-200">Today PnL</p><p className="mt-2 text-3xl font-bold text-white">{formatMoney(summary.todayPnl, summary.currency)}</p></GlassCard>
        <GlassCard className="p-5"><p className="text-sm text-purple-200">Signals today</p><p className="mt-2 text-3xl font-bold text-white">{summary.todaySignals}</p></GlassCard>
        <GlassCard className="p-5"><p className="text-sm text-purple-200">Orders today</p><p className="mt-2 text-3xl font-bold text-white">{summary.todayOrders}</p></GlassCard>
      </div>

      {loading ? <GlassCard className="p-6 text-purple-100">Loading live deployments...</GlassCard> : deployments.length === 0 ? <EmptyState title="No deployments yet" description="Create your first DEMO or approved LIVE broker deployment from a published strategy." action={accessStatus?.allowed === false ? <Button onClick={() => setShowSubscribeModal(true)} className="gap-2"><Zap className="h-4 w-4" />Create Deployment</Button> : <Link href="/live-trading/new"><Button className="gap-2"><Zap className="h-4 w-4" />Create Deployment</Button></Link>} /> : (
        <div className="space-y-4">
          <div className="inline-flex flex-wrap items-center gap-1 rounded-2xl border border-white/10 bg-white/5 p-1.5" aria-label="Deployment account policy filters">
            {([
              ["ALL", "All Deployments"],
              ["STANDARD", "Standard"],
              ["FUNDED", "Funded"],
            ] as const).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setDeploymentFilter(value)}
                className={`rounded-xl px-4 py-2 text-sm font-medium transition ${deploymentFilter === value ? "bg-lime-400 text-slate-950 shadow-lg shadow-lime-950/20" : "text-purple-100 hover:bg-white/10 hover:text-white"}`}
              >
                {label} <span className="ml-1 opacity-70">({filterCounts[value]})</span>
              </button>
            ))}
          </div>
          {filteredDeployments.length === 0 ? (
            <GlassCard className="p-6 text-sm text-purple-100" hoverEffect={false}>No {deploymentFilter === "FUNDED" ? "funded" : "standard"} deployments match this filter.</GlassCard>
          ) : (
        <GlassCard className="overflow-hidden" hoverEffect={false}>
          <div className="responsive-table-wrapper overflow-x-auto">
            <table className="w-full min-w-[1680px] text-left text-sm">
              <thead className="border-b border-white/10 bg-white/5 text-purple-100"><tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Strategy</th><th className="px-4 py-3">Instrument</th><th className="px-4 py-3">Timeframe</th><th className="px-4 py-3">Execution / Policy</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Broker</th><th className="px-4 py-3">Today PnL</th><th className="px-4 py-3">Auto Runner</th><th className="px-4 py-3">Last Signal</th><th className="w-[420px] min-w-[420px] px-4 py-3 text-right">Actions</th></tr></thead>
              <tbody className="divide-y divide-white/10">{filteredDeployments.map((deployment) => {
                const sm = summaries[deployment.id];
                const rowCurrency = sm?.metrics?.currency || sm?.broker?.currency || "USD";
                const deleteAllowed = canDeleteDeployment(deployment.status);
                return <tr key={deployment.id} className="text-purple-50 hover:bg-white/5">
                  <td className="px-4 py-4 font-semibold text-white">{deployment.name}</td>
                  <td className="px-4 py-4">{strategyName(deployment.strategy_id)}</td>
                  <td className="px-4 py-4">{deployment.instrument}</td>
                  <td className="px-4 py-4">{deployment.timeframe}</td>
                  <td className="px-4 py-4"><div className="flex flex-wrap items-center gap-1.5"><Badge className={deployment.mode === "PAPER" ? "border-amber-400/30 bg-amber-400/20 text-amber-100" : "border-cyan-400/30 bg-cyan-400/20 text-cyan-100"}>{deployment.mode === "PAPER" ? "PAPER Deprecated" : deployment.mode}</Badge>{deployment.account_policy_type === "FUNDED" ? <Badge className="border-lime-400/30 bg-lime-400/20 text-lime-100">FUNDED</Badge> : <Badge className="border-slate-400/30 bg-slate-400/15 text-slate-100">STANDARD</Badge>}</div>{deployment.account_policy_type === "FUNDED" && <div className="mt-1 text-[11px] text-lime-200">{sm?.funded?.guard?.status || "Guard pending"}{deployment.funded_phase_number ? ` · Phase ${deployment.funded_phase_number}` : ""}</div>}</td>
                  <td className="px-4 py-4"><StatusBadge status={deployment.status} /></td>
                  <td className="px-4 py-4">{sm?.broker ? `${sm.broker.account_label || "Broker"} (${sm.broker.status || "—"})` : "—"}</td>
                  <td className="px-4 py-4">{formatMoney(sm?.metrics?.today_pnl, rowCurrency)}</td>
                  <td className="px-4 py-4"><Badge title={`Next scheduled run: ${date(deployment.next_run_at)}`} className={deployment.auto_runner_enabled ? "border-lime-400/30 bg-lime-400/20 text-lime-100" : "border-slate-400/30 bg-slate-400/20 text-slate-100"}>{deployment.auto_runner_enabled ? "ON" : "OFF"}</Badge><div className="mt-1 text-xs text-purple-300">{date(deployment.last_processed_candle_time)}</div></td>
                  <td className="px-4 py-4">{date(deployment.last_signal_at)}</td>
                  <td className="w-[420px] min-w-[420px] px-4 py-4"><div className="flex flex-nowrap items-center justify-end gap-2 whitespace-nowrap"><Button size="sm" disabled={busyId === deployment.id || deployment.mode === "PAPER"} onClick={() => runAction(deployment.id, "start")} className="h-8 gap-1 px-3 bg-lime-500 text-slate-950 hover:bg-lime-400"><Play className="h-3.5 w-3.5" />Start</Button><Button size="sm" disabled={busyId === deployment.id} onClick={() => runAction(deployment.id, "pause")} className="h-8 gap-1 px-3 bg-yellow-500 text-slate-950 hover:bg-yellow-400"><Pause className="h-3.5 w-3.5" />Pause</Button><Button size="sm" disabled={busyId === deployment.id} onClick={() => runAction(deployment.id, "stop")} variant="outline" className="h-8 gap-1 px-3 border-red-400/30 bg-red-500/10 text-red-100 hover:bg-red-500/20"><Square className="h-3.5 w-3.5" />Stop</Button><Link href={`/live-trading/${deployment.id}`}><Button size="sm" variant="outline" className="h-8 gap-1 px-3 border-white/10 bg-white/5 text-white hover:bg-white/10"><Eye className="h-3.5 w-3.5" />View</Button></Link>{deleteAllowed && <Button size="sm" disabled={busyId === deployment.id} onClick={() => setDeleteTarget(deployment)} variant="outline" className="h-8 gap-1 px-3 border-red-400/30 bg-red-500/10 text-red-100 hover:bg-red-500/20"><Trash2 className="h-3.5 w-3.5" />Delete</Button>}</div></td>
                </tr>;
              })}</tbody>
            </table>
          </div>
        </GlassCard>
          )}
        </div>
      )}

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl border border-red-400/20 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900 p-6 shadow-2xl shadow-red-950/30">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-red-500/20 p-3 text-red-100"><AlertTriangle className="h-6 w-6" /></div>
              <div>
                <h2 className="text-2xl font-bold text-white">Delete live deployment?</h2>
                <p className="mt-2 text-sm leading-6 text-purple-100/80">This will remove this deployment from your workspace. This action cannot be undone.</p>
              </div>
            </div>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
              <Button variant="outline" onClick={() => setDeleteTarget(null)} className="border-white/10 bg-white/5 text-white hover:bg-white/10">Cancel</Button>
              <Button disabled={busyId === deleteTarget.id} onClick={deleteDeployment} className="bg-red-500 text-white hover:bg-red-400">Delete Deployment</Button>
            </div>
          </div>
        </div>
      )}

      {showSubscribeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900 p-6 shadow-2xl shadow-fuchsia-950/40">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-fuchsia-500/20 p-3 text-fuchsia-100"><ShieldAlert className="h-6 w-6" /></div>
              <div>
                <h2 className="text-2xl font-bold text-white">Subscription required</h2>
                <p className="mt-2 text-sm leading-6 text-purple-100/80">
                  Live trading deployment is available for active subscribers.
                  {accessStatus?.recommended_coupon ? ` Subscribe now and use coupon ${accessStatus.recommended_coupon} for discount.` : " Subscribe now to unlock deployment and start controls."}
                </p>
              </div>
            </div>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
              <Button variant="outline" onClick={() => setShowSubscribeModal(false)} className="border-white/10 bg-white/5 text-white hover:bg-white/10">Cancel</Button>
              {accessStatus?.recommended_coupon && (
                <Button onClick={() => router.push(`/billing/checkout?type=subscription&plan=PRO&period=MONTHLY&coupon=${encodeURIComponent(accessStatus.recommended_coupon || "")}`)} className="bg-gradient-to-r from-lime-400 to-emerald-500 text-slate-950">Apply Coupon</Button>
              )}
              <Button onClick={() => router.push("/pricing")} className="bg-gradient-to-r from-fuchsia-500 to-blue-500 text-white">View Plans</Button>
            </div>
          </div>
        </div>
      )}
    </PageShell>
  );
}
