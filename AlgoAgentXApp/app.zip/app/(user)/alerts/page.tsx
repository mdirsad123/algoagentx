"use client";

import { useEffect, useMemo, useState } from "react";
import { BellRing, CheckCircle2, CircleAlert, Edit3, Loader2, Pause, Play, RefreshCw, Send, Trash2, WifiOff } from "lucide-react";
import { PageShell } from "@/components/ui/PageShell";
import { PageHeader } from "@/components/ui/PageHeader";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { alertsApi } from "@/lib/api/alerts";
import { liveTradingApi } from "@/lib/api/live-trading";
import { formatDateTimeIST } from "@/lib/timezone";
import { useToast } from "@/components/shared/toast";
import type { AlertEvent, AlertHealth, AlertPayload, AlertType, PriceAlert, TelegramChannel } from "@/types/alerts";
import type { BrokerAccount } from "@/types/live-trading";

const alertSelectTriggerClass = "mt-2 border-white/20 bg-[#241044]/95 text-white shadow-sm hover:bg-[#2d1554] focus:ring-violet-400/60";
const alertSelectContentClass = "z-[150] border-white/20 bg-[#241044] text-white shadow-2xl";
const alertSelectItemClass = "text-white focus:bg-violet-600/40 focus:text-white";

const conditions: Array<{ value: AlertType; label: string }> = [
  { value: "CROSSING_UP", label: "Crossing Up" },
  { value: "CROSSING_DOWN", label: "Crossing Down" },
  { value: "ENTERING_ZONE", label: "Entering Zone" },
  { value: "LEAVING_ZONE", label: "Leaving Zone" },
];

const numberText = (value: unknown, digits = 2) => {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("en-US", { maximumFractionDigits: digits }) : "—";
};

const conditionLabel = (value: string) => conditions.find((x) => x.value === value)?.label || value.replaceAll("_", " ");

const eventTargetLabel = (event: AlertEvent) => {
  const snapshot = (event.payload?.alert_snapshot || {}) as Record<string, unknown>;
  if (event.condition_type === "ENTERING_ZONE" || event.condition_type === "LEAVING_ZONE") {
    return `${numberText(snapshot.zone_low)} – ${numberText(snapshot.zone_high)}`;
  }
  return numberText(snapshot.target_price);
};

const toIstInputValue = (value?: string | null) => {
  if (!value) return "";
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return "";
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
    hour12: false,
  }).formatToParts(parsed);
  const part = (type: string) => parts.find((x) => x.type === type)?.value || "";
  return `${part("year")}-${part("month")}-${part("day")}T${part("hour")}:${part("minute")}`;
};

const istInputToUtcIso = (value: string) => value ? new Date(`${value}:00+05:30`).toISOString() : null;

const blankForm = (): AlertPayload => ({
  symbol: "XAUUSD",
  provider: "MT5",
  broker_account_id: null,
  alert_type: "CROSSING_UP",
  target_price: null,
  zone_low: null,
  zone_high: null,
  trigger_mode: "ONCE",
  cooldown_seconds: 60,
  rearm_distance: 0,
  rearm_type: "DISTANCE_AND_COOLDOWN",
  expires_at: null,
  telegram_enabled: true,
  browser_enabled: false,
  whatsapp_enabled: false,
});

function statusClass(value: string) {
  const v = String(value || "").toUpperCase();
  if (["ACTIVE", "ARMED", "CONNECTED", "HEALTHY", "SENT", "CONFIGURED"].includes(v)) return "border-emerald-400/30 bg-emerald-400/15 text-emerald-100";
  if (["COOLDOWN", "REARM_WAIT", "DEGRADED", "RETRYING", "SENDING"].includes(v)) return "border-amber-400/30 bg-amber-400/15 text-amber-100";
  if (["DISABLED", "COMPLETED"].includes(v)) return "border-slate-400/30 bg-slate-400/15 text-slate-100";
  return "border-red-400/30 bg-red-400/15 text-red-100";
}

export default function AlertsPage() {
  const { showToast } = useToast();
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [history, setHistory] = useState<AlertEvent[]>([]);
  const [health, setHealth] = useState<AlertHealth | null>(null);
  const [telegram, setTelegram] = useState<TelegramChannel | null>(null);
  const [accounts, setAccounts] = useState<BrokerAccount[]>([]);
  const [chatId, setChatId] = useState("");
  const [form, setForm] = useState<AlertPayload>(blankForm());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState<AlertEvent | null>(null);

  const mt5Accounts = useMemo(() => accounts.filter((a) => String(a.broker_code || a.broker_name || "").toUpperCase() === "MT5"), [accounts]);
  const isZone = form.alert_type === "ENTERING_ZONE" || form.alert_type === "LEAVING_ZONE";
  const protectionHealthy = health?.worker === "healthy" && health?.redis === "healthy" && health?.database === "healthy" && health?.market_feed === "connected";

  const load = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const [a, h, healthData, tg, brokerRows] = await Promise.all([
        alertsApi.list(),
        alertsApi.history(100),
        alertsApi.health().catch(() => null),
        alertsApi.telegramChannel().catch(() => null),
        liveTradingApi.listBrokerAccounts().catch(() => []),
      ]);
      setAlerts(a || []);
      setHistory(h || []);
      if (healthData) setHealth(healthData);
      if (tg) {
        setTelegram(tg);
        if (tg.chat_id) setChatId(tg.chat_id);
      }
      setAccounts(brokerRows || []);
    } catch (error: any) {
      showToast(error?.message || "Unable to load alerts", "error");
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(true), 5000);
    return () => window.clearInterval(timer);
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setForm(blankForm());
  };

  const saveAlert = async () => {
    if (!form.symbol.trim()) return showToast("Symbol is required", "error");
    if (!form.broker_account_id && form.provider === "MT5") return showToast("Select the MT5 broker account that supplies live ticks", "error");
    if (!isZone && (!form.target_price || Number(form.target_price) <= 0)) return showToast("Enter a valid target price", "error");
    if (isZone && (!(Number(form.zone_low) < Number(form.zone_high)))) return showToast("Zone Low must be below Zone High", "error");
    try {
      setBusy(true);
      const payload: AlertPayload = {
        ...form,
        symbol: form.symbol.trim().toUpperCase(),
        target_price: isZone ? null : Number(form.target_price),
        zone_low: isZone ? Number(form.zone_low) : null,
        zone_high: isZone ? Number(form.zone_high) : null,
        cooldown_seconds: Number(form.cooldown_seconds || 0),
        rearm_distance: Number(form.rearm_distance || 0),
      };
      if (editingId) await alertsApi.update(editingId, payload);
      else await alertsApi.create(payload);
      showToast(editingId ? "Alert updated" : "Alert created and armed", "success");
      resetForm();
      await load(true);
    } catch (error: any) {
      showToast(error?.message || "Unable to save alert", "error");
    } finally {
      setBusy(false);
    }
  };

  const editAlert = (row: PriceAlert) => {
    setEditingId(row.id);
    setForm({
      symbol: row.symbol,
      provider: row.provider,
      broker_account_id: row.broker_account_id || null,
      alert_type: row.alert_type,
      target_price: row.target_price == null ? null : Number(row.target_price),
      zone_low: row.zone_low == null ? null : Number(row.zone_low),
      zone_high: row.zone_high == null ? null : Number(row.zone_high),
      trigger_mode: row.trigger_mode,
      cooldown_seconds: row.cooldown_seconds,
      rearm_distance: Number(row.rearm_distance || 0),
      rearm_type: row.rearm_type,
      expires_at: row.expires_at || null,
      telegram_enabled: row.telegram_enabled,
      browser_enabled: false,
      whatsapp_enabled: false,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const runAction = async (action: "enable" | "disable" | "delete", row: PriceAlert) => {
    try {
      setBusy(true);
      if (action === "enable") await alertsApi.enable(row.id);
      if (action === "disable") await alertsApi.disable(row.id);
      if (action === "delete") await alertsApi.remove(row.id);
      showToast(action === "delete" ? "Alert deleted" : `Alert ${action}d`, "success");
      await load(true);
    } catch (error: any) {
      showToast(error?.message || "Alert action failed", "error");
    } finally {
      setBusy(false);
    }
  };

  const saveTelegram = async () => {
    if (!chatId.trim()) return showToast("Enter your Telegram chat ID", "error");
    try {
      setBusy(true);
      const saved = await alertsApi.saveTelegramChannel(chatId.trim());
      setTelegram(saved);
      showToast("Telegram chat saved", "success");
    } catch (error: any) {
      showToast(error?.message || "Unable to save Telegram chat", "error");
    } finally { setBusy(false); }
  };

  const testTelegram = async () => {
    try {
      setBusy(true);
      if (chatId.trim() && chatId.trim() !== telegram?.chat_id) await alertsApi.saveTelegramChannel(chatId.trim());
      await alertsApi.testTelegram(chatId.trim() || undefined);
      showToast("Telegram API accepted the test notification", "success");
      await load(true);
    } catch (error: any) {
      showToast(error?.message || "Telegram test failed", "error");
    } finally { setBusy(false); }
  };

  if (loading) return <PageShell><div className="flex min-h-[50vh] items-center justify-center gap-2 text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin" />Loading alert engine…</div></PageShell>;

  return (
    <PageShell>
      <PageHeader title="Real-Time Alerts" description="Live tick/quote monitoring independent of candle close, backtests, strategy evaluation and browser refresh." />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        {[
          ["Alert Worker", health?.worker || "unknown", health?.worker === "healthy"],
          ["Redis", health?.redis || "unknown", health?.redis === "healthy"],
          ["Database", health?.database || "unknown", health?.database === "healthy"],
          ["Market Feed", health?.market_feed || "unknown", health?.market_feed === "connected"],
          ["Telegram", health?.telegram || "unknown", health?.telegram === "configured"],
        ].map(([label, value, good]) => (
          <GlassCard key={String(label)} className="p-4">
            <div className="flex items-center justify-between gap-3">
              <div><p className="text-xs uppercase tracking-wider text-muted-foreground">{String(label)}</p><p className="mt-1 font-semibold capitalize">{String(value).replaceAll("_", " ")}</p></div>
              {good ? <CheckCircle2 className="h-5 w-5 text-emerald-300" /> : <CircleAlert className="h-5 w-5 text-amber-300" />}
            </div>
          </GlassCard>
        ))}
      </div>

      {!protectionHealthy && (
        <div className="mt-4 flex gap-3 rounded-2xl border border-amber-400/25 bg-amber-400/10 p-4 text-sm text-amber-100">
          <WifiOff className="mt-0.5 h-5 w-5 shrink-0" />
          <div><strong>Real-time alert protection is not fully healthy.</strong> Alerts remain stored, but active protection requires the alert worker, Redis, database and live market feed to all be healthy. Start/verify the MT5 Agent on an always-on Windows/VPS host and check the health cards before relying on alerts.</div>
        </div>
      )}

      <div className="mt-6 grid gap-6 2xl:grid-cols-[1.25fr_.75fr]">
        <GlassCard className="p-5">
          <div className="mb-5 flex items-center justify-between"><div><h2 className="text-xl font-bold">{editingId ? "Edit Alert" : "Create Alert"}</h2><p className="text-sm text-muted-foreground">Phase 1 supports MT5 live ticks + Telegram.</p></div>{editingId && <Button variant="outline" onClick={resetForm}>Cancel Edit</Button>}</div>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <div><Label>Symbol</Label><Input className="mt-2" value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })} placeholder="XAUUSD" /></div>
            <div><Label>Feed / Provider</Label><Select value={form.provider} onValueChange={(v) => setForm({ ...form, provider: v })}><SelectTrigger className={alertSelectTriggerClass}><SelectValue /></SelectTrigger><SelectContent className={alertSelectContentClass}><SelectItem className={alertSelectItemClass} value="MT5">MT5 Agent — Live Ticks</SelectItem></SelectContent></Select></div>
            <div><Label>MT5 Broker Account</Label><Select value={form.broker_account_id || ""} onValueChange={(v) => setForm({ ...form, broker_account_id: v || null })}><SelectTrigger className={alertSelectTriggerClass}><SelectValue placeholder="Select account" /></SelectTrigger><SelectContent className={alertSelectContentClass}>{mt5Accounts.map((a) => <SelectItem className={alertSelectItemClass} key={a.id} value={a.id}>{a.account_label} · {a.status}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Condition</Label><Select value={form.alert_type} onValueChange={(v) => setForm({ ...form, alert_type: v as AlertType })}><SelectTrigger className={alertSelectTriggerClass}><SelectValue /></SelectTrigger><SelectContent className={alertSelectContentClass}>{conditions.map((x) => <SelectItem className={alertSelectItemClass} key={x.value} value={x.value}>{x.label}</SelectItem>)}</SelectContent></Select></div>
            {!isZone ? <div><Label>Target Price</Label><Input className="mt-2" type="number" step="any" value={form.target_price ?? ""} onChange={(e) => setForm({ ...form, target_price: e.target.value === "" ? null : Number(e.target.value) })} /></div> : <><div><Label>Zone Low</Label><Input className="mt-2" type="number" step="any" value={form.zone_low ?? ""} onChange={(e) => setForm({ ...form, zone_low: e.target.value === "" ? null : Number(e.target.value) })} /></div><div><Label>Zone High</Label><Input className="mt-2" type="number" step="any" value={form.zone_high ?? ""} onChange={(e) => setForm({ ...form, zone_high: e.target.value === "" ? null : Number(e.target.value) })} /></div></>}
            <div><Label>Frequency</Label><Select value={form.trigger_mode} onValueChange={(v) => setForm({ ...form, trigger_mode: v as "ONCE" | "RECURRING" })}><SelectTrigger className={alertSelectTriggerClass}><SelectValue /></SelectTrigger><SelectContent className={alertSelectContentClass}><SelectItem className={alertSelectItemClass} value="ONCE">Trigger Once</SelectItem><SelectItem className={alertSelectItemClass} value="RECURRING">Recurring / Rearm</SelectItem></SelectContent></Select></div>
            <div><Label>Cooldown (seconds)</Label><Input className="mt-2" type="number" min={0} value={form.cooldown_seconds} disabled={form.trigger_mode === "ONCE"} onChange={(e) => setForm({ ...form, cooldown_seconds: Number(e.target.value) })} /></div>
            <div><Label>Rearm Distance</Label><Input className="mt-2" type="number" min={0} step="any" value={form.rearm_distance} disabled={form.trigger_mode === "ONCE" || isZone} onChange={(e) => setForm({ ...form, rearm_distance: Number(e.target.value) })} /><p className="mt-1 text-xs text-muted-foreground">Crossing alerts must move this far away after cooldown before rearming.</p></div>
            <div><Label>Expiration (optional, IST)</Label><Input className="mt-2" type="datetime-local" value={toIstInputValue(form.expires_at)} onChange={(e) => setForm({ ...form, expires_at: istInputToUtcIso(e.target.value) })} /></div>
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-3">
            <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3"><p className="font-semibold">Telegram</p><p className="text-xs text-muted-foreground">Enabled in Phase 1</p></div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-3 opacity-60"><p className="font-semibold">Browser Push</p><p className="text-xs text-muted-foreground">Coming in Phase 4</p></div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-3 opacity-60"><p className="font-semibold">WhatsApp</p><p className="text-xs text-muted-foreground">Coming in Phase 4</p></div>
          </div>
          <Button className="mt-5" disabled={busy} onClick={() => void saveAlert()}><BellRing className="mr-2 h-4 w-4" />{editingId ? "Save Changes" : "Create & Arm Alert"}</Button>
        </GlassCard>

        <GlassCard className="p-5">
          <h2 className="text-xl font-bold">Telegram Setup</h2>
          <p className="mt-1 text-sm text-muted-foreground">Create the bot with BotFather, start a chat with it, then save the Telegram chat ID here.</p>
          <div className="mt-4"><Label>Telegram Chat ID</Label><Input className="mt-2" value={chatId} onChange={(e) => setChatId(e.target.value)} placeholder="e.g. 123456789" /></div>
          <div className="mt-4 flex flex-wrap gap-2"><Button variant="outline" disabled={busy} onClick={() => void saveTelegram()}>Save Chat ID</Button><Button disabled={busy} onClick={() => void testTelegram()}><Send className="mr-2 h-4 w-4" />Test Telegram</Button></div>
          <div className="mt-4 rounded-xl border border-white/10 bg-white/5 p-3 text-sm"><p>Bot token: <strong>{health?.telegram === "configured" ? "Configured" : "Not configured on API/worker"}</strong></p><p>Chat: <strong>{telegram?.configured ? (telegram.verified ? "Verified by test" : "Configured") : "Not configured"}</strong></p>{telegram?.using_global_fallback && <p className="mt-1 text-amber-200">Using global admin fallback chat ID.</p>}</div>
          <p className="mt-3 text-xs text-muted-foreground">A successful test means Telegram Bot API accepted the message. It is not a handset-delivery receipt.</p>
        </GlassCard>
      </div>

      <GlassCard className="mt-6 p-5">
        <div className="mb-4 flex items-center justify-between"><div><h2 className="text-xl font-bold">Active Alerts</h2><p className="text-sm text-muted-foreground">Persistent state survives frontend closure and worker restart.</p></div><Button size="sm" variant="outline" onClick={() => void load(true)}><RefreshCw className="mr-2 h-4 w-4" />Refresh</Button></div>
        <div className="overflow-x-auto"><Table className="min-w-[1200px]"><TableHeader><TableRow><TableHead>Symbol</TableHead><TableHead>Condition</TableHead><TableHead>Target / Zone</TableHead><TableHead>Feed</TableHead><TableHead>Status</TableHead><TableHead>Last Price</TableHead><TableHead>Distance</TableHead><TableHead>Last Triggered</TableHead><TableHead>Count</TableHead><TableHead>Channel</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>
          {alerts.length === 0 ? <TableRow><TableCell colSpan={11} className="py-10 text-center text-muted-foreground">No alerts created yet.</TableCell></TableRow> : alerts.map((row) => {
            const last = Number(row.last_price);
            const target = Number(row.target_price);
            const distance = row.target_price != null && Number.isFinite(last) ? Math.abs(target - last) : null;
            return <TableRow key={row.id}><TableCell className="font-semibold">{row.symbol}</TableCell><TableCell>{conditionLabel(row.alert_type)}</TableCell><TableCell>{row.target_price != null ? numberText(row.target_price) : `${numberText(row.zone_low)} – ${numberText(row.zone_high)}`}</TableCell><TableCell>{row.provider}</TableCell><TableCell><div className="flex gap-1"><Badge className={statusClass(row.status)}>{row.status}</Badge><Badge className={statusClass(row.runtime_state)}>{row.runtime_state}</Badge></div></TableCell><TableCell>{numberText(row.last_price)}</TableCell><TableCell>{distance == null ? "—" : numberText(distance, 4)}</TableCell><TableCell>{formatDateTimeIST(row.last_triggered_at, { seconds: true })}</TableCell><TableCell>{row.trigger_count}</TableCell><TableCell>Telegram</TableCell><TableCell><div className="flex gap-1"><Button title="Edit" size="icon" variant="ghost" onClick={() => editAlert(row)}><Edit3 className="h-4 w-4" /></Button>{row.status === "ACTIVE" ? <Button title="Disable" size="icon" variant="ghost" onClick={() => void runAction("disable", row)}><Pause className="h-4 w-4" /></Button> : <Button title="Enable" size="icon" variant="ghost" onClick={() => void runAction("enable", row)}><Play className="h-4 w-4" /></Button>}<Button title="Delete" size="icon" variant="ghost" onClick={() => void runAction("delete", row)}><Trash2 className="h-4 w-4" /></Button></div></TableCell></TableRow>;
          })}
        </TableBody></Table></div>
      </GlassCard>

      <GlassCard className="mt-6 p-5">
        <h2 className="text-xl font-bold">Alert History</h2><p className="mb-4 text-sm text-muted-foreground">Detailed timestamps and real measured API/internal latency.</p>
        <div className="overflow-x-auto"><Table className="min-w-[1050px]"><TableHeader><TableRow><TableHead>Symbol</TableHead><TableHead>Alert</TableHead><TableHead>Target / Zone</TableHead><TableHead>Trigger Price</TableHead><TableHead>Triggered At</TableHead><TableHead>Channel</TableHead><TableHead>Delivery</TableHead><TableHead>Feed→Server</TableHead><TableHead>Evaluation</TableHead><TableHead>Telegram API</TableHead><TableHead>Total</TableHead></TableRow></TableHeader><TableBody>
          {history.length === 0 ? <TableRow><TableCell colSpan={11} className="py-10 text-center text-muted-foreground">No alert events yet.</TableCell></TableRow> : history.map((row) => <TableRow key={row.id} className="cursor-pointer" onClick={() => setDetail(row)}><TableCell className="font-semibold">{row.symbol}</TableCell><TableCell>{conditionLabel(row.condition_type)}</TableCell><TableCell>{eventTargetLabel(row)}</TableCell><TableCell>{numberText(row.trigger_price)}</TableCell><TableCell>{formatDateTimeIST(row.condition_detected_at, { seconds: true })}</TableCell><TableCell>Telegram</TableCell><TableCell><Badge className={statusClass(row.telegram_status)}>{row.telegram_status}</Badge></TableCell><TableCell>{row.feed_to_server_latency_ms ?? "—"} ms</TableCell><TableCell>{row.evaluation_latency_ms ?? "—"} ms</TableCell><TableCell>{row.notification_api_latency_ms ?? "—"} ms</TableCell><TableCell>{row.total_internal_latency_ms ?? "—"} ms</TableCell></TableRow>)}
        </TableBody></Table></div>
      </GlassCard>

      <Dialog open={!!detail} onOpenChange={(open) => !open && setDetail(null)}><DialogContent className="max-w-2xl"><DialogHeader><DialogTitle>Alert Event Timing</DialogTitle></DialogHeader>{detail && <div className="grid gap-3 text-sm md:grid-cols-2">{[
        ["Event", detail.id], ["Alert", detail.alert_id], ["Symbol", detail.symbol], ["Condition", conditionLabel(detail.condition_type)], ["Target / Zone", eventTargetLabel(detail)], ["Previous Price", numberText(detail.previous_price)], ["Trigger Price", numberText(detail.trigger_price)], ["Market Timestamp", formatDateTimeIST(detail.market_timestamp, { seconds: true })], ["Server Received", formatDateTimeIST(detail.server_received_at, { seconds: true })], ["Condition Detected", formatDateTimeIST(detail.condition_detected_at, { seconds: true })], ["Notification Queued", formatDateTimeIST(detail.notification_queued_at, { seconds: true })], ["Telegram API Requested", formatDateTimeIST(detail.notification_sent_at, { seconds: true })], ["Telegram API Response", formatDateTimeIST(detail.notification_response_at, { seconds: true })],
      ].map(([label, value]) => <div key={String(label)} className="rounded-lg border border-white/10 bg-white/5 p-3"><p className="text-xs text-muted-foreground">{String(label)}</p><p className="mt-1 break-all">{String(value)}</p></div>)}</div>}</DialogContent></Dialog>
    </PageShell>
  );
}
