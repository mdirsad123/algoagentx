"use client";

/**
 * Payment Fallback Service
 * Provides demo payment functionality when backend API is not available
 */

export interface DemoPaymentResult {
  success: boolean;
  creditsGranted: number;
  message: string;
}

export interface DemoSubscriptionResult {
  success: boolean;
  planCode: string;
  period: string;
  message: string;
}

/**
 * Demo payment for credit top-up
 */
export function processDemoPayment(creditsToBuy: number): Promise<DemoPaymentResult> {
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      resolve({
        success: true,
        creditsGranted: creditsToBuy,
        message: `Demo Payment Successful! ${creditsToBuy} credits have been added to your wallet.`
      });
    }, 1500);
  });
}

/**
 * Demo subscription for plan purchases
 */
export function processDemoSubscription(planCode: string, billingPeriod: string): Promise<DemoSubscriptionResult> {
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      resolve({
        success: true,
        planCode: planCode,
        period: billingPeriod,
        message: `Demo Subscription Successful! ${planCode} plan (${billingPeriod}) activated.`
      });
    }, 1500);
  });
}

/**
 * Enhanced payment processor with automatic fallback
 */
export class PaymentProcessor {
  private useDemoMode: boolean;
  private backendAvailable: boolean | null = null;
  private lastHealthCheck: number = 0;
  private healthCheckCooldown: number = 5000; // 5 seconds cooldown

  constructor(useDemoMode: boolean = false) {
    this.useDemoMode = useDemoMode;
  }

  /**
   * Check if backend is available (cached result with cooldown)
   */
  async isBackendAvailable(): Promise<boolean> {
    const now = Date.now();
    
    // If we have a cached result and it's still within cooldown, return it
    if (this.backendAvailable !== null && (now - this.lastHealthCheck) < this.healthCheckCooldown) {
      return this.backendAvailable;
    }

    // If we're in demo mode, always return false to skip backend checks
    if (this.useDemoMode) {
      this.backendAvailable = false;
      return false;
    }

    try {
      const isAvailable = await checkBackendStatus();
      this.backendAvailable = isAvailable;
      this.lastHealthCheck = now;
      return isAvailable;
    } catch (error) {
      this.backendAvailable = false;
      this.lastHealthCheck = now;
      return false;
    }
  }

  /**
   * Process credit top-up with automatic fallback to demo mode
   */
  async processCreditPurchase(
    creditsToBuy: number,
    onSuccess: (result: DemoPaymentResult) => void,
    onError: (error: string) => void
  ) {
    // If explicitly using demo mode, skip backend check
    if (this.useDemoMode) {
      try {
        const result = await processDemoPayment(creditsToBuy);
        onSuccess(result);
      } catch (error) {
        onError('Demo payment failed. Please try again.');
      }
      return;
    }

    // Check if backend is available
    const backendAvailable = await this.isBackendAvailable();

    if (!backendAvailable) {
      console.log('Backend not available, using demo mode');
      try {
        const result = await processDemoPayment(creditsToBuy);
        onSuccess(result);
      } catch (error) {
        onError('Demo payment failed. Please try again.');
      }
      return;
    }

    try {
      // Try real payment first
      const { processPayment } = await import('./razorpay');
      await processPayment(
        creditsToBuy,
        (creditsGranted) => {
          onSuccess({
            success: true,
            creditsGranted,
            message: `Payment Successful! ${creditsGranted} credits added to your wallet.`
          });
        },
        (error) => {
          console.warn('Real payment failed, falling back to demo mode:', error);
          // Fall back to demo mode
          this.processCreditPurchase(creditsToBuy, onSuccess, onError);
        }
      );
    } catch (error) {
      console.warn('Payment service unavailable, using demo mode:', error);
      // Fall back to demo mode
      this.backendAvailable = false; // Cache that backend is not available
      const result = await processDemoPayment(creditsToBuy);
      onSuccess(result);
    }
  }

  /**
   * Process subscription with automatic fallback to demo mode
   */
  async processSubscription(
    planCode: string,
    billingPeriod: string,
    onSuccess: (result: DemoSubscriptionResult) => void,
    onError: (error: string) => void
  ) {
    // If explicitly using demo mode, skip backend check
    if (this.useDemoMode) {
      try {
        const result = await processDemoSubscription(planCode, billingPeriod);
        onSuccess(result);
      } catch (error) {
        onError('Demo subscription failed. Please try again.');
      }
      return;
    }

    // Check if backend is available
    const backendAvailable = await this.isBackendAvailable();

    if (!backendAvailable) {
      console.log('Backend not available, using demo mode');
      try {
        const result = await processDemoSubscription(planCode, billingPeriod);
        onSuccess(result);
      } catch (error) {
        onError('Demo subscription failed. Please try again.');
      }
      return;
    }

    try {
      // Try real subscription first
      const { processSubscription } = await import('./razorpay');
      await processSubscription(
        planCode,
        billingPeriod,
        () => {
          onSuccess({
            success: true,
            planCode,
            period: billingPeriod,
            message: `Subscription Successful! ${planCode} plan activated.`
          });
        },
        (error) => {
          console.warn('Real subscription failed, falling back to demo mode:', error);
          // Fall back to demo mode
          this.processSubscription(planCode, billingPeriod, onSuccess, onError);
        }
      );
    } catch (error) {
      console.warn('Subscription service unavailable, using demo mode:', error);
      // Fall back to demo mode
      this.backendAvailable = false; // Cache that backend is not available
      const result = await processDemoSubscription(planCode, billingPeriod);
      onSuccess(result);
    }
  }

  /**
   * Force refresh backend availability check
   */
  async refreshBackendStatus(): Promise<boolean> {
    this.backendAvailable = null;
    this.lastHealthCheck = 0;
    return await this.isBackendAvailable();
  }
}

/**
 * Create payment processor instance
 */
export function createPaymentProcessor(useDemoMode: boolean = false): PaymentProcessor {
  return new PaymentProcessor(useDemoMode);
}

/**
 * Check if backend API is available
 */
export async function checkBackendStatus(): Promise<boolean> {
  try {
    const response = await fetch('/health', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      cache: 'no-cache' // Prevent caching
    });
    return response.ok;
  } catch (error) {
    console.warn('Backend API not available:', error);
    return false;
  }
}
