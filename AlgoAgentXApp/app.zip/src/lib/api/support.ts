import axiosInstance from "../axios";

const unwrap = (payload: any) => payload?.success ? payload.data : payload;

export interface SupportReply {
  id: string;
  ticket_id: string;
  user_id?: string | null;
  message: string;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  priority: "low" | "medium" | "high";
  status: "open" | "in_progress" | "closed";
  created_at: string;
  updated_at: string;
  replies: SupportReply[];
}

export const supportApi = {
  list: async () => unwrap((await axiosInstance.get("/api/v1/support-tickets")).data) as SupportTicket[],
  create: async (payload: { subject: string; message: string; priority: "low" | "medium" | "high" }) => unwrap((await axiosInstance.post("/api/v1/support-tickets", payload)).data) as SupportTicket,
  reply: async (ticketId: string, message: string) => unwrap((await axiosInstance.post(`/api/v1/support-tickets/${ticketId}/reply`, { message })).data) as SupportReply,
};
