import axiosInstance from "@/lib/axios";

type ApiEnvelope<T> = {
  success?: boolean;
  data?: T;
  message?: string;
};

const unwrap = <T>(payload: ApiEnvelope<T> | T): T | undefined => {
  if (payload && typeof payload === "object" && "success" in (payload as Record<string, unknown>)) {
    const envelope = payload as ApiEnvelope<T>;
    return envelope.data as T | undefined;
  }
  return payload as T;
};

export interface StrategyOption {
  id: string;
  name: string;
  description?: string | null;
  strategyType?: string | null;
  timeframe?: string | null;
  parameters?: Record<string, unknown> | null;
}

export interface InstrumentOption {
  id: number;
  symbol: string;
  exchange?: string | null;
  market?: string | null;
  instrument_type?: string | null;
}

export interface BacktestConfigResponse {
  strategies: Array<{ id: string; name: string }>;
  instruments: InstrumentOption[];
  timeframes: string[];
  credits?: {
    balance?: number;
    included?: number;
  };
  limits?: {
    max_backtests_per_day?: number;
    max_date_range_days?: number;
  };
}

export interface DataAvailabilityResponse {
  instrument_id: number;
  timeframe: string;
  available: boolean;
  candle_count: number;
  min_timestamp: string | null;
  max_timestamp: string | null;
  requested_candle_count: number;
}

export interface CostPreviewResponse {
  total_cost: number;
  current_balance: number;
  can_run: boolean;
  balances?: {
    wallet_balance?: number;
    included_balance?: number;
    total_available?: number;
  };
  breakdown?: {
    base_cost?: number;
    date_range_days?: number;
    timeframe?: string;
    candle_count?: number;
    multipliers?: {
      volume?: number;
      complexity?: number;
    };
    complexity?: Record<string, unknown>;
  };
}

export interface BacktestRunPayload {
  strategy_id: string;
  instrument_id: number;
  timeframe: string;
  start_date: string;
  end_date: string;
  capital: number;
  save_result?: boolean;
}

export interface BacktestRunResult {
  backtest_id?: string;
  strategy_name?: string;
  instrument_symbol?: string;
  timeframe?: string;
  start_date?: string;
  end_date?: string;
  initial_capital?: number;
  final_capital?: number;
  net_profit?: number;
  max_drawdown?: number;
  sharpe_ratio?: number;
  win_rate?: number;
  profit_factor?: number;
  total_trades?: number;
  credit_cost?: number;
  debit_transaction_id?: string;
  pricing?: {
    pricing_version?: string;
    date_range_days?: number;
    timeframe?: string;
    timeframe_minutes?: number;
    candle_count?: number;
    candle_count_mode?: "estimated" | "actual" | string;
    base_cost?: number;
    range_units?: number;
    multipliers?: {
      timeframe?: number;
      volume?: number;
      complexity?: number;
      premium?: number;
    };
    complexity?: Record<string, unknown>;
  };
  saved?: boolean;
}

export interface BacktestRunResponse {
  job_id?: string;
  status?: string;
  backtest_id?: string;
  result?: BacktestRunResult;
  credits?: {
    debited?: number;
    included_debited?: number;
    wallet_debited?: number;
    charge_idempotent?: boolean;
    included_debit_transaction_id?: string;
    wallet_debit_transaction_id?: string;
    balance_after?: number;
    included_balance_after?: number;
    subscription_state?: string;
  };
}

export interface BacktestDetailResponse {
  summary: {
    id: string;
    strategy_name?: string;
    instrument_symbol?: string;
    timeframe?: string;
    net_profit?: number;
    max_drawdown?: number;
    sharpe_ratio?: number;
    win_rate?: number;
    total_trades?: number;
    final_capital?: number;
    initial_capital?: number;
    created_at?: string;
  };
  trades: Array<{
    id?: string;
    entry_time?: string;
    exit_time?: string | null;
    side?: string;
    quantity?: number;
    entry_price?: number;
    exit_price?: number | null;
    pnl?: number;
    exit_type?: string | null;
  }>;
  equity_curve: Array<{
    timestamp?: string;
    equity?: number;
  }>;
  pnl_calendar: Array<{
    date?: string;
    pnl?: number;
  }>;
}

export interface BacktestHistoryItem {
  id: string;
  strategy_id?: string | null;
  strategy_name?: string | null;
  instrument_id?: number | null;
  instrument_symbol?: string | null;
  timeframe?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  initial_capital?: number | null;
  final_capital?: number | null;
  net_profit?: number | null;
  max_drawdown?: number | null;
  sharpe_ratio?: number | null;
  win_rate?: number | null;
  total_trades?: number | null;
  winning_trades?: number | null;
  losing_trades?: number | null;
  credit_cost?: number | null;
  debit_transaction_id?: string | null;
  profit_factor?: number | null;
  status?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface BacktestHistoryPagination {
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export interface BacktestHistoryResponse {
  backtests: BacktestHistoryItem[];
  pagination: BacktestHistoryPagination;
}

export interface BacktestHistoryQuery {
  page?: number;
  page_size?: number;
  strategy_id?: string;
  instrument_id?: number;
  timeframe?: string;
  status?: string;
  start_date_from?: string;
  start_date_to?: string;
  min_profit?: number;
  max_drawdown?: number;
}

export const backtestsApi = {
  async getConfig(): Promise<BacktestConfigResponse> {
    const response = await axiosInstance.get<ApiEnvelope<BacktestConfigResponse> | BacktestConfigResponse>("/api/v1/backtests/config");
    return (unwrap(response.data) || {
      strategies: [],
      instruments: [],
      timeframes: [],
    }) as BacktestConfigResponse;
  },

  async getStrategiesCatalog(): Promise<StrategyOption[]> {
    const response = await axiosInstance.get<ApiEnvelope<StrategyOption[]> | StrategyOption[]>("/api/v1/strategies");
    const data = unwrap(response.data);
    return Array.isArray(data) ? data : [];
  },

  async getInstruments(): Promise<InstrumentOption[]> {
    const response = await axiosInstance.get<ApiEnvelope<InstrumentOption[]> | InstrumentOption[]>("/api/v1/instruments");
    const data = unwrap(response.data);
    return Array.isArray(data) ? data : [];
  },

  async getTimeframes(instrumentId?: number): Promise<string[]> {
    const response = await axiosInstance.get<ApiEnvelope<{ timeframes: string[] }> | { timeframes: string[] }>(
      "/api/v1/backtests/timeframes",
      {
        params: instrumentId ? { instrument_id: instrumentId } : undefined,
      },
    );
    const data = unwrap(response.data);
    return Array.isArray(data?.timeframes) ? data.timeframes : [];
  },

  async getDataAvailability(params: {
    instrument_id: number;
    timeframe: string;
    start_date?: string;
    end_date?: string;
  }): Promise<DataAvailabilityResponse> {
    const response = await axiosInstance.get<ApiEnvelope<DataAvailabilityResponse> | DataAvailabilityResponse>(
      "/api/v1/backtests/data-availability",
      { params },
    );
    return (unwrap(response.data) || {
      instrument_id: params.instrument_id,
      timeframe: params.timeframe,
      available: false,
      candle_count: 0,
      min_timestamp: null,
      max_timestamp: null,
      requested_candle_count: 0,
    }) as DataAvailabilityResponse;
  },

  async previewCost(payload: {
    strategy_id?: string;
    instrument_id?: number;
    timeframe: string;
    start_date: string;
    end_date: string;
    capital?: number;
  }): Promise<CostPreviewResponse> {
    const response = await axiosInstance.post<ApiEnvelope<CostPreviewResponse> | CostPreviewResponse>(
      "/api/v1/backtests/cost-preview",
      payload,
    );
    return (unwrap(response.data) || {
      total_cost: 0,
      current_balance: 0,
      can_run: false,
    }) as CostPreviewResponse;
  },

  async run(payload: BacktestRunPayload): Promise<BacktestRunResponse> {
    const response = await axiosInstance.post<ApiEnvelope<BacktestRunResponse> | BacktestRunResponse>(
      "/api/v1/backtests/run",
      payload,
    );
    return (unwrap(response.data) || {}) as BacktestRunResponse;
  },

  async getDetail(backtestId: string): Promise<BacktestDetailResponse> {
    const response = await axiosInstance.get<ApiEnvelope<BacktestDetailResponse> | BacktestDetailResponse>(
      `/api/v1/backtests/${backtestId}/detail`,
    );
    return (unwrap(response.data) || {
      summary: { id: backtestId },
      trades: [],
      equity_curve: [],
      pnl_calendar: [],
    }) as BacktestDetailResponse;
  },

  async getHistory(params: BacktestHistoryQuery = {}): Promise<BacktestHistoryResponse> {
    const response = await axiosInstance.get<ApiEnvelope<BacktestHistoryResponse> | BacktestHistoryResponse>(
      "/api/v1/backtests/history",
      { params },
    );
    return (unwrap(response.data) || {
      backtests: [],
      pagination: {
        page: params.page || 1,
        page_size: params.page_size || 20,
        total_count: 0,
        total_pages: 1,
      },
    }) as BacktestHistoryResponse;
  },
};
