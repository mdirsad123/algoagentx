"use client";

import axiosInstance from "./axios";
const unwrapApiData = (payload: any) => payload?.success ? payload.data : payload;

export interface CreateOrderRequest {
  credits_to_buy: number;
}

export interface CreateOrderResponse {
  order_id: string;
  amount: number;
  currency: string;
  razorpay_key_id: string;
  credits_to_buy: number;
}

export interface VerifyPaymentRequest {
  order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

export interface VerifyPaymentResponse {
  success: boolean;
  payment_id: string;
  credits_granted: number;
  message: string;
}

export interface CreateSubscriptionRequest {
  plan_code: string;
  billing_period: string;
}

export interface CreateSubscriptionResponse {
  subscription_id: string;
  plan_code: string;
  amount: number;
  currency: string;
  razorpay_key_id: string;
  start_date: string;
}

/**
 * Create a one-time payment order for credit top-up
 */
export async function createOrder(request: CreateOrderRequest): Promise<CreateOrderResponse> {
  try {
    const response = await axiosInstance.post('/api/v1/payments/razorpay/create-order', request);
    return unwrapApiData(response.data);
  } catch (error: any) {
    console.error('Error creating order:', error);
    throw new Error(error.response?.data?.detail || 'Failed to create payment order');
  }
}

/**
 * Verify a payment after successful checkout
 */
export async function verifyPayment(request: VerifyPaymentRequest): Promise<VerifyPaymentResponse> {
  try {
    const response = await axiosInstance.post('/api/v1/payments/razorpay/verify', request);
    return unwrapApiData(response.data);
  } catch (error: any) {
    console.error('Error verifying payment:', error);
    throw new Error(error.response?.data?.detail || 'Failed to verify payment');
  }
}

/**
 * Create a subscription for plan purchases
 */
export async function createSubscription(request: CreateSubscriptionRequest): Promise<CreateSubscriptionResponse> {
  try {
    const response = await axiosInstance.post('/api/v1/subscriptions/razorpay/create', request);
    return unwrapApiData(response.data);
  } catch (error: any) {
    console.error('Error creating subscription:', error);
    throw new Error(error.response?.data?.detail || 'Failed to create subscription');
  }
}

/**
 * Initialize Razorpay checkout with proper configuration
 */
export function initializeRazorpayCheckout(options: any): any {
  if (typeof window === 'undefined' || !(window as any).Razorpay) {
    throw new Error('Razorpay SDK not loaded');
  }

  return new (window as any).Razorpay({
    ...options,
    theme: {
      color: '#8b5cf6',
      backdrop_color: 'rgba(0, 0, 0, 0.5)',
      ...options.theme
    }
  });
}

/**
 * Handle demo payment for testing purposes
 */
export function handleDemoPayment(creditsToBuy: number, onSuccess: (creditsGranted: number) => void) {
  // Simulate API delay
  setTimeout(() => {
    // For demo purposes, grant the credits immediately
    alert(`Demo Payment Successful! ${creditsToBuy} credits have been added to your wallet.`);
    onSuccess(creditsToBuy);
  }, 1000);
}

/**
 * Process payment with fallback to demo mode if API fails
 */
export async function processPayment(
  creditsToBuy: number, 
  onSuccess: (creditsGranted: number) => void,
  onError: (error: string) => void,
  isDemoMode: boolean = false
) {
  if (isDemoMode) {
    handleDemoPayment(creditsToBuy, onSuccess);
    return;
  }

  try {
    // Create order
    const orderData = await createOrder({ credits_to_buy: creditsToBuy });

    // Configure Razorpay options
    const options = {
      key: orderData.razorpay_key_id,
      amount: orderData.amount,
      currency: orderData.currency,
      name: 'AlgoAgentX',
      description: `${creditsToBuy} Credits Top-up`,
      image: '/images/algoagentx_icon.jpeg',
      order_id: orderData.order_id,
      handler: async function (response: any) {
        try {
          // Verify payment
          const verifyData = await verifyPayment({
            order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature
          });

          if (verifyData.success) {
            onSuccess(verifyData.credits_granted);
          } else {
            throw new Error(verifyData.message || 'Payment verification failed');
          }
        } catch (err: any) {
          console.error('Payment verification error:', err);
          onError(err.message || 'Payment verification failed');
        }
      },
      prefill: {
        name: '', // Will be filled by Razorpay
        email: '', // Will be filled by Razorpay
        contact: '' // Will be filled by Razorpay
      },
      notes: {
        credits_to_buy: creditsToBuy
      },
      modal: {
        backdropclose: false,
        escape: true
      }
    };

    // Initialize and open checkout
    const rzp = initializeRazorpayCheckout(options);
    rzp.open();
  } catch (error: any) {
    console.error('Payment processing error:', error);
    onError(error.message || 'Failed to process payment');
  }
}

/**
 * Process subscription with fallback to demo mode if API fails
 */
export async function processSubscription(
  planCode: string,
  billingPeriod: string,
  onSuccess: () => void,
  onError: (error: string) => void,
  isDemoMode: boolean = false
) {
  if (isDemoMode) {
    // Demo subscription success
    setTimeout(() => {
      alert(`Demo Subscription Successful! ${planCode} plan activated.`);
      onSuccess();
    }, 1000);
    return;
  }

  try {
    // Create subscription
    const subscriptionData = await createSubscription({
      plan_code: planCode,
      billing_period: billingPeriod
    });

    // Configure Razorpay subscription options
    const options = {
      key: subscriptionData.razorpay_key_id,
      subscription_id: subscriptionData.subscription_id,
      name: 'AlgoAgentX',
      description: `${planCode} Plan - ${billingPeriod}`,
      image: '/images/algoagentx_icon.jpeg',
      handler: function (response: any) {
        // Success callback
        console.log('Subscription successful:', response);
        onSuccess();
      },
      prefill: {
        name: '', // Will be filled by Razorpay
        email: '', // Will be filled by Razorpay
        contact: '' // Will be filled by Razorpay
      },
      notes: {
        plan_code: planCode,
        billing_period: billingPeriod
      },
      modal: {
        backdropclose: false,
        escape: true
      }
    };

    // Initialize and open checkout
    const rzp = initializeRazorpayCheckout(options);
    rzp.open();
  } catch (error: any) {
    console.error('Subscription processing error:', error);
    onError(error.message || 'Failed to process subscription');
  }
}