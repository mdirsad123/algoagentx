"use client";

import { FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Copy, Lock, ShieldCheck } from "lucide-react";
import { FieldHelpTooltip } from "@/components/common/FieldHelpTooltip";
import { LiveCompatibilityCard } from "@/components/live/LiveCompatibilityCard";
import { RuntimeSettingsForm } from "@/components/runtime/RuntimeSettingsForm";
import { RUNTIME_TABS } from "@/components/runtime/runtimeSettingsDefaults";
import type { RuntimeTab } from "@/components/runtime/runtimeSettingsTypes";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/GlassCard";
import { PageHeader } from "@/components/ui/PageHeader";
import { PageShell } from "@/components/ui/PageShell";
import { useToast } from "@/components/shared/toast";
import { liveTradingApi } from "@/lib/api/live-trading";
import type { BrokerAccount, BrokerSymbol, FundedLiveStatus, FundedRiskPlanPayload, LiveCompatibilityResult, LiveDeploymentSummary, LiveOrderPreview, MarketInstrument } from "@/types/live-trading";


const FIELD_HELP: Record<string, string> = {
  "Name": "Friendly name for this live deployment. It helps you identify this strategy in dashboards and logs.",
  "Mode": "DEMO and LIVE use approved connected broker accounts. Risk is calculated from broker balance/equity.",
  "Broker Account": "Approved connected broker account used for DEMO or LIVE execution. Risk is calculated from broker balance/equity where available.",
  "Instrument": "Trading symbol for this deployment. It should match Instrument Master and broker symbol settings for correct sizing and execution.",
  "Timeframe": "Candle interval used by the strategy runner. Example: M5 means 5-minute candles. It affects signal frequency and execution timing.",
  "Broker Account Capital": "Read-only broker balance/equity used by the live risk engine. It appears after broker sync.",
  "Risk per Trade": "Percentage of capital risked per trade when using risk-based sizing. Example: 1% of $10,000 means $100 risk per trade. Higher values can create large losses.",
  "RR Ratio": "Reward-to-risk ratio. Example: 1:2 means target is twice the stop loss distance. This affects live TP preview and order planning.",
  "SL Mode": "Defines how stop loss is calculated: Fixed Percent, ATR volatility, recent swing high/low, or strategy suggested stop. This directly affects lot/quantity sizing.",
  "ATR Period": "Number of candles used to calculate Average True Range. Example: 14. Higher values make the volatility estimate smoother.",
  "ATR Multiplier": "Multiplier applied to ATR to calculate stop loss distance. Example: 1.5. Higher multiplier means wider stop and usually smaller position size.",
  "Swing Lookback": "Number of candles used to find recent swing high/low for stop loss placement. Example: 5 or 10 candles.",
  "Fixed Price Risk %": "Stop loss distance as a fixed percent of entry price. Example: 0.20% means SL is 0.20% away from entry. Too tight can cause noisy exits.",
  "Max Daily Loss": "Optional deployment-level daily loss guardrail. None means no extra AlgoAgentX daily-loss cap; broker/funded rules still apply where relevant.",
  "Max Trades / Day": "Optional deployment-level daily trade cap. None means AlgoAgentX allows all valid strategy signals subject to the other live risk checks.",
  "Broker Max Lot (MT5/cTrader)": "Optional extra AlgoAgentX lot cap applied after risk-based sizing. None means no extra app cap; the broker's native minimum, step, margin checks and maximum lot still apply.",
  "Max Open Positions": "Limits simultaneous open positions. Example: 1 keeps live risk controlled.",
  "MT5 DEMO Max Lot": "Maximum lot allowed for lot-based brokers such as MT5 and cTrader. Example: 0.02. Keep this low while testing.",
  "Quantity Mode": "Risk Based calculates size from stop loss and risk percent. Fixed Quantity uses the same quantity for each trade.",
  "Fixed Qty": "Manual quantity used when Quantity Mode is Fixed Quantity. High values can place oversized orders.",
  "Max Qty": "Maximum quantity cap for non-lot instruments. This protects from oversized live orders.",
  "Max Order Value": "Maximum order notional value allowed. This prevents very large orders when price or quantity is high.",
  "Product Type": "Broker product type. MIS is intraday; CNC is delivery. Use only the product type supported by your broker and instrument.",
  "Square-off Time": "Time used for intraday square-off on supported Indian market instruments. It is disabled for forex/metals like XAUUSD.",
  "Upstox Instrument Key": "Broker-specific instrument key required for Upstox orders. Example: NSE_EQ|INE040A01034.",
  "Exchange": "Broker exchange code such as NSE or BSE. Wrong values can reject orders.",
  "Segment": "Broker segment such as NSE_EQ or NSE_FO. Wrong values can reject orders.",
  "Side": "Manual preview side. BUY previews long orders; SELL previews short orders.",
  "Manual Entry": "Entry price used only for manual preview. It does not place an order by itself.",
  "Manual Stop Loss": "Stop loss price used only for manual preview. Keep it realistic because sizing depends on stop distance.",
};

const TIMEFRAME_OPTIONS = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"];
const UPSTOX_TIMEFRAME_OPTIONS = ["1m", "5m", "15m", "30m", "1h", "1d"];
const FALLBACK_SYMBOL_OPTIONS = ["XAUUSD", "BTCUSD", "EURUSD", "GBPUSD", "USDJPY", "US30", "NAS100"];

const USD_CAPITAL = [100, 500, 1000, 5000, 10000, 100000];
const INR_CAPITAL = [10000, 25000, 50000, 100000, 500000, 1000000];
const RISK_OPTIONS = [0.0025, 0.005, 0.01, 0.015, 0.02, 0.03];
const RR_OPTIONS = [1, 1.5, 1.7, 2, 3, 4, 5];
const SL_MODES = ["ATR", "SWING", "FIXED_PERCENT", "STRATEGY_SUGGESTED"];
const ATR_PERIODS = [7, 10, 14, 20, 21];
const ATR_MULTIPLIERS = [1, 1.5, 2, 2.5, 3];
const FIXED_RISK_OPTIONS = [0.001, 0.002, 0.003, 0.005, 0.01];
const USD_DAILY_LOSS = [25, 50, 100, 250, 500, 1000];
const INR_DAILY_LOSS = [500, 1000, 2500, 5000, 10000, 25000];
const MAX_TRADES = [1, 2, 3, 5, 10, 20, 50, 100];
const MAX_OPEN_POSITIONS = [1, 2, 3, 5];
const MT5_LOT_CAPS = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200];

type FormState = {
  name: string; instrument: string; timeframe: string; mode: "PAPER" | "DEMO" | "LIVE"; broker_account_id: string;
  capital: number; risk_per_trade: number; rr_ratio: number; sl_mode: string; atr_period: number; atr_multiplier: number; swing_lookback: number; price_risk_pct: number;
  max_daily_loss: number | null; max_trades_per_day: number | null; max_open_positions: number; allow_short: boolean; auto_trade_enabled: boolean; auto_runner_enabled: boolean;
  mt5_demo_max_lot: number | null; broker_symbol: string; instrument_key: string; exchange: string; segment: string; product_type: string; order_variety: string;
  quantity_mode: string; fixed_quantity: number; max_quantity: number; max_order_value: number; square_off_time: string; upstox_order_confirmed: boolean;
  copy_trading_enabled: boolean; copy_broker_account_ids: string[];
  break_even_enabled: boolean; break_even_trigger_r: number; trailing_enabled: boolean; trailing_mode: string; trail_start_r: number; trail_atr_multiplier: number; partial_exit_enabled: boolean; partial_exit_at_r: number; partial_exit_percent: number;
};

const money = (value: number | string | null | undefined, currency = "USD") => new Intl.NumberFormat(currency === "INR" ? "en-IN" : "en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(Number(value || 0));
const percent = (value: number) => `${(Number(value || 0) * 100).toFixed(value < 0.01 ? 2 : 1)}%`;
const selectValue = (value: number | null | undefined, options: number[]) => value == null ? "NONE" : options.some((item) => Number(item) === Number(value)) ? String(value) : "CUSTOM";

const normalizeSymbol = (value: unknown) => String(value || "").trim().toUpperCase();
// TradeLocker uses account-specific suffixes (BTCUSD.X, XAUUSD.X). Only
// recognize the common 6-letter forex/metal/crypto roots; never guess among
// multiple Instrument Master entries because risk specifications are critical.
const canonicalBrokerKey = (value: unknown) => {
  const symbol = normalizeSymbol(value).replace(/[^A-Z0-9]/g, "");
  return /^[A-Z]{6}[MX]$/.test(symbol) ? symbol.slice(0, 6) : symbol;
};
const masterForBrokerSymbol = (symbol: string, instruments: MarketInstrument[]) => {
  const exact = instruments.filter((item) =>
    [item.symbol, item.broker_symbol].some((v) => normalizeSymbol(v) === normalizeSymbol(symbol)));
  if (exact.length === 1) return exact[0];
  if (exact.length > 1) return null;
  const target = canonicalBrokerKey(symbol);
  const matches = instruments.filter((item) => canonicalBrokerKey(item.symbol) === target);
  return matches.length === 1 ? matches[0] : null;
};
const hasSpecValue = (value: unknown) => value !== null && value !== undefined && value !== "";
const yesNo = (value: unknown) => value === true ? "Yes" : value === false ? "No" : "—";
const displayValue = (value: unknown) => hasSpecValue(value) ? String(value) : "Missing";

type InstrumentOption = { key: string; value: string; label: string; source: "Instrument Master" | "Broker Symbol" | "Fallback"; instrument?: MarketInstrument; broker?: BrokerSymbol };

type InstrumentReadiness = {
  status: "Ready" | "Invalid" | "Missing";
  source: "Instrument Master" | "Broker Symbol Only" | "Fallback";
  spec: Record<string, any>;
  missingFields: string[];
  actionMessage: string;
  fallbackNotice?: string;
};

const buildInstrumentOptions = (currentSymbol: string, instruments: MarketInstrument[], brokerSymbols: BrokerSymbol[]): InstrumentOption[] => {
  const bySymbol = new Map<string, InstrumentOption>();
  const add = (option: InstrumentOption) => {
    const normalized = normalizeSymbol(option.value);
    if (!normalized) return;
    const existing = bySymbol.get(normalized);
    if (!existing || option.source === "Instrument Master") bySymbol.set(normalized, { ...option, value: normalized });
  };

  instruments.forEach((instrument) => {
    const symbol = normalizeSymbol(instrument.symbol);
    if (!symbol) return;
    add({
      key: `master-${instrument.id || symbol}`,
      value: symbol,
      label: `${symbol} · Instrument Master`,
      source: "Instrument Master",
      instrument,
    });
  });

  brokerSymbols.forEach((broker) => {
    const symbol = normalizeSymbol(broker.symbol);
    if (!symbol) return;
    add({ key: `broker-${symbol}`, value: symbol, label: `${symbol} · Broker Symbol`, source: "Broker Symbol", broker });
  });

  FALLBACK_SYMBOL_OPTIONS.forEach((symbol) => add({ key: `fallback-${normalizeSymbol(symbol)}`, value: symbol, label: `${normalizeSymbol(symbol)} · Fallback`, source: "Fallback" }));
  if (currentSymbol) add({ key: `current-${normalizeSymbol(currentSymbol)}`, value: currentSymbol, label: `${normalizeSymbol(currentSymbol)} · Current`, source: "Fallback" });

  return Array.from(bySymbol.values()).sort((a, b) => {
    const rank = { "Instrument Master": 0, "Broker Symbol": 1, "Fallback": 2 } as const;
    const sourceDiff = rank[a.source] - rank[b.source];
    return sourceDiff || a.value.localeCompare(b.value);
  });
};

const findSelectedMasterInstrument = (symbol: string, instruments: MarketInstrument[]) => {
  const normalized = normalizeSymbol(symbol);
  return instruments.find((instrument) => normalizeSymbol(instrument.symbol) === normalized || normalizeSymbol(instrument.broker_symbol) === normalized) || null;
};

const buildInstrumentReadiness = (symbol: string, master: MarketInstrument | null, broker: BrokerSymbol | null, preview: LiveOrderPreview | null): InstrumentReadiness => {
  const normalized = normalizeSymbol(symbol);
  const previewSpec = preview?.instrument_spec_snapshot && normalizeSymbol((preview.instrument_spec_snapshot as any).symbol || symbol) === normalized ? preview.instrument_spec_snapshot : null;
  const source = master ? "Instrument Master" : broker ? "Broker Symbol Only" : "Fallback";
  const rawSpec = master ? { ...master } : previewSpec ? { ...previewSpec } : { symbol: normalized };
  const quantityMode = normalizeSymbol(rawSpec.quantity_mode);
  const missing = new Set<string>();

  if (!master) {
    missing.add("instrument_master_record");
    missing.add("account_currency");
    missing.add("quantity_mode");
    missing.add("broker_symbol");
    missing.add("is_tradeable_live");
    missing.add("min_step_size");
  } else {
    if (!hasSpecValue(rawSpec.account_currency)) missing.add("account_currency");
    if (!hasSpecValue(rawSpec.quantity_mode)) missing.add("quantity_mode");
    if (!hasSpecValue(rawSpec.broker_symbol)) missing.add("broker_symbol");
    if (!hasSpecValue(rawSpec.tick_size) || Number(rawSpec.tick_size) <= 0) missing.add("tick_size");
    if (rawSpec.is_tradeable_live !== true) missing.add("is_tradeable_live");
    if (quantityMode === "LOTS") {
      if (!hasSpecValue(rawSpec.tick_value_per_lot) || Number(rawSpec.tick_value_per_lot) <= 0) missing.add("tick_value_per_lot");
      if (!hasSpecValue(rawSpec.lot_step) || Number(rawSpec.lot_step) <= 0) missing.add("lot_step");
      if (!hasSpecValue(rawSpec.min_lot) || Number(rawSpec.min_lot) <= 0) missing.add("min_lot");
    } else if (["SHARES", "UNITS", "CONTRACTS"].includes(quantityMode)) {
      if (!hasSpecValue(rawSpec.quantity_step) || Number(rawSpec.quantity_step) <= 0) missing.add("quantity_step");
      if (!hasSpecValue(rawSpec.min_quantity) || Number(rawSpec.min_quantity) <= 0) missing.add("min_quantity");
    } else {
      missing.add("quantity_mode");
      missing.add("min_step_size");
    }
  }

  (preview?.missing_fields || []).forEach((field) => missing.add(String(field)));
  const missingFields = Array.from(missing);
  const status = master ? (missingFields.length ? "Invalid" : "Ready") : "Missing";
  return {
    status,
    source,
    spec: rawSpec,
    missingFields,
    fallbackNotice: source !== "Instrument Master" ? "Fallback — not saved in Market Master" : undefined,
    actionMessage: status === "Ready" ? "This instrument is configured for live/demo preview." : `${normalized || "Selected symbol"} is not ready for live trading. Configure account currency, quantity mode, broker symbol, min/step size, and live enabled in Market Master.`,
  };
};

function FieldShell({ label, children, hint, help }: { label: string; children: ReactNode; hint?: string; help?: string }) {
  const helpText = help || FIELD_HELP[label] || "Runtime setting. Changing this can affect live risk, order preview, and execution behavior. Review carefully before saving.";
  return (
    <label className="space-y-2 text-sm text-purple-100">
      <span className="inline-flex items-center gap-1.5 font-semibold text-purple-50">
        {label}
        <FieldHelpTooltip label={`${label} help`} content={helpText} />
      </span>
      {children}
      {hint && <p className="text-xs text-purple-200/80">{hint}</p>}
    </label>
  );
}

function SelectBox(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-white outline-none disabled:cursor-not-allowed disabled:opacity-50 ${props.className || ""}`} />;
}

function InputBox(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`w-full rounded-xl border border-white/10 bg-white/10 px-3 py-2 text-white outline-none disabled:cursor-not-allowed disabled:opacity-50 ${props.className || ""}`} />;
}

export default function LiveDeploymentSettingsPage() {
  const { deploymentId } = useParams<{ deploymentId: string }>();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadVersion, setLoadVersion] = useState(0);
  const [runtimeLoaded, setRuntimeLoaded] = useState(false);
  const original = useRef<Record<string, any> | null>(null);
  const initialEditable = useRef<Record<string, any>>({});
  const compatibilityController = useRef<AbortController | null>(null);
  const [saving, setSaving] = useState(false);
  const [deploymentStatus, setDeploymentStatus] = useState<string>("DRAFT");
  const [brokers, setBrokers] = useState<BrokerAccount[]>([]);
  const [symbolOptions, setSymbolOptions] = useState<BrokerSymbol[]>([]);
  const [marketInstruments, setMarketInstruments] = useState<MarketInstrument[]>([]);
  const [loadingSymbols, setLoadingSymbols] = useState(false);
  const [symbolLoadError, setSymbolLoadError] = useState<string | null>(null);
  const [advancedMode, setAdvancedMode] = useState(false);
  const [advancedPreview, setAdvancedPreview] = useState(false);
  const [liveRuntimeTab, setLiveRuntimeTab] = useState<RuntimeTab>("risk");
  const [previewLoading, setPreviewLoading] = useState(false);
  const [manualSide, setManualSide] = useState<"BUY" | "SELL">("BUY");
  const [manualEntry, setManualEntry] = useState(4630);
  const [manualSL, setManualSL] = useState(4625);
  const [riskPreview, setRiskPreview] = useState<LiveOrderPreview | null>(null);
  const [summary, setSummary] = useState<LiveDeploymentSummary | null>(null);
  const [compatibility, setCompatibility] = useState<LiveCompatibilityResult | null>(null);
  const [compatBusy, setCompatBusy] = useState(false);
  const [fundedStatus, setFundedStatus] = useState<FundedLiveStatus | null>(null);
  const [fundedSaving, setFundedSaving] = useState(false);
  const [fundedRiskMode, setFundedRiskMode] = useState<"DYNAMIC" | "FIXED">("DYNAMIC");
  const [fundedFixedRiskPct, setFundedFixedRiskPct] = useState(0.01);
  const [fundedSafetyBufferPct, setFundedSafetyBufferPct] = useState(0.05);
  const [fundedConfiguredMaxRiskPct, setFundedConfiguredMaxRiskPct] = useState<number | null>(null);
  const [fundedTiers, setFundedTiers] = useState<FundedRiskPlanPayload["risk_tiers"]>([]);
  const [phaseAdvanceBrokerId, setPhaseAdvanceBrokerId] = useState("");
  const [phaseAdvanceBusy, setPhaseAdvanceBusy] = useState(false);
  const [initialRouting, setInitialRouting] = useState({ broker_account_id: "", instrument: "", broker_symbol: "" });
  const [form, setForm] = useState<FormState>({
    name: "", instrument: "", timeframe: "", mode: "PAPER", broker_account_id: "", capital: 100000, risk_per_trade: 0.01, rr_ratio: 2,
    sl_mode: "FIXED_PERCENT", atr_period: 14, atr_multiplier: 2, swing_lookback: 10, price_risk_pct: 0.002, max_daily_loss: null,
    max_trades_per_day: null, max_open_positions: 1, allow_short: true, auto_trade_enabled: false, auto_runner_enabled: false, mt5_demo_max_lot: null,
    broker_symbol: "", instrument_key: "", exchange: "NSE_EQ", segment: "EQ", product_type: "MIS", order_variety: "REGULAR", quantity_mode: "FIXED_QTY",
    fixed_quantity: 1, max_quantity: 1, max_order_value: 5000, square_off_time: "15:15", upstox_order_confirmed: false,
    copy_trading_enabled: false, copy_broker_account_ids: [],
    break_even_enabled: false, break_even_trigger_r: 1, trailing_enabled: false, trailing_mode: "ATR_TRAIL", trail_start_r: 1.5, trail_atr_multiplier: 1, partial_exit_enabled: false, partial_exit_at_r: 1.7, partial_exit_percent: 0.9,
  });

  const selectedBroker = useMemo(() => brokers.find((broker) => broker.id === form.broker_account_id), [brokers, form.broker_account_id]);
  const connectedBrokers = useMemo(() => brokers.filter((broker) => (broker.mode === "DEMO" || broker.mode === "LIVE") && broker.status === "CONNECTED"), [brokers]);
  const copyTargetBrokers = useMemo(() => connectedBrokers.filter((broker) => broker.id !== form.broker_account_id && broker.mode === selectedBroker?.mode), [connectedBrokers, form.broker_account_id, selectedBroker]);
  const isUpstox = (selectedBroker?.broker_name || selectedBroker?.broker_code || "").toUpperCase() === "UPSTOX";
  const isTradeLocker = (selectedBroker?.broker_code || selectedBroker?.broker_name || "").toUpperCase() === "TRADELOCKER";
  const isRunning = deploymentStatus === "RUNNING";
  const isFunded = original.current?.account_policy_type === "FUNDED";
  const fundedRiskLocked = isRunning || !summary || Number(summary.metrics?.open_positions || 0) > 0;
  const isPaperDeprecated = form.mode === "PAPER";
  const selectedMasterInstrument = useMemo(() => isTradeLocker ? masterForBrokerSymbol(form.broker_symbol || form.instrument, marketInstruments) : findSelectedMasterInstrument(form.instrument, marketInstruments), [form.instrument, form.broker_symbol, marketInstruments, isTradeLocker]);
  const accountMetrics = summary?.metrics || null;
  const accountCurrency = accountMetrics?.account_currency || accountMetrics?.currency || riskPreview?.account_currency || selectedMasterInstrument?.account_currency || (isUpstox || form.instrument_key ? "INR" : "USD");
  const currency = String(accountCurrency || "USD");
  const effectiveCapital = accountMetrics?.effective_capital ?? accountMetrics?.equity ?? accountMetrics?.balance ?? form.capital;
  const effectiveCapitalSource = accountMetrics?.effective_capital_source || (accountMetrics ? "BROKER_SYNC" : "FALLBACK_DEPLOYMENT_CAPITAL");
  const dailyLossOptions = currency === "INR" ? INR_DAILY_LOSS : USD_DAILY_LOSS;
  const selectedBrokerSymbol = useMemo(() => symbolOptions.find((item) => normalizeSymbol(item.symbol) === normalizeSymbol(isTradeLocker ? form.broker_symbol || form.instrument : form.instrument)) || null, [symbolOptions, form.instrument, form.broker_symbol, isTradeLocker]);
  const instrumentOptions = useMemo(() => isTradeLocker
    ? [...symbolOptions.map((broker) => ({ key: `broker-${broker.symbol}`, value: normalizeSymbol(broker.symbol), label: `${normalizeSymbol(broker.symbol)} · Connected TradeLocker`, source: "Broker Symbol" as const, broker })),
       ...(symbolOptions.some((row) => normalizeSymbol(row.symbol) === normalizeSymbol(form.broker_symbol || form.instrument)) ? [] : [{ key: "unavailable-current", value: normalizeSymbol(form.broker_symbol || form.instrument), label: `${normalizeSymbol(form.broker_symbol || form.instrument)} · Not in connected broker (select another)`, source: "Fallback" as const }])]
    : buildInstrumentOptions(form.instrument, marketInstruments, symbolOptions), [form.instrument, form.broker_symbol, marketInstruments, symbolOptions, isTradeLocker]);
  const instrumentReadiness = useMemo(() => buildInstrumentReadiness(form.instrument, selectedMasterInstrument, selectedBrokerSymbol, riskPreview), [form.instrument, selectedMasterInstrument, selectedBrokerSymbol, riskPreview]);
  const instrumentSpec = instrumentReadiness.spec;
  const instrumentStatus = instrumentReadiness.status;
  const normalizedInstrument = normalizeSymbol(form.instrument);
  const liveSlMode = form.sl_mode || "ATR";
  const liveQuantityMode = form.quantity_mode || "FIXED_QTY";
  const selectedMarketCode = normalizeSymbol(selectedMasterInstrument?.market || selectedMasterInstrument?.asset_class || selectedMasterInstrument?.exchange || (isUpstox ? "NSE" : ""));
  const supportsLiveSquareOff = isUpstox || ["NSE", "NSE_EQ", "NSE_FO", "BSE", "INDIAN_EQUITY", "INDIAN_INDEX", "INDIAN_FO", "INDIAN_FUTURES", "INDIAN_OPTIONS"].some((code) => selectedMarketCode.includes(code));
  const brokerMappingLabel = form.instrument_key && (isUpstox || selectedMarketCode.includes("INDIAN")) ? `Instrument key: ${form.instrument_key}` : `Broker symbol: ${form.broker_symbol || form.instrument}`;

  useEffect(() => {
    const controller = new AbortController();
    const loadSymbols = async () => {
      if (!selectedBroker || isRunning || isFunded || (form.mode !== "DEMO" && form.mode !== "LIVE") || !form.broker_account_id) { setSymbolOptions([]); setSymbolLoadError(null); return; }
      try {
        setLoadingSymbols(true);
        setSymbolLoadError(null);
        const provider = (selectedBroker?.broker_code || selectedBroker?.broker_name || "").toUpperCase();
        // TradeLocker needs the ENTIRE connected-account catalogue, not only
        // the previous instrument's prefix. Keep other broker UIs unchanged.
        const tradeLocker = provider === "TRADELOCKER";
        const query = tradeLocker ? "" : (form.instrument ? form.instrument.replace(/m$/i, "").slice(0, 6) : "");
        const rows = await liveTradingApi.listBrokerSymbols(form.broker_account_id, query, tradeLocker ? 5000 : 200, controller.signal);
        if (controller.signal.aborted) return;
        const usable = rows.filter((row) => row?.symbol && row.success !== false);
        setSymbolOptions(usable);
        if (tradeLocker && !usable.length) setSymbolLoadError("The selected TradeLocker account did not return any broker instruments.");
      } catch (error: any) {
        if (controller.signal.aborted) return;
        setSymbolOptions([]);
        setSymbolLoadError(String(error?.message || "Could not fetch instruments from broker"));
      } finally { if (!controller.signal.aborted) setLoadingSymbols(false); }
    };
    loadSymbols();
    return () => controller.abort();
  }, [form.mode, form.broker_account_id, selectedBroker, isRunning, isFunded]);

  useEffect(() => () => compatibilityController.current?.abort(), [deploymentId]);

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    const load = async () => {
      setLoading(true);
      setLoadError(null);
      try {
        const row = await liveTradingApi.getDeployment(deploymentId, { signal: controller.signal });
        if (!active) return;
        original.current = row;
        setDeploymentStatus(row.status);
        setRuntimeLoaded(false);
        liveTradingApi.getDeploymentRuntimeSettings(deploymentId).then((config) => {
          if (!active) return;
          setForm((current) => ({ ...current,
            sl_mode: config.sl_tp?.sl_mode || current.sl_mode,
            atr_period: Number(config.sl_tp?.atr_period ?? current.atr_period),
            atr_multiplier: Number(config.sl_tp?.atr_multiplier ?? current.atr_multiplier),
            swing_lookback: Number(config.sl_tp?.swing_lookback ?? current.swing_lookback),
            break_even_enabled: Boolean(config.trade_management?.break_even_enabled),
            break_even_trigger_r: Number(config.trade_management?.break_even_trigger_r ?? current.break_even_trigger_r),
            trailing_enabled: Boolean(config.trade_management?.trailing_enabled),
            trailing_mode: config.trade_management?.trailing_mode || current.trailing_mode,
            trail_start_r: Number(config.trade_management?.trail_start_r ?? current.trail_start_r),
            trail_atr_multiplier: Number(config.trade_management?.trail_atr_multiplier ?? current.trail_atr_multiplier),
          }));
          setRuntimeLoaded(true);
        }).catch(() => { if (active) showToast("Strategy runtime settings unavailable. Configuration remains editable; preview is disabled until refresh.", "warning"); });
        const loadedFunded = row.account_policy_type === "FUNDED" ? {
          account_policy_type: "FUNDED", risk_mode: row.funded_risk_mode,
          fixed_risk_pct: row.funded_fixed_risk_pct, safety_buffer_pct: row.funded_safety_buffer_pct,
          configured_max_risk_pct: row.funded_configured_max_risk_pct,
          risk_plan: (row as any).funded_risk_plan_snapshot,
        } as FundedLiveStatus : null;
        if (loadedFunded && "account_policy_type" in loadedFunded && loadedFunded.account_policy_type === "FUNDED") {
          setFundedStatus(loadedFunded as FundedLiveStatus);
          setFundedRiskMode(String((loadedFunded as FundedLiveStatus).risk_mode || row.funded_risk_mode || "DYNAMIC").toUpperCase() === "FIXED" ? "FIXED" : "DYNAMIC");
          setFundedFixedRiskPct(Number((loadedFunded as FundedLiveStatus).fixed_risk_pct ?? row.funded_fixed_risk_pct ?? 0.01));
          setFundedSafetyBufferPct(Number((loadedFunded as FundedLiveStatus).safety_buffer_pct ?? row.funded_safety_buffer_pct ?? 0.05));
          const maxRisk = (loadedFunded as FundedLiveStatus).configured_max_risk_pct ?? row.funded_configured_max_risk_pct;
          setFundedConfiguredMaxRiskPct(maxRisk === null || maxRisk === undefined ? null : Number(maxRisk));
          const plan = (loadedFunded as FundedLiveStatus).risk_plan;
          setFundedTiers(Array.isArray(plan) ? plan.map((tier: any, index: number) => ({
            id: tier.id || null, name: tier.name || `Tier ${index + 1}`, sort_order: Number(tier.sort_order ?? tier.sequence ?? index),
            min_account_return_pct: tier.min_account_return_pct === null || tier.min_account_return_pct === undefined ? null : Number(tier.min_account_return_pct),
            max_account_return_pct: tier.max_account_return_pct === null || tier.max_account_return_pct === undefined ? null : Number(tier.max_account_return_pct),
            risk_percent: Number(tier.risk_percent ?? tier.risk_pct ?? 0.01), is_active: tier.is_active !== false,
          })) : []);
        } else setFundedStatus(null);
        setPhaseAdvanceBrokerId(row.broker_account_id || "");
        setInitialRouting({ broker_account_id: row.broker_account_id || "", instrument: normalizeSymbol(row.instrument), broker_symbol: normalizeSymbol(row.broker_symbol) });
        setForm((prev) => {
          const loadedForm: FormState = { ...prev,
          name: row.name, instrument: row.instrument, timeframe: row.timeframe, mode: (row.mode === "LIVE" ? "LIVE" : row.mode === "DEMO" ? "DEMO" : "PAPER"), broker_account_id: row.broker_account_id || "",
          capital: Number(row.capital), risk_per_trade: Number(row.risk_per_trade), rr_ratio: Number(row.rr_ratio), price_risk_pct: Number(row.price_risk_pct),
          max_daily_loss: row.max_daily_loss == null ? null : Number(row.max_daily_loss), max_trades_per_day: row.max_trades_per_day == null ? null : Number(row.max_trades_per_day), max_open_positions: Number(row.max_open_positions), partial_exit_enabled: Boolean(row.partial_exit_enabled), partial_exit_at_r: Number(row.partial_exit_at_r ?? 1.7), partial_exit_percent: Number(row.partial_exit_percent ?? 0.9),
          allow_short: Boolean(row.allow_short), auto_trade_enabled: Boolean(row.auto_trade_enabled), auto_runner_enabled: Boolean(row.auto_runner_enabled), mt5_demo_max_lot: row.mt5_demo_max_lot == null ? null : Number(row.mt5_demo_max_lot),
          broker_symbol: row.broker_symbol || "", instrument_key: row.instrument_key || "", exchange: row.exchange || "NSE_EQ", segment: row.segment || "EQ", product_type: row.product_type || "MIS",
          order_variety: row.order_variety || "REGULAR", quantity_mode: row.quantity_mode || "FIXED_QTY", fixed_quantity: Number(row.fixed_quantity ?? 1), max_quantity: Number(row.max_quantity ?? 1),
          max_order_value: Number(row.max_order_value ?? 5000), square_off_time: row.square_off_time || "15:15", upstox_order_confirmed: Boolean(row.upstox_order_confirmed),
          copy_trading_enabled: Boolean(row.copy_trading_enabled), copy_broker_account_ids: Array.isArray(row.copy_broker_account_ids) ? row.copy_broker_account_ids.map(String) : [],
          };
          initialEditable.current = { ...loadedForm };
          return loadedForm;
        });
      } catch (error: any) {
        if (active) setLoadError(error.message || "Failed to load settings");
      } finally { if (active) setLoading(false); }
    };
    if (deploymentId) load();
    return () => { active = false; controller.abort(); };
  }, [deploymentId, loadVersion]);

  // Optional reference data never holds the configuration form behind a spinner.
  useEffect(() => {
    let active = true;
    if (!deploymentId) return;
    liveTradingApi.listBrokerAccounts().then((rows) => { if (active) setBrokers(rows); })
      .catch((error) => { if (active) showToast(`Broker accounts: ${error.message}`, "error"); });
    liveTradingApi.listMarketInstruments().then((rows) => { if (active) setMarketInstruments(rows); })
      .catch((error) => { if (active) showToast(`Instrument reference: ${error.message}`, "warning"); });
    liveTradingApi.getDeploymentSummary(deploymentId, { refreshBroker: false }).then((row) => {
      if (active) { setSummary(row); if (row.funded) setFundedStatus(row.funded as FundedLiveStatus); }
    }).catch(() => { /* Capital/position diagnostics are optional, not editable configuration. */ });
    return () => { active = false; };
  }, [deploymentId, loadVersion]);

  const runCompatibility = async () => {
    if (!deploymentId) return;
    compatibilityController.current?.abort();
    const controller = new AbortController();
    compatibilityController.current = controller;
    try {
      setCompatBusy(true);
      const result = await liveTradingApi.runCompatibilityCheck(deploymentId, controller.signal);
      setCompatibility(result);
      showToast(result.summary || "Live compatibility checked", result.status === "FAIL" ? "error" : result.status === "WARNING" ? "warning" : "success");
    } catch (error: any) {
      if (!controller.signal.aborted) showToast(error.message || "Compatibility check failed", "error");
    } finally {
      setCompatBusy(false);
    }
  };

  const runtimeConfig = () => ({
    risk: {
      initial_capital: Number(effectiveCapital || form.capital),
      risk_percent: Number(form.risk_per_trade),
      position_size_mode: form.quantity_mode === "RISK_BASED" ? "RISK_BASED" : "FIXED_QUANTITY",
      fixed_quantity: Number(form.fixed_quantity),
      max_lot_cap: form.mt5_demo_max_lot == null ? null : Number(form.mt5_demo_max_lot),
      max_quantity_cap: form.max_quantity ? Number(form.max_quantity) : null,
    },
    sl_tp: { rr_ratio: Number(form.rr_ratio), sl_mode: form.sl_mode, atr_period: Number(form.atr_period), atr_multiplier: Number(form.atr_multiplier), swing_lookback: Number(form.swing_lookback), fixed_price_risk_pct: Number(form.price_risk_pct) },
    execution: { entry_mode: "NEXT_CANDLE_OPEN", exit_on_opposite_signal: false, allow_long: true, allow_short: Boolean(form.allow_short), max_trades_per_day: form.max_trades_per_day == null ? null : Number(form.max_trades_per_day), max_open_positions: Number(form.max_open_positions), intraday_square_off: supportsLiveSquareOff, square_off_time: form.square_off_time },
    trade_management: { break_even_enabled: form.break_even_enabled, break_even_trigger_r: form.break_even_trigger_r, trailing_enabled: form.trailing_enabled, trailing_mode: form.trailing_mode, trail_start_r: form.trail_start_r, trail_atr_multiplier: form.trail_atr_multiplier, partial_exit_enabled: form.partial_exit_enabled, partial_exit_at_r: form.partial_exit_at_r, partial_exit_percent: form.partial_exit_percent },
    strategy_params: {},
  });

  const updateLiveRuntimeSection = (section: string, key: string, value: any) => {
    if (section === "risk") {
      if (key === "initial_capital") setForm((prev) => ({ ...prev, capital: Number(value) }));
      else if (key === "risk_percent") setForm((prev) => ({ ...prev, risk_per_trade: Number(value) }));
      else if (key === "position_size_mode") {
        if (value === "FIXED_LOT") { showToast("Fixed Lot cannot be saved by this deployment API. Use Risk Based or Fixed Quantity.", "warning"); return; }
        setForm((prev) => ({ ...prev, quantity_mode: value === "RISK_BASED" ? "RISK_BASED" : "FIXED_QTY" }));
      }
      else if (key === "fixed_quantity") setForm((prev) => ({ ...prev, fixed_quantity: Number(value || 0) }));
      else if (key === "max_lot_cap") setForm((prev) => ({ ...prev, mt5_demo_max_lot: value == null || value === "" ? null : Number(value) }));
      else if (key === "max_quantity_cap") setForm((prev) => ({ ...prev, max_quantity: Number(value || 0) }));
    } else if (section === "sl_tp") {
      const map: Record<string, keyof FormState> = { rr_ratio: "rr_ratio", sl_mode: "sl_mode", atr_period: "atr_period", atr_multiplier: "atr_multiplier", swing_lookback: "swing_lookback", fixed_price_risk_pct: "price_risk_pct" };
      const target = map[key];
      if (target) setForm((prev) => ({ ...prev, [target]: key === "sl_mode" ? value : Number(value) }));
    } else if (section === "execution") {
      if (key === "max_trades_per_day") setForm((prev) => ({ ...prev, max_trades_per_day: value == null || value === "" ? null : Number(value) }));
      else {
        const map: Record<string, keyof FormState> = { allow_short: "allow_short", max_open_positions: "max_open_positions", square_off_time: "square_off_time" };
        const target = map[key];
        if (target) setForm((prev) => ({ ...prev, [target]: typeof prev[target] === "boolean" ? Boolean(value) : key === "square_off_time" ? value : Number(value || 0) }));
      }
    } else if (section === "trade_management") {
      const map: Record<string, keyof FormState> = { break_even_enabled: "break_even_enabled", break_even_trigger_r: "break_even_trigger_r", trailing_enabled: "trailing_enabled", trailing_mode: "trailing_mode", trail_start_r: "trail_start_r", trail_atr_multiplier: "trail_atr_multiplier", partial_exit_enabled: "partial_exit_enabled", partial_exit_at_r: "partial_exit_at_r", partial_exit_percent: "partial_exit_percent" };
      const target = map[key];
      if (target) setForm((prev) => ({ ...prev, [target]: typeof prev[target] === "boolean" ? Boolean(value) : key === "trailing_mode" ? value : Number(value) }));
    }
  };

  const runPreview = async (mode: "AUTO_LATEST_PRICE" | "MANUAL") => {
    if (!runtimeLoaded) { showToast("Wait for strategy runtime settings or refresh before previewing.", "warning"); return; }
    try {
      setPreviewLoading(true);
      const result = await liveTradingApi.previewLiveOrder({
        deployment_id: deploymentId, symbol: form.instrument, side: mode === "MANUAL" ? manualSide : "BUY", mode,
        entry_price: mode === "MANUAL" ? Number(manualEntry) : undefined, stop_loss: mode === "MANUAL" ? Number(manualSL) : undefined, runtime_config: runtimeConfig(),
      });
      setRiskPreview(result as LiveOrderPreview);
      if ((result as LiveOrderPreview).validation_status === "OK") showToast("Order preview passed", "success");
      else showToast((result as LiveOrderPreview).reason || ((result as LiveOrderPreview).missing_fields?.length ? "Instrument not ready" : ((result as LiveOrderPreview).rejected_reason || "Order preview rejected")), "error");
    } catch (error: any) { showToast(error?.message || "Order preview failed", "error"); } finally { setPreviewLoading(false); }
  };

  const validateBeforeSave = () => {
    if (isPaperDeprecated) return "PAPER deployment is deprecated. Please create a DEMO or LIVE broker deployment.";
    if (!isFunded && (form.risk_per_trade <= 0 || form.risk_per_trade > 0.10)) return "Risk per trade must be greater than 0% and not more than 10%.";
    if (!isFunded && form.risk_per_trade > 0.03) return "Normal UI blocks risk above 3%. Use a lower safe risk value.";
    if (form.rr_ratio <= 0) return "RR ratio must be greater than 0.";
    if (form.price_risk_pct <= 0) return "Fixed price risk percent must be greater than 0.";
    if (form.max_daily_loss != null && form.max_daily_loss < 0) return "Max daily loss cannot be negative.";
    if (form.max_trades_per_day != null && form.max_trades_per_day < 1) return "Max trades per day must be at least 1 when enabled.";
    if (form.partial_exit_enabled && form.partial_exit_at_r <= 0) return "Partial exit trigger R must be greater than 0.";
    if (form.partial_exit_enabled && (form.partial_exit_percent <= 0 || form.partial_exit_percent >= 1)) return "Partial exit percent must be greater than 0% and less than 100%.";
    if (form.max_open_positions < 1) return "Max open positions must be at least 1.";
    if (form.mt5_demo_max_lot != null && form.mt5_demo_max_lot <= 0) return "Broker max lot must be greater than 0 when enabled.";
    if ((form.mode === "DEMO" || form.mode === "LIVE") && !form.broker_account_id) return "Broker account is required for DEMO and LIVE.";
    return null;
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const error = validateBeforeSave();
    if (error) { showToast(error, "error"); return; }
    try {
      setSaving(true);
      const routingChanged = String(form.broker_account_id || "") !== String(initialRouting.broker_account_id || "") || normalizeSymbol(form.instrument) !== normalizeSymbol(initialRouting.instrument) || (isTradeLocker && normalizeSymbol(form.broker_symbol) !== normalizeSymbol(initialRouting.broker_symbol));
      if (isTradeLocker && routingChanged && (!selectedBrokerSymbol || normalizeSymbol(selectedBrokerSymbol.symbol) !== normalizeSymbol(form.broker_symbol))) {
        showToast("Select an exact symbol fetched from the connected TradeLocker account before saving.", "error");
        return;
      }
      const candidate = {
        name: form.name, mode: form.mode, broker_account_id: form.broker_account_id || null, instrument: normalizeSymbol(form.instrument), timeframe: form.timeframe,
        ...(isTradeLocker && routingChanged ? { broker_symbol: normalizeSymbol(form.broker_symbol), instrument_key: normalizeSymbol(form.broker_symbol) }
           : routingChanged ? { broker_symbol: null, instrument_key: null, exchange: null, segment: null } : {}),
        risk_per_trade: form.risk_per_trade, rr_ratio: form.rr_ratio, price_risk_pct: form.price_risk_pct, max_daily_loss: form.max_daily_loss,
        max_trades_per_day: form.max_trades_per_day, max_open_positions: form.max_open_positions, allow_short: form.allow_short, auto_trade_enabled: form.auto_trade_enabled, partial_exit_enabled: form.partial_exit_enabled, partial_exit_at_r: form.partial_exit_at_r, partial_exit_percent: form.partial_exit_percent,
        auto_runner_enabled: form.auto_runner_enabled, copy_trading_enabled: form.copy_trading_enabled, copy_broker_account_ids: form.copy_broker_account_ids, mt5_demo_max_lot: form.mt5_demo_max_lot,
        product_type: form.product_type, order_variety: form.order_variety, quantity_mode: form.quantity_mode, fixed_quantity: form.fixed_quantity,
        max_quantity: form.max_quantity, max_order_value: form.max_order_value, square_off_time: form.square_off_time, upstox_order_confirmed: form.upstox_order_confirmed,
      };
      // PATCH only user changes: do not overwrite concurrent runner/config state
      // or revalidate unchanged broker routing on a name/copy-target edit.
      const changes = Object.fromEntries(Object.entries(candidate).filter(([key, value]) => {
        const mappingField = ["broker_symbol", "instrument_key", "exchange", "segment"].includes(key);
        if (!(routingChanged && mappingField) && key in form && JSON.stringify(form[key as keyof FormState]) === JSON.stringify(initialEditable.current[key])) return false;
        const previous = original.current?.[key];
        if (Array.isArray(value)) return JSON.stringify(value) !== JSON.stringify(previous || []);
        if (value == null || previous == null) return value != previous;
        if (typeof value === "number") return Number(previous) !== value;
        return String(previous) !== String(value);
      }));
      const updated = await liveTradingApi.updateDeployment(deploymentId, changes);
      original.current = updated;
      initialEditable.current = { ...form };
      setDeploymentStatus(updated.status);
      setInitialRouting({ broker_account_id: updated.broker_account_id || "", instrument: normalizeSymbol(updated.instrument), broker_symbol: normalizeSymbol(updated.broker_symbol) });
      setCompatibility(null);
      showToast("Deployment settings updated", "success");
    } catch (error: any) {
      showToast(error.code === "ECONNABORTED" ? "Save timed out; the result is unknown. Refresh settings before retrying to confirm whether it saved." : error.message || "Failed to update settings", "error");
    } finally { setSaving(false); }
  };

  const saveFundedRiskPlan = async () => {
    if (!isFunded) return;
    if (fundedRiskLocked) { showToast("Pause/stop the deployment and close all positions before changing funded risk policy.", "error"); return; }
    if (fundedRiskMode === "FIXED" && (fundedFixedRiskPct <= 0 || fundedFixedRiskPct > 0.10)) { showToast("Fixed funded risk must be greater than 0% and not more than 10%.", "error"); return; }
    try {
      setFundedSaving(true);
      const updated = await liveTradingApi.updateFundedRiskPlan(deploymentId, {
        risk_mode: fundedRiskMode,
        fixed_risk_pct: fundedRiskMode === "FIXED" ? fundedFixedRiskPct : null,
        safety_buffer_pct: fundedSafetyBufferPct,
        configured_max_risk_pct: fundedConfiguredMaxRiskPct,
        risk_tiers: fundedRiskMode === "DYNAMIC" ? fundedTiers : [],
      });
      setFundedStatus(updated);
      showToast("Funded risk plan updated", "success");
    } catch (error: any) { showToast(error?.message || "Failed to update funded risk plan", "error"); } finally { setFundedSaving(false); }
  };

  const advanceFundedPhase = async () => {
    if (!isFunded || !["PASS_READY", "AWAITING_PROVIDER_TRANSITION"].includes(String(fundedStatus?.guard?.status || "").toUpperCase())) return;
    if (fundedRiskLocked) { showToast("Pause/stop the deployment and close all positions before advancing the funded phase.", "error"); return; }
    const ok = window.confirm("Advance to the next funded provider phase? AlgoAgentX will revalidate the selected broker account and create fresh funded runtime state. This does not change the broker login automatically unless you select another connected account.");
    if (!ok) return;
    try {
      setPhaseAdvanceBusy(true);
      const updated = await liveTradingApi.advanceFundedPhase(deploymentId, { broker_account_id: phaseAdvanceBrokerId || null, confirm: true });
      setFundedStatus(updated);
      showToast("Funded phase advanced. Run a fresh readiness check before starting.", "success");
    } catch (error: any) { showToast(error?.message || "Failed to advance funded phase", "error"); } finally { setPhaseAdvanceBusy(false); }
  };

  const LockedNote = () => <div className="rounded-xl border border-cyan-300/25 bg-cyan-400/10 p-4 text-sm text-cyan-100"><Lock className="mr-2 inline h-4 w-4" />Mode, broker account, instrument, and timeframe can be changed for a stopped STANDARD deployment. {isRunning && <span className="ml-1 text-amber-100">Stop this deployment first to edit routing/candle settings safely.</span>} {isFunded && <span className="ml-1 text-amber-100">Funded routing remains protected and uses the funded workflow.</span>} <Link className="ml-2 underline" href={`/live-trading/new?clone=${deploymentId}`}><Copy className="mr-1 inline h-4 w-4" />Clone Deployment</Link></div>;

  return (
    <PageShell>
      <PageHeader title="Safe Deployment Settings" subtitle="Beginner-safe presets, guarded risk settings, and automatic order preview before auto trading." actions={<Link href={`/live-trading/${deploymentId}`}><Button variant="outline" className="gap-2 border-white/10 bg-white/5 text-white hover:bg-white/10"><ArrowLeft className="h-4 w-4" />Back</Button></Link>} />
      <GlassCard className="p-6" hoverEffect={false}>
        {loading ? <p role="status" className="text-muted-foreground">Loading settings...</p> : loadError ? (
          <div role="alert" className="space-y-4 text-foreground"><p>{loadError}</p><Button type="button" onClick={() => setLoadVersion((value) => value + 1)}>Retry loading settings</Button></div>
        ) : (
          <form onSubmit={submit} className="space-y-6">
            <LiveCompatibilityCard result={compatibility} loading={compatBusy} onRun={runCompatibility} compact />
            <LockedNote />
            {isPaperDeprecated && <div className="rounded-xl border border-amber-300/25 bg-amber-400/10 p-4 text-sm text-amber-100"><ShieldCheck className="mr-2 inline h-4 w-4" />PAPER deployment is deprecated. Settings are read-only for broker-only workflow. <Link className="ml-2 underline" href="/live-trading/new">Create Broker Deployment</Link></div>}
            <div className="rounded-xl border border-lime-300/20 bg-lime-300/10 p-4 text-sm text-lime-100"><ShieldCheck className="mr-2 inline h-4 w-4" />Beginner Safe Mode is ON by default. DEMO and LIVE use approved connected broker accounts. Risk is calculated from broker balance/equity.</div>

            <div className="rounded-2xl border border-cyan-300/20 bg-cyan-300/10 p-5 text-sm text-cyan-50">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"><div><h3 className="text-base font-black text-white">Auto Order Preview</h3><p className="mt-1 text-xs text-cyan-100">Uses latest closed candle, selected SL mode, RR, Instrument Master, and risk engine. No real order is placed.</p></div><Button type="button" disabled={previewLoading} onClick={() => runPreview("AUTO_LATEST_PRICE")} className="border-0 bg-cyan-400 text-slate-950 hover:bg-cyan-300">{previewLoading ? "Previewing..." : "Auto Preview from Latest Price"}</Button></div>
              {riskPreview && <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Status</p><p className={riskPreview.validation_status === "OK" ? "font-bold text-lime-200" : "font-bold text-rose-200"}>{riskPreview.validation_status || "—"}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Latest Price</p><p className="font-bold text-white">{riskPreview.latest_price ?? riskPreview.entry_price ?? "—"}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">SL / TP</p><p className="font-bold text-white">{riskPreview.stop_loss ?? "—"} / {riskPreview.target ?? "—"}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Risk</p><p className="font-bold text-white">{money(riskPreview.actual_risk_amount ?? riskPreview.risk_amount, riskPreview.account_currency || currency)}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Reward</p><p className="font-bold text-white">{riskPreview.expected_reward_amount != null ? money(riskPreview.expected_reward_amount, riskPreview.account_currency || currency) : "—"}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Lot / Qty</p><p className="font-bold text-white">{riskPreview.quantity_mode === "LOTS" ? `${riskPreview.final_lot_size ?? "—"} lots` : `${riskPreview.final_quantity ?? "—"} qty`}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Broker Symbol</p><p className="truncate font-bold text-white">{riskPreview.broker_symbol || (riskPreview.broker_order_payload_preview as any)?.symbol || "—"}</p></div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-cyan-200">Payload</p><p className="truncate font-bold text-white">{riskPreview.quantity_mode === "LOTS" ? `volume=${(riskPreview.broker_order_payload_preview as any)?.volume ?? "—"}` : `qty=${(riskPreview.broker_order_payload_preview as any)?.quantity ?? "—"}`}</p></div>
              </div>}
              {riskPreview?.validation_status === "REJECTED" && <div className="mt-3 rounded-xl border border-rose-300/20 bg-rose-500/10 p-3 text-rose-100"><p className="font-bold">{riskPreview.reason || "Instrument not ready"}</p><p className="mt-1 text-xs">{riskPreview.instrument_not_ready_message || riskPreview.rejected_reason || "Review the Instrument Readiness card below before previewing again."}</p></div>}
              <button type="button" onClick={() => setAdvancedPreview((v) => !v)} className="mt-4 text-xs font-bold text-cyan-100 underline">{advancedPreview ? "Hide" : "Show"} Advanced Manual Preview</button>
              {advancedPreview && <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-4"><FieldShell label="Side"><SelectBox value={manualSide} onChange={(e) => setManualSide(e.target.value as "BUY" | "SELL")}><option value="BUY">BUY</option><option value="SELL">SELL</option></SelectBox></FieldShell><FieldShell label="Manual Entry"><InputBox type="number" step="0.01" value={manualEntry} onChange={(e) => setManualEntry(Number(e.target.value))} /></FieldShell><FieldShell label="Manual Stop Loss"><InputBox type="number" step="0.01" value={manualSL} onChange={(e) => setManualSL(Number(e.target.value))} /></FieldShell><Button type="button" disabled={previewLoading} onClick={() => runPreview("MANUAL")} className="mt-7 bg-white/10 text-white hover:bg-white/20">Preview Manual</Button></div>}
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                <div><h3 className="font-black text-white">Instrument Readiness</h3><p className="mt-1 text-xs text-purple-200">Use this card to confirm the symbol is saved and complete in Market Master before DEMO/LIVE trading.</p></div>
                <Link href="/admin/market-data" className="text-xs font-bold text-cyan-100 underline">Open Market Master</Link>
              </div>
              {instrumentReadiness.fallbackNotice && <p className="mt-3 rounded-xl border border-amber-300/20 bg-amber-400/10 p-3 text-xs text-amber-100">{instrumentReadiness.fallbackNotice}</p>}
              <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8 text-sm">
                <Info label="Instrument" value={form.instrument} />
                <Info label="Source" value={instrumentReadiness.source} />
                <Info label="Instrument ID" value={displayValue(instrumentSpec.id)} />
                <Info label="Asset Class" value={displayValue(instrumentSpec.asset_class)} />
                <Info label="Account Currency" value={displayValue(instrumentSpec.account_currency)} />
                <Info label="Currency Symbol" value={displayValue(instrumentSpec.currency_symbol)} />
                <Info label="Qty Mode" value={displayValue(instrumentSpec.quantity_mode)} />
                <Info label="Broker Symbol" value={displayValue(instrumentSpec.broker_symbol)} />
                <Info label="Tick Size" value={displayValue(instrumentSpec.tick_size)} />
                <Info label="Tick Value / Lot" value={displayValue(instrumentSpec.tick_value_per_lot)} />
                <Info label="Lot Step / Min Lot" value={`${displayValue(instrumentSpec.lot_step)} / ${displayValue(instrumentSpec.min_lot)}`} />
                <Info label="Qty Step / Min Qty" value={normalizeSymbol(instrumentSpec.quantity_mode) === "LOTS" ? "N/A for LOTS" : `${displayValue(instrumentSpec.quantity_step)} / ${displayValue(instrumentSpec.min_quantity)}`} />
                <Info label="Live Enabled" value={yesNo(instrumentSpec.is_tradeable_live)} />
                <Info label="Status" value={instrumentStatus} />
              </div>
              {instrumentReadiness.missingFields.length > 0 && <div className="mt-4 rounded-xl border border-rose-300/20 bg-rose-500/10 p-4 text-sm text-rose-100"><p className="font-bold">Missing / invalid Market Master fields</p><div className="mt-2 flex flex-wrap gap-2">{instrumentReadiness.missingFields.map((field) => <span key={field} className="rounded-full bg-rose-400/15 px-2 py-1 text-xs">{field}</span>)}</div><p className="mt-3 text-xs">{instrumentReadiness.actionMessage}</p></div>}
            </div>

            <div className="rounded-2xl border border-emerald-300/20 bg-emerald-400/10 p-5">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="font-black text-white">Broker Account Capital</h3>
                  <p className="mt-1 text-xs text-emerald-100/80">Read-only balance/equity from broker sync. Risk is calculated from broker balance/equity where available.</p>
                </div>
                <span className="rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-xs font-semibold text-emerald-100">{effectiveCapitalSource || "Waiting for sync"}</span>
              </div>
              {accountMetrics ? <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
                <Info label="Currency" value={String(accountMetrics.account_currency || accountMetrics.currency || currency || "USD")} />
                <Info label="Balance" value={money(accountMetrics.balance, currency)} />
                <Info label="Equity" value={money(accountMetrics.equity, currency)} />
                <Info label="Free Margin" value={money(accountMetrics.free_margin, currency)} />
                <Info label="Effective Capital" value={money(effectiveCapital, currency)} />
                <Info label="Capital Source" value={String(effectiveCapitalSource || "—").replace(/_/g, " ")} />
              </div> : <p className="mt-4 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-emerald-50">Broker balance/equity will appear after broker sync.</p>}
            </div>

            {isFunded && fundedStatus && <div className="rounded-2xl border border-lime-300/20 bg-lime-400/10 p-5">
              <div className="flex flex-col justify-between gap-3 lg:flex-row lg:items-start">
                <div>
                  <div className="flex flex-wrap items-center gap-2"><h3 className="font-black text-white">Funded Account Guard</h3><span className="rounded-full border border-lime-300/30 bg-lime-300/10 px-3 py-1 text-xs font-bold text-lime-100">{fundedStatus.guard?.status || "NOT_INITIALIZED"}</span></div>
                  <p className="mt-1 text-xs text-lime-100/80">Prop-firm hard rules are read-only here. You may edit only this deployment's risk-plan snapshot while stopped/paused with no open positions.</p>
                  {fundedRiskLocked && <p className="mt-2 text-xs text-amber-100">Risk plan locked: stop/pause the deployment and close all positions before editing.</p>}
                </div>
                <Button type="button" disabled={fundedSaving} onClick={async () => { try { const result = await liveTradingApi.refreshFundedStatus(deploymentId); const next = (result as any)?.funded; if (next) setFundedStatus(next); showToast("Funded guard refreshed", "success"); } catch (error: any) { showToast(error?.message || "Funded refresh failed", "error"); } }} variant="outline" className="border-lime-300/20 bg-lime-300/10 text-lime-50 hover:bg-lime-300/20">Refresh Funded Guard</Button>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
                <Info label="Profile" value={fundedStatus.profile?.name || "—"} /><Info label="Provider" value={fundedStatus.profile?.provider_name || "—"} />
                <Info label="Stage" value={fundedStatus.phase_number ? `Phase ${fundedStatus.phase_number}` : "Instant"} /><Info label="Rule Timezone" value={fundedStatus.guard?.rule_timezone || "—"} />
                <Info label="Balance" value={money(fundedStatus.guard?.balance ?? fundedStatus.broker?.balance, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} /><Info label="Equity" value={money(fundedStatus.guard?.equity ?? fundedStatus.broker?.equity, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} />
                <Info label="Daily Floor" value={money(fundedStatus.guard?.daily_floor, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} /><Info label="Max DD Floor" value={money(fundedStatus.guard?.max_floor, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} />
                <Info label="Daily Remaining" value={money(fundedStatus.guard?.remaining_daily_capacity, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} /><Info label="Max DD Remaining" value={money(fundedStatus.guard?.remaining_max_capacity, fundedStatus.broker?.currency || fundedStatus.profile?.account_currency || "USD")} />
                <Info label="Risk Tier" value={fundedStatus.guard?.risk_tier || "—"} /><Info label="Effective Risk" value={fundedStatus.guard?.effective_risk_pct == null ? "—" : percent(Number(fundedStatus.guard.effective_risk_pct))} />
              </div>
              {(!fundedStatus.broker?.fresh || Number(fundedStatus.broker?.balance || 0) <= 0 || Number(fundedStatus.broker?.equity || 0) <= 0) && <div className="mt-4 rounded-xl border border-rose-300/20 bg-rose-500/10 p-3 text-sm text-rose-100">Broker funded state unavailable/incomplete. Auto entries are blocked until fresh positive broker balance and equity are synchronized. Fallback deployment capital is never used for FUNDED.</div>}
              <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-3">
                <FieldShell label="Funded Risk Mode"><SelectBox disabled={fundedRiskLocked} value={fundedRiskMode} onChange={(e) => setFundedRiskMode(e.target.value === "FIXED" ? "FIXED" : "DYNAMIC")}><option value="DYNAMIC">Dynamic Risk Ladder</option><option value="FIXED">Fixed Risk</option></SelectBox></FieldShell>
                {fundedRiskMode === "FIXED" && <FieldShell label="Fixed Risk %"><InputBox disabled={fundedRiskLocked} type="number" min="0.01" max="10" step="0.01" value={fundedFixedRiskPct * 100} onChange={(e) => setFundedFixedRiskPct(Number(e.target.value || 0) / 100)} /></FieldShell>}
                <FieldShell label="Safety Buffer %"><InputBox disabled={fundedRiskLocked} type="number" min="0" max="99" step="0.1" value={fundedSafetyBufferPct * 100} onChange={(e) => setFundedSafetyBufferPct(Number(e.target.value || 0) / 100)} /></FieldShell>
                <FieldShell label="Configured Max Risk %"><InputBox disabled={fundedRiskLocked} type="number" min="0" max="10" step="0.01" value={fundedConfiguredMaxRiskPct == null ? "" : fundedConfiguredMaxRiskPct * 100} onChange={(e) => setFundedConfiguredMaxRiskPct(e.target.value === "" ? null : Number(e.target.value) / 100)} /></FieldShell>
              </div>
              {fundedRiskMode === "DYNAMIC" && <div className="mt-5 space-y-3">
                <p className="text-xs font-bold uppercase tracking-wide text-lime-100">Deployment Risk Ladder</p>
                {fundedTiers.map((tier, index) => <div key={tier.id || index} className="grid grid-cols-1 gap-3 rounded-xl border border-white/10 bg-white/5 p-3 md:grid-cols-5">
                  <InputBox disabled={fundedRiskLocked} value={tier.name} onChange={(e) => setFundedTiers((rows) => rows.map((row, i) => i === index ? { ...row, name: e.target.value } : row))} />
                  <InputBox disabled={fundedRiskLocked} type="number" step="0.01" placeholder="Min return % / blank" value={tier.min_account_return_pct == null ? "" : Number(tier.min_account_return_pct) * 100} onChange={(e) => setFundedTiers((rows) => rows.map((row, i) => i === index ? { ...row, min_account_return_pct: e.target.value === "" ? null : Number(e.target.value) / 100 } : row))} />
                  <InputBox disabled={fundedRiskLocked} type="number" step="0.01" placeholder="Max return % / blank" value={tier.max_account_return_pct == null ? "" : Number(tier.max_account_return_pct) * 100} onChange={(e) => setFundedTiers((rows) => rows.map((row, i) => i === index ? { ...row, max_account_return_pct: e.target.value === "" ? null : Number(e.target.value) / 100 } : row))} />
                  <InputBox disabled={fundedRiskLocked} type="number" step="0.01" min="0.01" max="10" value={Number(tier.risk_percent) * 100} onChange={(e) => setFundedTiers((rows) => rows.map((row, i) => i === index ? { ...row, risk_percent: Number(e.target.value || 0) / 100 } : row))} />
                  <label className="flex items-center gap-2 text-xs text-purple-100"><input disabled={fundedRiskLocked} type="checkbox" checked={tier.is_active} onChange={(e) => setFundedTiers((rows) => rows.map((row, i) => i === index ? { ...row, is_active: e.target.checked } : row))} />Active · Tier {index + 1}</label>
                </div>)}
                <p className="text-xs text-purple-200">Columns: name · min account return % · max account return % · risk % · active. Blank first min and blank last max are preserved as open bounds.</p>
              </div>}
              <div className="mt-4 flex flex-wrap gap-2"><Button type="button" disabled={fundedSaving || fundedRiskLocked} onClick={saveFundedRiskPlan} className="bg-lime-400 text-slate-950 hover:bg-lime-300">{fundedSaving ? "Saving Funded Risk..." : "Save Funded Risk Plan"}</Button></div>
              {["PASS_READY", "AWAITING_PROVIDER_TRANSITION"].includes(String(fundedStatus.guard?.status || "").toUpperCase()) && <div className="mt-5 rounded-xl border border-cyan-300/20 bg-cyan-400/10 p-4">
                <p className="text-sm font-bold text-cyan-50">Provider phase transition required</p>
                <p className="mt-1 text-xs text-cyan-100/80">AlgoAgentX will not auto-advance a funded phase. Select the current/new provider account, then explicitly advance after the provider issues or confirms the next phase.</p>
                <div className="mt-3 grid gap-3 md:grid-cols-[1fr_auto]">
                  <SelectBox disabled={fundedRiskLocked || phaseAdvanceBusy} value={phaseAdvanceBrokerId} onChange={(e) => setPhaseAdvanceBrokerId(e.target.value)}>
                    {connectedBrokers.filter((broker) => String(broker.mode || "").toUpperCase() === String(form.mode || "").toUpperCase()).map((broker) => <option key={broker.id} value={broker.id}>{broker.broker_code || broker.broker_name} • {broker.account_label || "Account"} • {broker.login_id || broker.server_name || "—"}</option>)}
                  </SelectBox>
                  <Button type="button" disabled={fundedRiskLocked || phaseAdvanceBusy || !phaseAdvanceBrokerId} onClick={advanceFundedPhase} className="bg-cyan-300 text-slate-950 hover:bg-cyan-200">{phaseAdvanceBusy ? "Advancing..." : "Advance Funded Phase"}</Button>
                </div>
              </div>}
            </div>}

            <div className="rounded-2xl border border-white/10 bg-white/5 p-5"><div className="flex items-center justify-between gap-3"><div><h3 className="font-black text-white">Beginner Safe Mode</h3><p className="text-xs text-purple-200">Safe dropdowns prevent invalid values. Advanced custom inputs stay collapsed.</p></div><Button type="button" variant="outline" onClick={() => setAdvancedMode((v) => !v)} className="border-white/10 bg-white/5 text-white hover:bg-white/10">{advancedMode ? "Hide Advanced" : "Advanced Mode"}</Button></div>
              <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                <FieldShell label="Name"><InputBox value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></FieldShell>
                <FieldShell label="Mode" hint={isPaperDeprecated ? "PAPER deployment is deprecated. Create a broker deployment instead." : isRunning ? "Stop the deployment before changing mode." : isFunded ? "Funded deployment mode remains protected." : "You can change the broker environment while the deployment is stopped."}><SelectBox disabled={isRunning || isFunded} value={form.mode} onChange={(e) => { const mode = e.target.value as FormState["mode"]; const currentBroker = brokers.find((broker) => broker.id === form.broker_account_id); setForm((prev) => ({ ...prev, mode, broker_account_id: currentBroker && currentBroker.mode === mode ? prev.broker_account_id : "", copy_broker_account_ids: prev.copy_broker_account_ids.filter((id) => brokers.find((broker) => broker.id === id)?.mode === mode) })); }}>{isPaperDeprecated && <option value="PAPER">PAPER Deprecated</option>}<option value="DEMO">DEMO / Broker</option><option value="LIVE">LIVE / Broker</option></SelectBox></FieldShell>
                <FieldShell label="Broker Account" hint={isRunning ? "Stop the deployment before changing the primary broker account." : isFunded ? "Funded broker changes use the funded phase workflow." : "You can switch the primary connected broker account while the deployment is stopped."}><SelectBox disabled={isRunning || isFunded} value={form.broker_account_id} onChange={(e) => setForm((prev) => ({ ...prev, broker_account_id: e.target.value, copy_broker_account_ids: prev.copy_broker_account_ids.filter((id) => id !== e.target.value) }))}><option value="">Select connected broker account</option>{connectedBrokers.filter((broker) => broker.mode === form.mode).map((broker) => <option key={broker.id} value={broker.id}>{broker.broker_code || broker.broker_name} • {broker.account_label} • {broker.mode} • {broker.status} • {broker.login_id || broker.server_name || "—"}</option>)}</SelectBox></FieldShell>
                <FieldShell label="Instrument" hint={isRunning ? "Stop the deployment before changing instrument." : isFunded ? "Funded deployment instrument remains protected." : "You can change the deployment instrument while it is stopped."}><SelectBox disabled={isRunning || isFunded || (isTradeLocker && loadingSymbols)} value={normalizeSymbol(isTradeLocker ? form.broker_symbol || form.instrument : form.instrument)} onChange={(e) => {
                  const value = normalizeSymbol(e.target.value);
                  if (isTradeLocker) {
                    const master = masterForBrokerSymbol(value, marketInstruments);
                    setForm((prev) => ({ ...prev, instrument: normalizeSymbol(master?.symbol || value), broker_symbol: value, instrument_key: value }));
                  } else setForm((prev) => ({ ...prev, instrument: value }));
                }}>{instrumentOptions.length ? instrumentOptions.map((option) => <option key={option.key} value={option.value}>{option.label}</option>) : <option value={normalizeSymbol(isTradeLocker ? form.broker_symbol || form.instrument : form.instrument)}>{loadingSymbols ? "Loading broker instruments..." : (form.instrument || "Selected symbol")}</option>}</SelectBox><p className="mt-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs text-purple-100">{brokerMappingLabel}{isTradeLocker && !selectedBrokerSymbol ? " · Symbol not confirmed by selected broker" : ""}</p>{isTradeLocker && symbolLoadError && <p className="mt-2 text-xs text-rose-200">{symbolLoadError}</p>}</FieldShell>
                <FieldShell label="Timeframe" hint={isRunning ? "Stop the deployment before changing timeframe." : isFunded ? "Funded deployment timeframe remains protected." : "You can change the candle timeframe while the deployment is stopped."}><SelectBox disabled={isRunning || isFunded} value={form.timeframe} onChange={(e) => setForm((prev) => ({ ...prev, timeframe: e.target.value }))}>{[...new Set([form.timeframe, ...(isUpstox ? UPSTOX_TIMEFRAME_OPTIONS : TIMEFRAME_OPTIONS)])].filter(Boolean).map((tf) => <option key={tf} value={tf}>{tf}</option>)}</SelectBox></FieldShell>
                {!isFunded && <FieldShell label="Risk per Trade" hint={form.risk_per_trade > 0.02 ? "Warning: above 2% is aggressive." : "Default recommended: 1%."}><SelectBox value={selectValue(form.risk_per_trade, RISK_OPTIONS)} onChange={(e) => e.target.value !== "CUSTOM" ? setForm({ ...form, risk_per_trade: Number(e.target.value) }) : setAdvancedMode(true)}>{RISK_OPTIONS.map((value) => <option key={value} value={value}>{percent(value)}</option>)}<option value="CUSTOM">Custom Advanced</option></SelectBox>{advancedMode && selectValue(form.risk_per_trade, RISK_OPTIONS) === "CUSTOM" && <InputBox type="number" step="0.001" max="0.10" value={form.risk_per_trade} onChange={(e) => setForm({ ...form, risk_per_trade: Number(e.target.value) })} />}</FieldShell>}
                <FieldShell label="RR Ratio"><SelectBox value={form.rr_ratio} onChange={(e) => setForm({ ...form, rr_ratio: Number(e.target.value) })}>{RR_OPTIONS.map((value) => <option key={value} value={value}>1:{value}</option>)}</SelectBox></FieldShell>
                <FieldShell label="Partial Exit"><label className="flex h-11 items-center gap-3 rounded-xl border border-border/50 bg-card/20 px-3"><input type="checkbox" checked={form.partial_exit_enabled} onChange={(e) => setForm({ ...form, partial_exit_enabled: e.target.checked })} /><span>{form.partial_exit_enabled ? "Enabled" : "Disabled"}</span></label></FieldShell>
                {form.partial_exit_enabled && <FieldShell label="Partial Exit At R"><SelectBox value={form.partial_exit_at_r} onChange={(e) => setForm({ ...form, partial_exit_at_r: Number(e.target.value) })}>{[0.5,1,1.25,1.35,1.5,1.65,1.7,1.75,1.8,1.9,2].map((v)=><option key={v} value={v}>{v.toFixed(2)}R</option>)}</SelectBox></FieldShell>}
                {form.partial_exit_enabled && <FieldShell label="Partial Exit Percent" hint="If the requested runner is below the Instrument Master broker minimum/step, AlgoAgentX skips the partial and leaves the full position to its original TP."><SelectBox value={form.partial_exit_percent} onChange={(e) => setForm({ ...form, partial_exit_percent: Number(e.target.value) })}>{[[0.25,"25%"],[0.5,"50%"],[0.75,"75%"],[0.9,"90%"],[0.95,"95%"]].map(([v,label])=><option key={String(v)} value={Number(v)}>{label}</option>)}</SelectBox></FieldShell>}
                <FieldShell label="SL Mode" hint="Read-only strategy runtime setting; deployment saves do not persist SL-mode overrides."><SelectBox disabled value={liveSlMode}>{SL_MODES.map((value) => <option key={value} value={value}>{value.replace(/_/g, " ")}</option>)}</SelectBox></FieldShell>
                {!isFunded && <FieldShell label="Max Daily Loss" hint={form.max_daily_loss == null ? "None = no extra AlgoAgentX daily-loss cap." : undefined}><SelectBox value={selectValue(form.max_daily_loss, dailyLossOptions)} onChange={(e) => e.target.value === "NONE" ? setForm({ ...form, max_daily_loss: null }) : e.target.value !== "CUSTOM" ? setForm({ ...form, max_daily_loss: Number(e.target.value) }) : setAdvancedMode(true)}><option value="NONE">None / Unlimited</option>{dailyLossOptions.map((value) => <option key={value} value={value}>{money(value, currency)}</option>)}<option value="CUSTOM">Custom</option></SelectBox>{advancedMode && selectValue(form.max_daily_loss, dailyLossOptions) === "CUSTOM" && <InputBox type="number" min="0" value={form.max_daily_loss ?? ""} onChange={(e) => setForm({ ...form, max_daily_loss: e.target.value === "" ? null : Number(e.target.value) })} />}</FieldShell>}
                <FieldShell label="Max Trades / Day" hint={form.max_trades_per_day == null ? "None = no extra daily trade-count cap; valid strategy signals can proceed." : undefined}><SelectBox value={form.max_trades_per_day == null ? "NONE" : String(form.max_trades_per_day)} onChange={(e) => setForm({ ...form, max_trades_per_day: e.target.value === "NONE" ? null : Number(e.target.value) })}><option value="NONE">None / Strategy signals</option>{MAX_TRADES.map((value) => <option key={value} value={value}>{value}</option>)}</SelectBox></FieldShell>
                <FieldShell label="Broker Max Lot (MT5/cTrader)" hint={form.mt5_demo_max_lot == null ? "None = no extra AlgoAgentX lot cap. Risk sizing still respects broker-native min/step/max limits." : undefined}><SelectBox value={selectValue(form.mt5_demo_max_lot, MT5_LOT_CAPS)} onChange={(e) => e.target.value === "NONE" ? setForm({ ...form, mt5_demo_max_lot: null }) : e.target.value !== "CUSTOM" ? setForm({ ...form, mt5_demo_max_lot: Number(e.target.value) }) : setAdvancedMode(true)}><option value="NONE">None / Broker native max</option>{MT5_LOT_CAPS.map((value) => <option key={value} value={value}>{value.toFixed(2)}</option>)}<option value="CUSTOM">Custom Advanced</option></SelectBox>{advancedMode && selectValue(form.mt5_demo_max_lot, MT5_LOT_CAPS) === "CUSTOM" && <InputBox type="number" step="0.01" min="0.01" value={form.mt5_demo_max_lot ?? ""} onChange={(e) => setForm({ ...form, mt5_demo_max_lot: e.target.value === "" ? null : Number(e.target.value) })} />}</FieldShell>
              </div>
            </div>

            {advancedMode && !isFunded && <div className="rounded-2xl border border-purple-300/20 bg-purple-500/10 p-5">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="font-black text-white">Unified Runtime Settings</h3>
                  <p className="mt-1 text-xs text-purple-100/80">Same runtime tabs, conditional fields and help tooltips as Backtest. Live-only broker and safety caps remain protected.</p>
                </div>
                <div className="flex flex-wrap gap-2">{RUNTIME_TABS.map((tab) => <button key={tab.value} type="button" onClick={() => setLiveRuntimeTab(tab.value)} className={`rounded-xl border px-3 py-2 text-xs font-medium transition ${liveRuntimeTab === tab.value ? "border-primary/60 bg-primary/20 text-primary-foreground" : "border-white/10 bg-white/5 text-purple-100 hover:bg-white/10"}`}>{tab.label}</button>)}</div>
              </div>
              <div className="mt-5">
                {(["sl_tp", "trade_management"] as RuntimeTab[]).includes(liveRuntimeTab) && <p className="mb-3 text-sm text-muted-foreground">Strategy-managed settings below are read-only: this deployment API cannot persist SL mode, ATR, break-even or trailing overrides. Edit RR and partial exits using the deployment controls above.</p>}
                <fieldset disabled={(["sl_tp", "trade_management"] as RuntimeTab[]).includes(liveRuntimeTab)}>
                <RuntimeSettingsForm
                  activeTab={liveRuntimeTab}
                  config={runtimeConfig() as any}
                  updateSection={updateLiveRuntimeSection as any}
                  currency={currency}
                  instrumentSymbol={normalizedInstrument || "this instrument"}
                  supportsIntradaySquareOff={supportsLiveSquareOff}
                  mode="live"
                />
                </fieldset>
              </div>
              {supportsLiveSquareOff && <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                {isUpstox && <><FieldShell label="Upstox Instrument Key"><InputBox disabled value={form.instrument_key} placeholder="NSE_EQ|INE040A01034" /></FieldShell><FieldShell label="Exchange"><InputBox disabled value={form.exchange} /></FieldShell><FieldShell label="Segment"><InputBox disabled value={form.segment} /></FieldShell></>}
                <FieldShell label="Product Type"><SelectBox value={form.product_type} onChange={(e) => setForm({ ...form, product_type: e.target.value })}><option value="MIS">MIS / Intraday</option><option value="CNC">CNC / Delivery</option></SelectBox></FieldShell>
              </div>}
              <div className="mt-4 rounded-xl border border-amber-300/20 bg-amber-500/10 p-3 text-xs text-amber-100">{isFunded ? "Funded hard rules, broker balance/equity, safety buffer and deployment risk plan remain authoritative. Runtime UI cannot bypass the funded guard." : "Live safety remains enforced by broker readiness, broker-native limits, max-open-position checks, and any optional caps you configure. Runtime UI cannot bypass broker/funded rules."}</div>
            </div>}

            <div className="rounded-2xl border border-cyan-300/20 bg-cyan-500/10 p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div><h3 className="font-black text-white">Copy Trading</h3><p className="mt-1 text-xs text-purple-100/80">The strategy still runs once on the primary deployment. A valid trade intent is routed independently to the selected connected accounts using the same risk settings.</p></div>
                <label className="flex items-center gap-2 text-sm font-semibold text-cyan-100"><input type="checkbox" disabled={isFunded} checked={form.copy_trading_enabled} onChange={(e) => setForm({ ...form, copy_trading_enabled: e.target.checked })} />Enable Copy Trading</label>
              </div>
              {isFunded && <p className="mt-3 rounded-lg border border-amber-300/20 bg-amber-500/10 p-3 text-xs text-amber-100">Funded copy trading is kept disabled in this safe release because each target needs its own funded profile/drawdown state.</p>}
              {!isFunded && form.copy_trading_enabled && <div className="mt-4 space-y-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-purple-200">Copy signal to connected accounts</p>
                {copyTargetBrokers.length === 0 ? <p className="rounded-lg border border-white/10 bg-white/5 p-3 text-sm text-purple-200">No additional connected account in the same DEMO/LIVE environment is available.</p> : copyTargetBrokers.map((broker) => { const checked = form.copy_broker_account_ids.includes(broker.id); return <label key={broker.id} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-purple-50"><input type="checkbox" checked={checked} onChange={(e) => setForm({ ...form, copy_broker_account_ids: e.target.checked ? [...new Set([...form.copy_broker_account_ids, broker.id])] : form.copy_broker_account_ids.filter((id) => id !== broker.id) })} /><span><strong>{broker.broker_code || broker.broker_name}</strong> • {broker.account_label} • {broker.mode} • {broker.login_id || broker.server_name || "Connected"}</span></label>; })}
                <p className="text-xs text-purple-200/80">Risk sizing, open-position limits, duplicate protection and order execution are evaluated per target account. One target failure does not cancel successful sibling accounts.</p>
              </div>}
            </div>

            <div className="flex flex-wrap gap-4 rounded-xl border border-white/10 bg-white/5 p-4"><label className="flex items-center gap-2 text-sm text-purple-100"><input type="checkbox" checked={form.allow_short} onChange={(e) => setForm({ ...form, allow_short: e.target.checked })} />Allow short</label><label className="flex items-center gap-2 text-sm text-purple-100"><input type="checkbox" checked={form.auto_trade_enabled} onChange={(e) => setForm({ ...form, auto_trade_enabled: e.target.checked })} />Auto trade enabled</label><label className="flex items-center gap-2 text-sm text-purple-100"><input type="checkbox" checked={form.auto_runner_enabled} onChange={(e) => setForm({ ...form, auto_runner_enabled: e.target.checked })} />Auto runner enabled</label>{isUpstox && <label className="flex items-center gap-2 text-sm text-yellow-100"><input type="checkbox" checked={form.upstox_order_confirmed} onChange={(e) => setForm({ ...form, upstox_order_confirmed: e.target.checked })} />I understand Upstox orders may place real trades</label>}</div>
            <Button disabled={saving || isPaperDeprecated} className="border-0 bg-gradient-to-r from-lime-400 to-emerald-500 text-slate-950 hover:from-lime-300 hover:to-emerald-400">{isPaperDeprecated ? "Create Broker Deployment Instead" : saving ? "Saving..." : "Save Settings"}</Button>
          </form>
        )}
      </GlassCard>
    </PageShell>
  );
}

function Info({ label, value }: { label: string; value: ReactNode }) {
  return <div className="rounded-xl border border-white/10 bg-white/5 p-3"><p className="text-[10px] uppercase text-purple-200">{label}</p><p className="truncate font-bold text-white">{value || "—"}</p></div>;
}
