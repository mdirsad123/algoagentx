'use client';

import React, { useEffect, useState } from 'react';
import { Eye, Trash2,CheckSquare  } from 'lucide-react';
import Cookies from 'js-cookie';
import { useFetcher } from '@/hooks/use-query';
import { NotificationType } from '@/types/notification-type';
import { usePoster, useUpdater } from "@/hooks/use-query";
import Toast from "@/components/shared/toast";
import { useAtom } from 'jotai';

// Import specific icons you need
import { 
  FaBell, 
  FaUser, 
  FaFileAlt, 
  FaCalendar, 
  FaDollarSign,
  FaExclamationTriangle 
} from 'react-icons/fa';
import { 
  IoBriefcase, 
  IoDocument, 
  IoPersonAdd,
  IoCalendarOutline,
  IoNotifications 
} from 'react-icons/io5';
import { MdMessage } from "react-icons/md";
import { FaBook } from "react-icons/fa";
import { number } from 'zod';
import { atomNotifications } from '@/stores';

export default function FullNotificationsPage() {
  const [activeTab, setActiveTab] = useState('All');
  const [loggedinuserid] = useState(Cookies.get('loggedinuserid'));
  const [selectedNotification, setSelectedNotification] = useState<NotificationType | null>(null);
  const [isUpdating, setIsUpdating] = useState<number | null>(null);
  const [isDeleting, setIsDeleting] = useState<number | null>(null);
   const [isMarkingAll, setIsMarkingAll] = useState(false);
   const [isUpdatingAll, setIsUpdatingAll] = useState(false);
     const [notifications, setNotifications] = useAtom(atomNotifications);

   

  // API base URL - adjust this based on your environment
  const API_BASE_URL = process.env.NEXT_PUBLIC_API_SERVER;

  // Fetch notifications on mount
  useEffect(() => {
    if (loggedinuserid) {
      fetch(`${API_BASE_URL}/notifications/my/${loggedinuserid}`)
        .then(res => res.json())
        .then((data: NotificationType[]) => setNotifications(data))
        .catch(console.error);
    }
  }, [loggedinuserid, setNotifications]);

  // Calculate counts
  const totalCount = notifications.length;
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const readCount = notifications.filter((n) => n.isRead).length;

  // Tabs array with badge counts
  const tabs = [
    { label: `All (${totalCount})`, value: 'All' },
    { label: `Unread (${unreadCount})`, value: 'Unread' },
    { label: `Read (${readCount})`, value: 'Read' }
  ];

  // Filter notifications based on active tab
  const filteredNotifications = notifications.filter((n) => {
    if (activeTab === 'All') return true;
    if (activeTab === 'Unread') return !n.isRead;
    if (activeTab === 'Read') return n.isRead;
    return n.type === activeTab;
  });

  // Icon mapping object for better control
  const iconMap = {
    IoBriefcase,
    IoDocument,
    IoPersonAdd,
    IoCalendarOutline,
    IoNotifications,
    FaBell,
    FaUser,
    FaFileAlt,
    FaCalendar,
    FaDollarSign,
    FaExclamationTriangle,
    FaBook,
  };

  // Function to get the correct icon component
  const getIconComponent = (iconName: string) => {
    return iconMap[iconName as keyof typeof iconMap] || null;
  };


   // ✅ New function to mark all as read
  const handleMarkAllAsRead = async () => {
    if (!loggedinuserid) return;

    setIsMarkingAll(true);
    try {
      const res = await fetch(`${API_BASE_URL}/notifications/mark-all-read`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userid: Number(loggedinuserid) }),
      });

      if (res.ok) {
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, isRead: true }))
        );
        Toast.fire({
          icon: "success",
          title: "All notifications marked as read!",
        });
      } else {
        const errorText = await res.text();
        console.error('Error marking all read:', errorText);
        Toast.fire({
          icon: "error",
          title: "Failed to mark all as read",
          text: errorText,
        });
      }
    } catch (err) {
      console.error('Network error:', err);
      Toast.fire({
        icon: "error",
        title: "Network error occurred",
      });
    } finally {
      setIsMarkingAll(false);
    }
  };

//   const handleMarkAllAsUnread = async () => {
//   if (!loggedinuserid) return;
//   setIsUpdatingAll(true);

//   try {
//     const res = await fetch(`${API_BASE_URL}/notifications/mark-all-unread`, {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify({ userid: Number(loggedinuserid) }),
//     });

//     if (res.ok) {
//       // Update local state
//       setNotifications(prev =>
//         prev.map(n => ({ ...n, isRead: false }))
//       );
//     } else {
//       console.error('Mark All Unread failed');
//     }
//   } catch (err) {
//     console.error(err);
//   } finally {
//     setIsUpdatingAll(false);
//   }
// };

  // Fixed handleViewClick function with proper error handling and debugging
  const handleViewClick = async (notification: NotificationType) => {
    setSelectedNotification(notification);

    if (!notification.isRead) {
      setIsUpdating(notification.id);
      
      // Debug logging
      console.log('Marking notification as read:', {
        notificationId: notification.id,
        userid: loggedinuserid,
        url: `${API_BASE_URL}/notifications/${notification.id}/read`
      });
      
      try {
        const response = await fetch(`${API_BASE_URL}/notifications/${notification.id}/read`, {
          method: 'PUT',
          headers: { 
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({ userid: Number(loggedinuserid) })
        });

        console.log('API Response Status:', response.status);
        console.log('API Response OK:', response.ok);

        if (response.ok) {
          // Try to parse response as JSON if available
          let responseData;
          try {
            responseData = await response.json();
            console.log('Success Response Data:', responseData);
          } catch (e) {
            console.log('Response is not JSON, treating as success');
          }

          // Only update UI if API call was successful
          setNotifications((prev) =>
            prev.map((n) =>
              n.id === notification.id ? { ...n, isRead: true } : n
            )
          );
          
          Toast.fire({
            icon: "success",
            title: "Notification marked as read!",
          });
        } else {
          // Get detailed error information
          let errorData;
          try {
            errorData = await response.json();
            console.error('API Error Response (JSON):', errorData);
          } catch (e) {
            errorData = await response.text();
            console.error('API Error Response (text):', errorData);
          }
          
          Toast.fire({
            icon: "error",
            title: `Failed to mark notification as read (${response.status})`,
            text: typeof errorData === 'string' ? errorData : errorData?.message || 'Unknown error'
          });
        }
      } catch (error) {
        console.error('Network Error:', error);
        
        Toast.fire({
          icon: "error",
          title: "Network error occurred",
          text: error instanceof Error ? error.message : 'Unknown network error'
        });
      } finally {
        setIsUpdating(null);
      }
    }
  };

  // Improved handleDeleteClick with better error handling
  const handleDeleteClick = async (notification: NotificationType) => {
    if (isDeleting === notification.id) return;
    
    setIsDeleting(notification.id);
    
    // Optimistically remove from UI
    const originalNotifications = notifications;
    setNotifications((prev) => prev.filter((n) => n.id !== notification.id));

    try {
      const res = await fetch(`${API_BASE_URL}/notifications/${notification.id}/user/${Number(loggedinuserid)}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        Toast.fire({
          icon: "success",
          title: "Notification deleted successfully!",
        });
      } else {
        // Revert if API call failed
        setNotifications(originalNotifications);
        const errorText = await res.text();
        console.error('Delete failed', errorText);
        
        Toast.fire({
          icon: "error",
          title: "Failed to delete notification",
          text: errorText
        });
      }
    } catch (err) {
      // Revert if network error
      setNotifications(originalNotifications);
      console.error('Error deleting notification', err);
      
      Toast.fire({
        icon: "error",
        title: "Network error occurred",
        text: err instanceof Error ? err.message : 'Unknown error'
      });
    } finally {
      setIsDeleting(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-3 sm:p-6 transition-colors duration-300">
  <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">Notifications</h1>

  {/* Tabs */}
 <div className="border-b mb-4 overflow-x-auto">
  <div className="flex items-center">
    {/* Tabs */}
    <nav className="flex min-w-max sm:min-w-0">
      {tabs.map((tab) => (
        <button
          key={tab.value}
          onClick={() => setActiveTab(tab.value)}
          className={`px-4 sm:px-6 py-2 sm:py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === tab.value
              ? "border-amber-500 text-amber-600 bg-amber-50"
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          }`}
        >
          {tab.label}
        </button>
      ))}
    </nav>

    {/* Mark All as Read button on the right */}
    <div className="ml-auto">
      <button
        onClick={handleMarkAllAsRead}
        disabled={isMarkingAll || unreadCount === 0}
        className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md shadow-sm transition-colors
          ${unreadCount === 0
            ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
            : 'bg-blue-500 text-white hover:bg-blue-600'
          }`}
      >
        {isMarkingAll ? (
          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        ) : (
          <CheckSquare className="w-4 h-4" />
        )}
        {isMarkingAll ? 'Marking...' : 'Mark All as Read'}
      </button>
    </div>
  </div>
</div>


  {/* Notifications List */}
  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border dark:border-gray-700 divide-y divide-gray-100 dark:divide-gray-700">
    {filteredNotifications.length === 0 ? (
      <div className="p-6 text-gray-500 dark:text-gray-400">No notifications to show.</div>
    ) : (
      filteredNotifications.map((notification: NotificationType) => {
        return (
          <div
            key={notification.id}
            className="p-4 sm:p-6 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3 sm:space-x-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                  <MdMessage className="text-lg sm:text-xl text-blue-500" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h3
                      className={`font-semibold text-sm sm:text-base ${
                        notification.isRead
                        ? "text-gray-600 dark:text-gray-400"
                        : "text-gray-900 dark:text-gray-100"
                      }`}
                    >
                      {notification.title || "Untitled"}
                    </h3>
                    {notification.type === "Action" && (
                      <span className="px-2 py-0.5 text-xs font-medium rounded-full border bg-red-100 text-red-600 border-red-200">
                        Action Required
                      </span>
                    )}
                    {!notification.isRead && (
                      <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-blue-100 text-blue-600">
                        New
                      </span>
                    )}
                  </div>

                  {/* Render HTML-rich message */}
                  <div
                    className={`mb-3 text-sm break-words ${
                      notification.isRead ? "text-gray-500 dark:text-gray-400" : "text-gray-600 dark:text-gray-300"
                    }`}
                    dangerouslySetInnerHTML={{ __html: notification.message }}
                  />

                  <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                    <span>{notification.createdAt}</span>
                    {notification.isRead && (
                      <span className="text-green-500">✓ Read</span>
                    )}
                    <div
                      className={`w-2.5 h-2.5 rounded-full ${
                        notification.isRead ? "bg-gray-300" : "bg-blue-500"
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-1 sm:space-x-2 ml-2">
                {/* View */}
                <button
                  className={`p-1.5 sm:p-2 rounded transition-colors ${
                    isUpdating === notification.id
                      ? "text-blue-500 cursor-not-allowed"
                      : "text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300"
                  }`}
                  onClick={() => handleViewClick(notification)}
                  disabled={isUpdating === notification.id}
                >
                  {isUpdating === notification.id ? (
                    <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <Eye className="w-4 h-4 sm:w-5 sm:h-5" />
                  )}
                </button>

                {/* Delete */}
                <button
                  className={`p-1.5 sm:p-2 rounded transition-colors ${
                    isDeleting === notification.id
                      ? "text-red-500 cursor-not-allowed"
                      : "text-gray-400 dark:text-gray-500 hover:text-red-500 dark:hover:text-red-400"
                  }`}
                  onClick={() => handleDeleteClick(notification)}
                  disabled={isDeleting === notification.id}
                >
                  {isDeleting === notification.id ? (
                    <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-red-500 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                  )}
                </button>
              </div>
            </div>
          </div>
        );
      })
    )}
  </div>

  {/* Popup Modal */}
  {selectedNotification && (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 dark:bg-opacity-70 z-50 p-3">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-lg max-h-[85vh] overflow-y-auto p-4 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg sm:text-xl font-bold break-words dark:text-gray-100">
            {selectedNotification.title}
          </h2>
          {selectedNotification.isRead ? (
            <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-green-100 text-green-600">
              Read
            </span>
          ) : (
            <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-blue-100 text-blue-600">
              New
            </span>
          )}
        </div>

        <div
          className="text-sm sm:text-base text-gray-700 dark:text-gray-300 mb-4 max-h-60 overflow-y-auto break-words"
          dangerouslySetInnerHTML={{
            __html: selectedNotification.message,
          }}
        />

        <div className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mb-4">
          Created At:{" "}
          {new Date(selectedNotification.createdAt).toLocaleString()}
        </div>

        <div className="flex justify-end">
          <button
            onClick={() => setSelectedNotification(null)}
            className="px-3 sm:px-4 py-2 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors text-sm sm:text-base dark:text-gray-100"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  )}
</div>

  );
}