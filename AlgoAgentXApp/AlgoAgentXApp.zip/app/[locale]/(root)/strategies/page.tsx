"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function StrategiesPage() {
  const strategies = [
    {
      name: "EMA Crossover Strategy",
      description: "Dual EMA crossover with RSI confirmation",
      status: "active",
      winRate: 67.1,
      totalTrades: 161,
      profitFactor: 3.53,
      sharpeRatio: 0.72,
      maxDrawdown: -4.24,
      lastUpdated: "2024-01-07",
    },
    {
      name: "Mean Reversion Strategy",
      description: "Bollinger Band squeeze breakout",
      status: "active",
      winRate: 58.3,
      totalTrades: 89,
      profitFactor: 2.15,
      sharpeRatio: 0.45,
      maxDrawdown: -6.12,
      lastUpdated: "2024-01-06",
    },
    {
      name: "Momentum Strategy",
      description: "Volume-based momentum trading",
      status: "inactive",
      winRate: 52.4,
      totalTrades: 124,
      profitFactor: 1.87,
      sharpeRatio: 0.38,
      maxDrawdown: -8.45,
      lastUpdated: "2024-01-05",
    },
    {
      name: "Support Resistance Strategy",
      description: "Price action around key levels",
      status: "active",
      winRate: 61.8,
      totalTrades: 203,
      profitFactor: 2.67,
      sharpeRatio: 0.59,
      maxDrawdown: -5.33,
      lastUpdated: "2024-01-07",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Trading Strategies</h1>
        <p className="text-gray-600 mt-2">
          Browse and analyze available trading strategies
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {strategies.map((strategy, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{strategy.name}</CardTitle>
                <Badge variant={strategy.status === 'active' ? 'default' : 'secondary'}>
                  {strategy.status}
                </Badge>
              </div>
              <p className="text-sm text-gray-600">{strategy.description}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Win Rate</span>
                    <span className="text-sm font-medium text-green-600">
                      {strategy.winRate}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Total Trades</span>
                    <span className="text-sm font-medium">{strategy.totalTrades}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Profit Factor</span>
                    <span className="text-sm font-medium">{strategy.profitFactor}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Sharpe Ratio</span>
                    <span className="text-sm font-medium">{strategy.sharpeRatio}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Max Drawdown</span>
                    <span className="text-sm font-medium text-red-600">
                      {strategy.maxDrawdown}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Last Updated</span>
                    <span className="text-sm font-medium">{strategy.lastUpdated}</span>
                  </div>
                </div>
              </div>

            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Strategy Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 border rounded-lg text-center">
              <h3 className="font-medium">Trend Following</h3>
              <p className="text-sm text-gray-500">12 strategies</p>
            </div>
            <div className="p-4 border rounded-lg text-center">
              <h3 className="font-medium">Mean Reversion</h3>
              <p className="text-sm text-gray-500">8 strategies</p>
            </div>
            <div className="p-4 border rounded-lg text-center">
              <h3 className="font-medium">Breakout</h3>
              <p className="text-sm text-gray-500">6 strategies</p>
            </div>
            <div className="p-4 border rounded-lg text-center">
              <h3 className="font-medium">Arbitrage</h3>
              <p className="text-sm text-gray-500">4 strategies</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
