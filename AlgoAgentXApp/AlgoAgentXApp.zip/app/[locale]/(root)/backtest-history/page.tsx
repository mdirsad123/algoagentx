"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import axios from "@/lib/axios";
import Toast from "@/components/shared/toast";
import { Eye, Filter, ChevronLeft, ChevronRight } from "lucide-react";

interface BacktestHistoryItem {
  id: string;
  strategy_id: string;
  strategy_name: string;
  instrument_id: number;
  instrument_symbol: string;
  timeframe: string;
  start_date: string;
  end_date: string;
  initial_capital: number;
  final_capital: number | null;
  net_profit: number | null;
  max_drawdown: number | null;
  sharpe_ratio: number | null;
  win_rate: number | null;
  total_trades: number | null;
  winning_trades: number | null;
  losing_trades: number | null;
  status: string;
  created_at: string;
  updated_at: string;
}

interface Strategy {
  id: string;
  name: string;
}

interface Instrument {
  id: number;
  symbol: string;
}

interface PaginationInfo {
  page: number;
  page_size: number;
  total_count: number;
  total_pages: number;
}

export default function BacktestHistoryPage() {
  // Filter state
  const [strategies, setStrategies] = useState<Strategy[]>([]);
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [selectedStrategy, setSelectedStrategy] = useState<string>("");
  const [selectedInstrument, setSelectedInstrument] = useState<string>("");
  const [timeframe, setTimeframe] = useState<string>("");
  const [startDateFrom, setStartDateFrom] = useState<string>("");
  const [startDateTo, setStartDateTo] = useState<string>("");
  const [minProfit, setMinProfit] = useState<string>("");
  const [maxDrawdown, setMaxDrawdown] = useState<string>("");

  // Data state
  const [backtests, setBacktests] = useState<BacktestHistoryItem[]>([]);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedBacktest, setSelectedBacktest] = useState<BacktestHistoryItem | null>(null);

  // Load strategies and instruments on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const [strategiesRes, instrumentsRes] = await Promise.all([
          axios.get("/api/v1/strategies"),
          axios.get("/api/v1/instruments")
        ]);
        setStrategies(strategiesRes.data);
        setInstruments(instrumentsRes.data);
      } catch (error: any) {
        Toast.fire({
          icon: 'error',
          title: 'Failed to load data',
          text: error.response?.data?.detail || 'Unable to load strategies and instruments'
        });
      }
    };
    loadData();
  }, []);

  // Load backtest history
  const loadBacktestHistory = async (page: number = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedStrategy) params.append('strategy_id', selectedStrategy);
      if (selectedInstrument) params.append('instrument_id', selectedInstrument);
      if (timeframe) params.append('timeframe', timeframe);
      if (startDateFrom) params.append('start_date_from', startDateFrom);
      if (startDateTo) params.append('start_date_to', startDateTo);
      if (minProfit) params.append('min_profit', minProfit);
      if (maxDrawdown) params.append('max_drawdown', maxDrawdown);
      params.append('page', page.toString());
      params.append('page_size', '20');

      const response = await axios.get(`/api/v1/backtests/history?${params}`);
      const data = response.data;

      setBacktests(data.backtests);
      setPagination(data.pagination);
    } catch (error: any) {
      Toast.fire({
        icon: 'error',
        title: 'Failed to load history',
        text: error.response?.data?.detail || 'Unable to load backtest history'
      });
    } finally {
      setLoading(false);
    }
  };

  // Load initial data
  useEffect(() => {
    loadBacktestHistory();
  }, []);

  const applyFilters = () => {
    loadBacktestHistory(1);
  };

  const clearFilters = () => {
    setSelectedStrategy("");
    setSelectedInstrument("");
    setTimeframe("");
    setStartDateFrom("");
    setStartDateTo("");
    setMinProfit("");
    setMaxDrawdown("");
    loadBacktestHistory(1);
  };

  const viewBacktestReport = (backtest: BacktestHistoryItem) => {
    setSelectedBacktest(backtest);
    // In a real app, this would navigate to a detailed report page
    // For now, we'll just show the data in the UI
  };

  const formatCurrency = (value: number | null) => {
    if (value === null) return "-";
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };

  const formatPercent = (value: number | null) => {
    if (value === null) return "-";
    return `${(value * 100).toFixed(2)}%`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Backtest History</h1>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Strategy Filter */}
            <div className="space-y-2">
              <Label>Strategy</Label>
              <Select value={selectedStrategy} onValueChange={setSelectedStrategy}>
                <SelectTrigger>
                  <SelectValue placeholder="All strategies" />
                </SelectTrigger>
                <SelectContent>
                  {strategies.map(strategy => (
                    <SelectItem key={strategy.id} value={strategy.id}>
                      {strategy.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Instrument Filter */}
            <div className="space-y-2">
              <Label>Instrument</Label>
              <Select value={selectedInstrument} onValueChange={setSelectedInstrument}>
                <SelectTrigger>
                  <SelectValue placeholder="All instruments" />
                </SelectTrigger>
                <SelectContent>
                  {instruments.map(instrument => (
                    <SelectItem key={instrument.id.toString()} value={instrument.id.toString()}>
                      {instrument.symbol}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Timeframe Filter */}
            <div className="space-y-2">
              <Label>Timeframe</Label>
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger>
                  <SelectValue placeholder="All timeframes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5m">5 Minutes</SelectItem>
                  <SelectItem value="15m">15 Minutes</SelectItem>
                  <SelectItem value="1h">1 Hour</SelectItem>
                  <SelectItem value="1d">1 Day</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Min Profit Filter */}
            <div className="space-y-2">
              <Label>Min Profit ($)</Label>
              <Input
                type="number"
                value={minProfit}
                onChange={(e) => setMinProfit(e.target.value)}
                placeholder="0"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Start Date From */}
            <div className="space-y-2">
              <Label>Start Date From</Label>
              <Input
                type="date"
                value={startDateFrom}
                onChange={(e) => setStartDateFrom(e.target.value)}
              />
            </div>

            {/* Start Date To */}
            <div className="space-y-2">
              <Label>Start Date To</Label>
              <Input
                type="date"
                value={startDateTo}
                onChange={(e) => setStartDateTo(e.target.value)}
              />
            </div>

            {/* Max Drawdown Filter */}
            <div className="space-y-2">
              <Label>Max Drawdown (%)</Label>
              <Input
                type="number"
                value={maxDrawdown}
                onChange={(e) => setMaxDrawdown(e.target.value)}
                placeholder="20"
              />
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-6">
              <Button onClick={applyFilters} disabled={loading}>
                Apply Filters
              </Button>
              <Button variant="outline" onClick={clearFilters} disabled={loading}>
                Clear
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Backtest Results</CardTitle>
          {pagination && (
            <div className="text-sm text-gray-600">
              Showing {((pagination.page - 1) * pagination.page_size) + 1} to {Math.min(pagination.page * pagination.page_size, pagination.total_count)} of {pagination.total_count} results
            </div>
          )}
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Strategy</TableHead>
                <TableHead>Instrument</TableHead>
                <TableHead>Timeframe</TableHead>
                <TableHead>Period</TableHead>
                <TableHead>Net Profit</TableHead>
                <TableHead>Win Rate</TableHead>
                <TableHead>Max DD</TableHead>
                <TableHead>Trades</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {backtests.map((backtest) => (
                <TableRow key={backtest.id}>
                  <TableCell className="font-medium">{backtest.strategy_name}</TableCell>
                  <TableCell>{backtest.instrument_symbol}</TableCell>
                  <TableCell>{backtest.timeframe}</TableCell>
                  <TableCell>
                    {formatDate(backtest.start_date)} - {formatDate(backtest.end_date)}
                  </TableCell>
                  <TableCell className={backtest.net_profit && backtest.net_profit >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {formatCurrency(backtest.net_profit)}
                  </TableCell>
                  <TableCell>{formatPercent(backtest.win_rate)}</TableCell>
                  <TableCell className="text-red-600">
                    {formatPercent(backtest.max_drawdown)}
                  </TableCell>
                  <TableCell>{backtest.total_trades || 0}</TableCell>
                  <TableCell>
                    <Badge variant={backtest.status === 'completed' ? 'default' : 'secondary'}>
                      {backtest.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDate(backtest.created_at)}</TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewBacktestReport(backtest)}
                      className="flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {backtests.length === 0 && !loading && (
                <TableRow>
                  <TableCell colSpan={11} className="text-center py-8 text-gray-500">
                    No backtests found matching your criteria
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {pagination && pagination.total_pages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-gray-600">
                Page {pagination.page} of {pagination.total_pages}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => loadBacktestHistory(pagination.page - 1)}
                  disabled={pagination.page <= 1 || loading}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => loadBacktestHistory(pagination.page + 1)}
                  disabled={pagination.page >= pagination.total_pages || loading}
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Selected Backtest Details Modal/Panel would go here */}
      {selectedBacktest && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              Backtest Report: {selectedBacktest.strategy_name} - {selectedBacktest.instrument_symbol}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div>
                <div className="text-sm text-gray-600">Net Profit</div>
                <div className={`text-xl font-bold ${selectedBacktest.net_profit && selectedBacktest.net_profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(selectedBacktest.net_profit)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Win Rate</div>
                <div className="text-xl font-bold text-blue-600">
                  {formatPercent(selectedBacktest.win_rate)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Max Drawdown</div>
                <div className="text-xl font-bold text-red-600">
                  {formatPercent(selectedBacktest.max_drawdown)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Total Trades</div>
                <div className="text-xl font-bold">
                  {selectedBacktest.total_trades || 0}
                </div>
              </div>
            </div>

            <div className="text-sm text-gray-600">
              <p>Period: {formatDate(selectedBacktest.start_date)} - {formatDate(selectedBacktest.end_date)}</p>
              <p>Timeframe: {selectedBacktest.timeframe}</p>
              <p>Initial Capital: {formatCurrency(selectedBacktest.initial_capital)}</p>
              <p>Final Capital: {formatCurrency(selectedBacktest.final_capital)}</p>
              <p>Sharpe Ratio: {selectedBacktest.sharpe_ratio?.toFixed(2) || '-'}</p>
            </div>

            <div className="mt-4">
              <Button variant="outline" onClick={() => setSelectedBacktest(null)}>
                Close Report
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
