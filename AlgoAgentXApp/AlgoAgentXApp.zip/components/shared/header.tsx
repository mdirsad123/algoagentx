"use client";
import React, { useState } from "react";
import { Bell, ChevronDown, Globe } from "lucide-react";

export default function MinimalHeader() {
  const [showLangDropdown, setShowLangDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [selectedLang, setSelectedLang] = useState("Eng (US)");
  const [notifications] = useState(1);

  const languages = [
    "Eng (US)",
    "Eng (UK)", 
    "Spanish",
    "French",
    "German"
  ];

  return (
    <div className="w-full bg-white border-b border-gray-200">
      <div className="flex items-center justify-end h-14 px-6 gap-6">
        
        {/* Language Selector */}
        <div className="relative" onBlur={() => setShowLangDropdown(false)}>
          <button
            onClick={() => setShowLangDropdown(!showLangDropdown)}
            className="flex items-center gap-2 text-sm text-gray-700 hover:text-gray-900 transition-colors"
          >
            <Globe className="w-4 h-4" />
            <span>{selectedLang}</span>
            <ChevronDown className="w-4 h-4" />
          </button>
          
          {showLangDropdown && (
            <div 
              className="absolute right-0 mt-2 w-40 bg-white border border-gray-200 rounded-lg shadow-lg z-50"
              onMouseDown={(e) => e.preventDefault()}
            >
              {languages.map((lang) => (
                <button
                  key={lang}
                  onClick={() => {
                    setSelectedLang(lang);
                    setShowLangDropdown(false);
                  }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                    selectedLang === lang ? "bg-blue-50 text-blue-600" : "text-gray-700"
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notification Bell */}
        <button className="relative p-2 hover:bg-gray-50 rounded-full transition-colors">
          <Bell className="w-5 h-5 text-gray-600" />
          {notifications > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          )}
        </button>

        {/* User Profile */}
        <div className="relative" onBlur={() => setShowUserDropdown(false)}>
          <button
            onClick={() => setShowUserDropdown(!showUserDropdown)}
            className="flex items-center gap-3 hover:bg-gray-50 rounded-lg px-2 py-1 transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
              <img
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%234299e1'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='.3em' fill='white' font-size='40' font-family='Arial, sans-serif' font-weight='bold'%3EM%3C/text%3E%3C/svg%3E"
                alt="User Avatar"
                className="w-full h-full rounded-full"
              />
            </div>
            <div className="flex flex-col items-start">
              <span className="text-sm font-medium text-gray-900">Musfiq UI</span>
              <span className="text-xs text-gray-500">Admin</span>
            </div>
            <ChevronDown className="w-4 h-4 text-gray-600" />
          </button>

          {showUserDropdown && (
            <div 
              className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50"
              onMouseDown={(e) => e.preventDefault()}
            >
              <div className="px-4 py-3 border-b border-gray-100">
                <p className="text-sm font-medium text-gray-900">Musfiq UI</p>
                <p className="text-xs text-gray-500">admin@example.com</p>
              </div>
              <button className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                My Profile
              </button>
              <button className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                Settings
              </button>
              <div className="border-t border-gray-100">
                <button className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                  Logout
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}