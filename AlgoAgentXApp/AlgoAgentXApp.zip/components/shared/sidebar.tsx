"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  BarChart3,
  Layers,
  PlayCircle,
  History,
  FileText,
  Settings,
} from "lucide-react";
import React from "react";

// Define menu items with proper locale-aware URLs
const menuItems = [
  { icon: Home, label: "Dashboard", href: "/dashboard" },
  { icon: Layers, label: "Brokers", href: "/brokers" },
  { icon: BarChart3, label: "Strategies", href: "/strategies" },
  { icon: PlayCircle, label: "Backtest", href: "/backtest" },
  { icon: History, label: "Backtest History", href: "/backtest-history" },
  { icon: FileText, label: "Reports", href: "/reports" },
];

// Memoize SidebarItem to prevent unnecessary re-renders
const SidebarItem = React.memo(function SidebarItem({
  icon: Icon,
  label,
  href,
  isActive,
}: {
  icon: any;
  label: string;
  href: string;
  isActive: boolean;
}) {
  return (
    <Link
      href={href}
      prefetch={true}
      className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors duration-200
        ${
          isActive
            ? "bg-blue-50 text-blue-600 border-r-2 border-blue-600"
            : "text-slate-700 hover:bg-blue-50 hover:text-blue-600"
        }
      `}
    >
      <Icon className="w-5 h-5" />
      <span className="text-sm font-medium">{label}</span>
    </Link>
  );
});

SidebarItem.displayName = "SidebarItem";

export default React.memo(function Sidebar() {
  const pathname = usePathname();

  // Determine active menu item based on current pathname
  const getIsActive = React.useCallback((href: string) => {
    // Remove locale prefix from pathname for comparison
    const pathWithoutLocale = pathname.replace(/^\/[a-z]{2}/, '') || '/';
    return pathWithoutLocale === href || pathWithoutLocale.startsWith(href + '/');
  }, [pathname]);

  // Memoize the sidebar content to prevent unnecessary re-renders
  const sidebarContent = React.useMemo(() => (
    <aside className="w-[260px] min-h-screen border-r border-slate-200 bg-white flex flex-col">
      {/* LOGO */}
      <div className="h-[90px] flex items-center justify-center border-b border-slate-200">
        <img
          src="/product.svg"
          alt="AlgoAgentX"
          className="h-[60px] object-contain"
        />
      </div>

      {/* MENU */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {menuItems.map((item) => (
          <SidebarItem
            key={item.href}
            icon={item.icon}
            label={item.label}
            href={item.href}
            isActive={getIsActive(item.href)}
          />
        ))}
      </nav>

      {/* FOOTER */}
      <div className="p-4 border-t border-slate-200">
        <Link
          href="/myprofile"
          prefetch={true}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-200"
        >
          <Settings className="w-5 h-5" />
          <span className="text-sm font-medium">Settings</span>
        </Link>
      </div>
    </aside>
  ), [getIsActive]);

  return sidebarContent;
});
