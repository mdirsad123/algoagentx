# Run docker after that (postgres Database backup)
--> docker ps look container name in this case my container name is (algo_postgres)

--> this below command is make full databae backup in docker temp
docker exec -t algo_postgres pg_dump -U algo_user -d algo_db -F c -b -v -f /tmp/algo_db_backup.dump

--> Copy this backup dump file in window below command
docker cp algo_postgres:/tmp/algo_db_backup.dump D:\Stock_market\algoagentx\AlgoAgentXAPI\backup_db\algo_db_backup.dump

--> One-line direct backup command
docker exec -t algo_postgres pg_dump -U algo_user -d algo_db -F c -b -v > D:\Stock_market\algoagentx\db_backup\algo_db_backup.dump

