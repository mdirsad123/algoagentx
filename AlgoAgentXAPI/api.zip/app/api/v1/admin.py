from __future__ import annotations

import json
from datetime import datetime, timedelta
from decimal import Decimal
from math import ceil
from typing import Any, Optional
from uuid import uuid4
import logging
from pathlib import Path

import bcrypt
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import String, and_, cast, delete, func, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import load_only

from ...core.dependencies import get_admin_user, get_current_user, get_db
from ...utils.api_response import success_response
from ...db.models import (
    Trade,
    EquityCurve,
    PnLCalendar,
    BillingOrder,
    CreditTransaction,
    CreditTransactionType,
    Instrument,
    JobStatus,
    MarketData,
    Payment,
    PerformanceMetric,
    Plan,
    Strategy,
    StrategyRequest,
    User,
    UserCredit,
    UserSubscription,
    SupportTicket,
    SupportTicketReply,
)
from ...db.compat import as_uuid_or_str, column_text, table_has_column
from ...services.credits.management import CreditManagementService
from ...services.pricing.backtest_pricing_service import BacktestPricingService

logger = logging.getLogger(__name__)


def _admin_to_float(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _admin_to_int(value):
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None
router = APIRouter()


class UserCreateRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)
    fullname: Optional[str] = None
    mobile: Optional[str] = None
    role: str = "user"

class UserUpdateRequest(BaseModel):
    email: Optional[EmailStr] = None
    fullname: Optional[str] = None
    mobile: Optional[str] = None
    role: Optional[str] = None


class UserStatusRequest(BaseModel):
    is_active: bool


class UserRoleRequest(BaseModel):
    role: str


class CreditAdjustRequest(BaseModel):
    user_id: str
    amount: int = Field(..., gt=0)
    reason: str = Field(..., min_length=2)


class StrategyDecisionRequest(BaseModel):
    status: str = Field(..., pattern="^(UNDER_DEVELOPMENT|NEEDS_CLARIFICATION|REJECTED|DEPLOYED)$")
    admin_notes: Optional[str] = None


class SubscriptionUpdateRequest(BaseModel):
    status: Optional[str] = None
    renews: Optional[bool] = None
    end_at: Optional[datetime] = None


class OrderStatusRequest(BaseModel):
    status: str


class PaymentRefundRequest(BaseModel):
    note: Optional[str] = None


class BacktestPricingRuleSetUpdateRequest(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None

    base_cost: Optional[float] = Field(default=None, gt=0)
    range_days_step: Optional[int] = Field(default=None, ge=1)
    min_credit_charge: Optional[int] = Field(default=None, ge=1)
    max_credit_charge: Optional[int] = Field(default=None, ge=1)

    date_range_buckets: Optional[list[dict[str, Any]]] = None
    timeframe_multipliers: Optional[list[dict[str, Any]]] = None

    strategy_complexity_enabled: Optional[bool] = None
    strategy_complexity_step: Optional[float] = Field(default=None, ge=0)
    strategy_complexity_cap: Optional[float] = Field(default=None, ge=0)

    plan_discounts: Optional[dict[str, float]] = None


class BacktestPricingRuleSetActivateRequest(BaseModel):
    rule_set_id: str


class MarketDataHookRequest(BaseModel):
    instrument_id: Optional[int] = None
    timeframe: Optional[str] = None
    source: Optional[str] = None
    note: Optional[str] = None


def _serialize(value: Any) -> Any:
    if isinstance(value, Decimal):
        try:
            return int(value) if value == int(value) else float(value)
        except Exception:
            return float(value)
    if isinstance(value, datetime):
        return value.isoformat()
    return value


def _safe_attr(instance: Any, name: str, default: Any = None) -> Any:
    try:
        return instance.__dict__.get(name, default)
    except Exception:
        return default


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _read_text_file(path: Path) -> str:
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path.name}")
    return path.read_text(encoding="utf-8")


def _write_text_file(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")



def _parse_iso_datetime(value: Optional[str], *, field_name: str) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        raise HTTPException(status_code=400, detail=f"Invalid {field_name} datetime format")


async def _user_is_active_value(db: AsyncSession, user: User) -> bool:
    if await table_has_column(db, "users", "is_active"):
        result = await db.execute(text("SELECT is_active FROM users WHERE id = :user_id"), {"user_id": str(user.id)})
        value = result.scalar()
        return True if value is None else bool(value)
    return True


async def _ensure_user_credit_row(db: AsyncSession, user_id: str) -> UserCredit:
    row = (await db.execute(select(UserCredit).where(column_text(UserCredit.user_id) == str(user_id)))).scalar_one_or_none()
    if row:
        return row
    row = UserCredit(user_id=as_uuid_or_str(user_id), balance=0)
    db.add(row)
    await db.flush()
    return row


async def _get_credit_balance_map(db: AsyncSession, user_ids: list[str]) -> dict[str, int]:
    if not user_ids:
        return {}
    result = await db.execute(select(UserCredit).where(column_text(UserCredit.user_id).in_([str(uid) for uid in user_ids])))
    return {str(row.user_id): int(row.balance or 0) for row in result.scalars().all()}


async def _get_subscription_map(db: AsyncSession, user_ids: list[str]) -> dict[str, dict[str, Any]]:
    if not user_ids:
        return {}
    stmt = (
        select(UserSubscription, Plan)
        .outerjoin(Plan, Plan.id == UserSubscription.plan_id)
        .where(cast(UserSubscription.user_id, String).in_([str(uid) for uid in user_ids]))
        .order_by(UserSubscription.created_at.desc())
    )
    result = await db.execute(stmt)
    subscription_map: dict[str, dict[str, Any]] = {}
    for sub, plan in result.all():
        key = str(sub.user_id)
        if key in subscription_map:
            continue
        plan_code = str(getattr(sub, "plan_code_snapshot", None) or getattr(plan, "code", None) or "FREE").upper()
        billing_period = str(getattr(sub, "billing_period_snapshot", None) or getattr(plan, "billing_period", None) or "NONE").upper()
        subscription_map[key] = {
            "plan": plan_code,
            "plan_code": plan_code,
            "billing_period": billing_period,
            "status": sub.status,
            "subscription_id": str(sub.id),
            "included_credits_total": int(getattr(sub, "included_credits_total", None) or getattr(plan, "included_credits", 0) or 0),
            "included_credits_remaining": int(getattr(sub, "included_credits_remaining", None) or 0),
        }
    return subscription_map


async def _adjust_credits(
    db: AsyncSession,
    user_id: str,
    amount: int,
    reason: str,
    transaction_type: CreditTransactionType,
    actor_user_id: Optional[str] = None,
    source: str = "admin_manual",
) -> dict[str, Any]:
    user_id_or_email = str(user_id or "").strip()
    user = None
    if "@" in user_id_or_email:
        user = (await db.execute(select(User).where(User.email == user_id_or_email))).scalar_one_or_none()
    else:
        user = (await db.execute(select(User).where(column_text(User.id) == user_id_or_email))).scalar_one_or_none()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    credit_row = await _ensure_user_credit_row(db, str(user.id))
    balance_before = int(credit_row.balance or 0)
    signed_amount = amount if transaction_type != CreditTransactionType.DEBIT else -amount
    new_balance = balance_before + signed_amount
    if new_balance < 0:
        raise HTTPException(status_code=400, detail="Insufficient credit balance")

    credit_row.balance = new_balance

    txn_id = str(uuid4())
    has_actor_user_id = await table_has_column(db, "credit_transactions", "actor_user_id")
    has_source = await table_has_column(db, "credit_transactions", "source")
    normalized_reason = str(reason or "").strip()

    description_value = normalized_reason
    if not has_source or not has_actor_user_id:
        fallback_audit = [normalized_reason or "admin_manual_credit_adjustment", f"source={source}"]
        if actor_user_id:
            fallback_audit.append(f"actor={actor_user_id}")
        description_value = " | ".join(fallback_audit)

    insert_columns = [
        "id",
        "user_id",
        "transaction_type",
        "amount",
        "balance_after",
        "description",
    ]
    insert_params: dict[str, Any] = {
        "id": txn_id,
        "user_id": as_uuid_or_str(str(user.id)),
        "transaction_type": transaction_type.name,
        "amount": amount,
        "balance_after": new_balance,
        "description": description_value,
    }

    if has_actor_user_id:
        insert_columns.append("actor_user_id")
        insert_params["actor_user_id"] = actor_user_id
    if has_source:
        insert_columns.append("source")
        insert_params["source"] = source

    await db.execute(
        text(
            f"""
            INSERT INTO credit_transactions ({', '.join(insert_columns)})
            VALUES ({', '.join(':' + col for col in insert_columns)})
            """
        ),
        insert_params,
    )

    created_at = (
        await db.execute(
            text("SELECT created_at FROM credit_transactions WHERE id = :txn_id"),
            {"txn_id": txn_id},
        )
    ).scalar_one_or_none()

    await db.commit()
    return {
        "message": "Credits updated successfully",
        "transaction": {
            "id": txn_id,
            "user_id": str(user.id),
            "user_email": user.email,
            "credits": signed_amount,
            "type": transaction_type.value,
            "reason": normalized_reason,
            "source_type": source if has_source else None,
            "actor_user_id": actor_user_id if has_actor_user_id else None,
            "balance_after": new_balance,
            "created_at": _serialize(created_at),
        },
    }


async def _get_backtest_billing_snapshot(db: AsyncSession, backtest_ids: list[str]) -> dict[str, dict[str, Any]]:
    if not backtest_ids:
        return {}

    rows = (
        await db.execute(
            select(
                CreditTransaction.backtest_id,
                CreditTransaction.id,
                CreditTransaction.amount,
                CreditTransaction.transaction_type,
                CreditTransaction.source,
            )
            .where(CreditTransaction.backtest_id.in_(backtest_ids))
            .order_by(CreditTransaction.created_at.desc())
        )
    ).all()

    out: dict[str, dict[str, Any]] = {}
    for backtest_id, txn_id, amount, transaction_type, source in rows:
        key = str(backtest_id)
        if key not in out:
            out[key] = {
                "debit_transaction_id": None,
                "debit_transaction_ids": [],
                "refund_transaction_ids": [],
                "credit_cost": 0.0,
                "effective_credit_cost": 0.0,
                "included_debited": 0.0,
                "wallet_debited": 0.0,
                "included_refunded": 0.0,
                "wallet_refunded": 0.0,
                "refund_total": 0.0,
                "charge_status": "not_charged",
            }

        tx_type = transaction_type.name if hasattr(transaction_type, "name") else str(transaction_type).upper()
        tx_source = str(source or "").lower()
        tx_amount = float(amount or 0)

        if tx_type == CreditTransactionType.DEBIT.name:
            if out[key]["debit_transaction_id"] is None:
                out[key]["debit_transaction_id"] = str(txn_id)
            out[key]["debit_transaction_ids"].append(str(txn_id))
            out[key]["credit_cost"] += tx_amount
            if tx_source == CreditManagementService.SOURCE_BACKTEST_INCLUDED_DEBIT:
                out[key]["included_debited"] += tx_amount
            else:
                out[key]["wallet_debited"] += tx_amount
            continue

        if tx_type == CreditTransactionType.REFUND.name:
            out[key]["refund_transaction_ids"].append(str(txn_id))
            if tx_source == CreditManagementService.SOURCE_BACKTEST_INCLUDED_REFUND:
                out[key]["included_refunded"] += tx_amount
            else:
                out[key]["wallet_refunded"] += tx_amount

    for key in out.keys():
        debit_total = float(out[key]["credit_cost"])
        refund_total = float(out[key]["included_refunded"] + out[key]["wallet_refunded"])
        out[key]["refund_total"] = refund_total
        out[key]["effective_credit_cost"] = max(debit_total - refund_total, 0.0)

        if debit_total <= 0:
            out[key]["charge_status"] = "not_charged"
        elif out[key]["effective_credit_cost"] <= 0 and refund_total > 0:
            out[key]["charge_status"] = "refunded"
        elif refund_total > 0:
            out[key]["charge_status"] = "partially_refunded"
        else:
            out[key]["charge_status"] = "charged"

    return out


@router.get("/metrics")
async def get_admin_metrics(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    total_users = (await db.execute(select(func.count()).select_from(User))).scalar() or 0
    has_is_active = await table_has_column(db, "users", "is_active")
    if has_is_active:
        active_users = (await db.execute(text("SELECT COUNT(*) FROM users WHERE is_active = true"))).scalar() or 0
    else:
        active_users = total_users

    paid_statuses = ["PAID", "captured", "success", "SUCCESS"]
    total_revenue = (
        await db.execute(select(func.coalesce(func.sum(Payment.amount_inr), 0)).where(Payment.status.in_(paid_statuses)))
    ).scalar() or 0
    total_credits_issued = (
        await db.execute(
            select(func.coalesce(func.sum(CreditTransaction.amount), 0)).where(
                func.lower(cast(CreditTransaction.transaction_type, String)).in_([
                    CreditTransactionType.CREDIT.value,
                    CreditTransactionType.CREDIT.name.lower(),
                    CreditTransactionType.REFUND.value,
                    CreditTransactionType.REFUND.name.lower(),
                ])
            )
        )
    ).scalar() or 0
    total_subscriptions = (await db.execute(select(func.count()).select_from(UserSubscription))).scalar() or 0
    pending_strategy_requests = (
        await db.execute(
            select(func.count()).select_from(StrategyRequest).where(
                StrategyRequest.status.in_(["PENDING", "UNDER_DEVELOPMENT", "NEEDS_CLARIFICATION"])
            )
        )
    ).scalar() or 0
    total_backtests = (await db.execute(select(func.count()).select_from(PerformanceMetric))).scalar() or 0
    has_billing_orders = await table_has_column(db, "billing_orders", "id")
    if has_billing_orders:
        total_orders = (await db.execute(select(func.count()).select_from(BillingOrder))).scalar() or 0
    else:
        total_orders = (await db.execute(select(func.count()).select_from(Payment))).scalar() or 0

    recent_user_rows = (await db.execute(select(User).order_by(User.created_at.desc()).limit(5))).scalars().all()
    user_ids = [str(user.id) for user in recent_user_rows]
    balances = await _get_credit_balance_map(db, user_ids)
    subs = await _get_subscription_map(db, user_ids)
    recent_users = []
    for user in recent_user_rows:
        uid = str(user.id)
        recent_users.append(
            {
                "id": uid,
                "email": user.email,
                "fullname": user.fullname,
                "role": user.role,
                "is_active": await _user_is_active_value(db, user),
                "mobile": user.mobile,
                "plan": subs.get(uid, {}).get("plan", "FREE"),
                "billing_period": subs.get(uid, {}).get("billing_period", "NONE"),
                "subscription_status": subs.get(uid, {}).get("status"),
                "credits": balances.get(uid, 0),
                "created_at": _serialize(user.created_at),
            }
        )

    payment_stmt = (
        select(Payment, User.email, User.fullname)
        .outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String))
        .order_by(Payment.created_at.desc())
        .limit(5)
    )
    payment_rows = (await db.execute(payment_stmt)).all()
    recent_payments = []
    recent_orders = []
    for payment, email, fullname in payment_rows:
        payload = {
            "id": str(payment.id),
            "user_id": str(payment.user_id),
            "user_email": email or "—",
            "user_name": fullname or email or "—",
            "amount": int(payment.amount_inr or 0),
            "currency": payment.currency or "INR",
            "status": payment.status,
            "payment_method": payment.provider,
            "purpose": payment.purpose,
            "transaction_id": payment.razorpay_payment_id,
            "razorpay_order_id": payment.razorpay_order_id,
            "created_at": _serialize(payment.created_at),
        }
        recent_payments.append(payload)

    if has_billing_orders:
        order_rows = (
            await db.execute(
                select(BillingOrder, User.email, User.fullname)
                .outerjoin(User, cast(User.id, String) == cast(BillingOrder.user_id, String))
                .order_by(BillingOrder.created_at.desc())
                .limit(5)
            )
        ).all()
        for order, email, fullname in order_rows:
            recent_orders.append(
                {
                    "id": str(order.id),
                    "user_id": str(order.user_id),
                    "user_email": email or "—",
                    "user_name": fullname or email or "—",
                    "order_number": order.billing_order_id or order.razorpay_order_id or str(order.id),
                    "status": order.status,
                    "total_amount": int(order.amount_inr or 0),
                    "currency": order.currency or "INR",
                    "payment_method": order.provider,
                    "purpose": order.purpose,
                    "created_at": _serialize(order.created_at),
                }
            )
    else:
        for payment, email, fullname in payment_rows:
            recent_orders.append(
                {
                    "id": str(payment.id),
                    "user_id": str(payment.user_id),
                    "user_email": email or "—",
                    "user_name": fullname or email or "—",
                    "order_number": payment.razorpay_order_id or str(payment.id),
                    "status": payment.status,
                    "total_amount": int(payment.amount_inr or 0),
                    "currency": payment.currency or "INR",
                    "payment_method": payment.provider,
                    "purpose": payment.purpose,
                    "created_at": _serialize(payment.created_at),
                }
            )

    # Calculate additional metrics for test compatibility
    paid_count = (await db.execute(select(func.count()).select_from(Payment).where(Payment.status.in_(paid_statuses)))).scalar() or 0
    failed_count = total_orders - paid_count
    
    total_credits_used = (
        await db.execute(
            select(func.coalesce(func.sum(CreditTransaction.amount), 0)).where(
                func.lower(cast(CreditTransaction.transaction_type, String)).in_([
                    CreditTransactionType.DEBIT.value,
                    CreditTransactionType.DEBIT.name.lower(),
                ])
            )
        )
    ).scalar() or 0
    
    active_subscriptions = (await db.execute(select(func.count()).select_from(UserSubscription).where(UserSubscription.status == "ACTIVE"))).scalar() or 0
    
    # AI Screener Jobs
    try:
        ai_jobs_total = (await db.execute(text("SELECT COUNT(*) FROM job_status WHERE job_type = 'ai_screener'"))).scalar() or 0
        ai_jobs_completed = (await db.execute(text("SELECT COUNT(*) FROM job_status WHERE job_type = 'ai_screener' AND status = 'completed'"))).scalar() or 0
        ai_jobs_failed = ai_jobs_total - ai_jobs_completed
    except Exception:
        await db.rollback()
        ai_jobs_total = 0
        ai_jobs_completed = 0
        ai_jobs_failed = 0
    
    # Support Tickets / Notifications
    try:
        tickets_total = (await db.execute(text("SELECT COUNT(*) FROM notifications"))).scalar() or 0
        tickets_unread = (await db.execute(text("SELECT COUNT(*) FROM notifications WHERE status = 'unread'"))).scalar() or 0
    except Exception:
        await db.rollback()
        tickets_total = 0
        tickets_unread = 0
    
    try:
        total_strategies = (await db.execute(select(func.count()).select_from(Strategy))).scalar() or 0
    except Exception:
        await db.rollback()
        total_strategies = 0

    return success_response({
        "users": {"total": total_users, "active": active_users, "recent": recent_users},
        "payments": {
            "total": total_orders,
            "paid": paid_count,
            "failed": failed_count,
            "revenue": float(total_revenue),
            "revenue_total": float(total_revenue),
            "recent": recent_payments
        },
        "subscriptions": {
            "total": total_subscriptions,
            "active": active_subscriptions
        },
        "credits": {
            "total": int(total_credits_issued),
            "total_issued": int(total_credits_issued),
            "used": int(total_credits_used),
            "available": int(total_credits_issued - total_credits_used),
            "active_subscriptions": active_subscriptions,
        },
        "strategies": {
            "pending": pending_strategy_requests,
            "total": total_strategies
        },
        "backtests": {"total": total_backtests},
        "orders": {"total": total_orders, "recent": recent_orders},
        "ai_screener_jobs": {
            "total": ai_jobs_total,
            "completed": ai_jobs_completed,
            "failed": ai_jobs_failed,
            "recent": []
        },
        "support_tickets": {
            "total": tickets_total,
            "unread": tickets_unread
        },
        "recent_activity": {
            "recent_users": recent_users[:5],
            "recent_payments": recent_payments[:5],
            "recent_jobs": []
        },
        "generated_at": datetime.utcnow().isoformat()
    })

# -----------------------------------------------------------------------------
# Admin dashboard command-center helpers (safe aggregate reads)
# -----------------------------------------------------------------------------

async def _admin_table_exists(db: AsyncSession, table_name: str) -> bool:
    try:
        bind = db.get_bind()
        dialect = bind.dialect.name if bind is not None else ""
        if dialect == "sqlite":
            result = await db.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name=:table_name"), {"table_name": table_name})
            return result.scalar() is not None
        result = await db.execute(text("SELECT to_regclass(:table_name)"), {"table_name": table_name})
        return result.scalar() is not None
    except Exception:
        await db.rollback()
        return False


async def _admin_safe_scalar(db: AsyncSession, sql: str, params: Optional[dict[str, Any]] = None, default: Any = 0) -> Any:
    try:
        result = await db.execute(text(sql), params or {})
        value = result.scalar()
        return default if value is None else value
    except Exception:
        await db.rollback()
        return default


async def _admin_safe_rows(db: AsyncSession, sql: str, params: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    try:
        result = await db.execute(text(sql), params or {})
        return [{key: _serialize(value) for key, value in dict(row._mapping).items()} for row in result.fetchall()]
    except Exception:
        await db.rollback()
        return []


def _admin_serialize_row(row: Any) -> dict[str, Any]:
    try:
        raw = dict(row._mapping) if hasattr(row, "_mapping") else dict(row)
    except Exception:
        return {}
    return {key: _serialize(value) for key, value in raw.items()}


# Keep datetimes JSON-safe for dashboard payloads.
def _admin_iso(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)

@router.get("/dashboard/summary")
async def get_admin_dashboard_summary(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    now = datetime.utcnow()

    async def has_table(name: str) -> bool:
        return await _admin_table_exists(db, name)

    async def has_col(table: str, column: str) -> bool:
        return await table_has_column(db, table, column)

    # Users
    total_users = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM users", default=0) if await has_table("users") else 0)
    if await has_col("users", "is_active"):
        active_users = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM users WHERE COALESCE(is_active, true) = true", default=total_users))
    else:
        active_users = total_users
    admin_users = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM users WHERE LOWER(COALESCE(role, '')) = 'admin'", default=0) if await has_table("users") else 0)
    new_users_today = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM users WHERE created_at::date = CURRENT_DATE", default=0) if await has_col("users", "created_at") else 0)
    new_users_7d = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM users WHERE created_at >= (NOW() - INTERVAL '7 days')", default=0) if await has_col("users", "created_at") else 0)

    # Billing and credits
    payment_table = "payments" if await has_table("payments") else None
    orders_table = "billing_orders" if await has_table("billing_orders") else None
    paid_status_sql = "('paid','captured','success','succeeded')"
    refunded_status_sql = "('refunded','refund','partially_refunded')"
    failed_status_sql = "('failed','cancelled','canceled')"

    total_revenue = float(await _admin_safe_scalar(db, f"SELECT COALESCE(SUM(amount_inr),0) FROM {payment_table} WHERE LOWER(COALESCE(status,'')) IN {paid_status_sql}", default=0) if payment_table else 0)
    paid_revenue = total_revenue
    refunded_amount = float(await _admin_safe_scalar(db, f"SELECT COALESCE(SUM(amount_inr),0) FROM {payment_table} WHERE LOWER(COALESCE(status,'')) IN {refunded_status_sql}", default=0) if payment_table else 0)
    failed_amount = float(await _admin_safe_scalar(db, f"SELECT COALESCE(SUM(amount_inr),0) FROM {payment_table} WHERE LOWER(COALESCE(status,'')) IN {failed_status_sql}", default=0) if payment_table else 0)

    if orders_table:
        total_orders = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM billing_orders", default=0))
        paid_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM billing_orders WHERE LOWER(COALESCE(status,'')) IN {paid_status_sql}", default=0))
        failed_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM billing_orders WHERE LOWER(COALESCE(status,'')) IN {failed_status_sql}", default=0))
        refunded_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM billing_orders WHERE LOWER(COALESCE(status,'')) IN {refunded_status_sql}", default=0))
    elif payment_table:
        total_orders = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM payments", default=0))
        paid_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM payments WHERE LOWER(COALESCE(status,'')) IN {paid_status_sql}", default=0))
        failed_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM payments WHERE LOWER(COALESCE(status,'')) IN {failed_status_sql}", default=0))
        refunded_orders = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM payments WHERE LOWER(COALESCE(status,'')) IN {refunded_status_sql}", default=0))
    else:
        total_orders = paid_orders = failed_orders = refunded_orders = 0

    active_subscriptions = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM user_subscriptions WHERE LOWER(COALESCE(status,'')) = 'active'", default=0) if await has_table("user_subscriptions") else 0)
    expired_subscriptions = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM user_subscriptions WHERE LOWER(COALESCE(status,'')) IN ('expired','cancelled','canceled','inactive')", default=0) if await has_table("user_subscriptions") else 0)

    if await has_table("credit_transactions"):
        total_credits_issued = float(await _admin_safe_scalar(db, "SELECT COALESCE(SUM(amount),0) FROM credit_transactions WHERE LOWER(transaction_type::text) IN ('credit','refund')", default=0))
        total_credits_used = float(await _admin_safe_scalar(db, "SELECT COALESCE(SUM(amount),0) FROM credit_transactions WHERE LOWER(transaction_type::text) = 'debit'", default=0))
    else:
        total_credits_issued = total_credits_used = 0

    # Strategies and requests
    total_strategies = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategies", default=0) if await has_table("strategies") else 0)
    published_strategies = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategies WHERE UPPER(COALESCE(visibility,'')) = 'PUBLIC' OR UPPER(COALESCE(lifecycle_status,'')) = 'PUBLISHED'", default=0) if await has_table("strategies") else 0)
    private_strategies = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategies WHERE UPPER(COALESCE(visibility,'')) <> 'PUBLIC' AND UPPER(COALESCE(lifecycle_status,'')) <> 'PUBLISHED'", default=0) if await has_table("strategies") else 0)
    if await has_table("strategy_requests"):
        pending_strategy_requests = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_requests WHERE UPPER(COALESCE(status,'')) IN ('PENDING','UNDER_DEVELOPMENT','NEEDS_CLARIFICATION')", default=0))
        approved_strategy_requests = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_requests WHERE UPPER(COALESCE(status,'')) IN ('APPROVED','DEPLOYED')", default=0))
        rejected_strategy_requests = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_requests WHERE UPPER(COALESCE(status,'')) = 'REJECTED'", default=0))
    else:
        pending_strategy_requests = approved_strategy_requests = rejected_strategy_requests = 0

    # Backtests
    backtest_table = "performance_metrics" if await has_table("performance_metrics") else "backtests" if await has_table("backtests") else None
    if backtest_table:
        total_backtests = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table}", default=0))
        completed_backtests = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table} WHERE LOWER(COALESCE(status,'')) IN ('completed','success','done')", default=0))
        failed_backtests = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table} WHERE LOWER(COALESCE(status,'')) IN ('failed','error')", default=0))
        running_backtests = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table} WHERE LOWER(COALESCE(status,'')) IN ('running','queued','pending','processing')", default=0))
        backtests_today = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table} WHERE created_at::date = CURRENT_DATE", default=0) if await has_col(backtest_table, "created_at") else 0)
        backtests_7d = int(await _admin_safe_scalar(db, f"SELECT COUNT(*) FROM {backtest_table} WHERE created_at >= (NOW() - INTERVAL '7 days')", default=0) if await has_col(backtest_table, "created_at") else 0)
    else:
        total_backtests = completed_backtests = failed_backtests = running_backtests = backtests_today = backtests_7d = 0

    # Broker accounts
    if await has_table("broker_accounts"):
        total_broker_accounts = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM broker_accounts", default=0))
        connected_broker_accounts = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM broker_accounts WHERE UPPER(COALESCE(status,'')) IN ('CONNECTED','ACTIVE','READY')", default=0))
        failed_broker_accounts = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM broker_accounts WHERE UPPER(COALESCE(status,'')) IN ('FAILED','ERROR','DISCONNECTED')", default=0))
        broker_breakdown = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT COALESCE(broker_name, broker_code, 'Unknown') AS broker, COUNT(*)::int AS total, SUM(CASE WHEN UPPER(COALESCE(status,'')) IN ('CONNECTED','ACTIVE','READY') THEN 1 ELSE 0 END)::int AS connected FROM broker_accounts GROUP BY COALESCE(broker_name, broker_code, 'Unknown') ORDER BY total DESC LIMIT 8")]
    else:
        total_broker_accounts = connected_broker_accounts = failed_broker_accounts = 0
        broker_breakdown = []

    # Live trading
    if await has_table("strategy_deployments"):
        total_deployments = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_deployments", default=0))
        running_deployments = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_deployments WHERE UPPER(COALESCE(status,'')) IN ('RUNNING','ACTIVE','STARTED')", default=0))
        paused_deployments = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_deployments WHERE UPPER(COALESCE(status,'')) = 'PAUSED'", default=0))
        stopped_deployments = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM strategy_deployments WHERE UPPER(COALESCE(status,'')) IN ('STOPPED','DRAFT','INACTIVE')", default=0))
        live_sync_enabled_users = int(await _admin_safe_scalar(db, "SELECT COUNT(DISTINCT user_id) FROM strategy_deployments WHERE COALESCE(live_sync_enabled,false) = true", default=0)) if await has_col("strategy_deployments", "live_sync_enabled") else 0
        approval_required_users = int(await _admin_safe_scalar(db, "SELECT COUNT(DISTINCT user_id) FROM strategy_deployments WHERE COALESCE(live_approved,false) = false", default=0)) if await has_col("strategy_deployments", "live_approved") else 0
    else:
        total_deployments = running_deployments = paused_deployments = stopped_deployments = live_sync_enabled_users = approval_required_users = 0

    if await has_table("live_orders"):
        orders_today = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_orders WHERE created_at::date = CURRENT_DATE", default=0))
        orders_total = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_orders", default=0))
        successful_orders = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_orders WHERE UPPER(COALESCE(status,'')) IN ('FILLED','SUCCESS','PLACED','EXECUTED')", default=0))
        failed_live_orders = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_orders WHERE UPPER(COALESCE(status,'')) IN ('FAILED','REJECTED','ERROR')", default=0))
    else:
        orders_today = orders_total = successful_orders = failed_live_orders = 0
    open_positions = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_positions WHERE UPPER(COALESCE(status,'')) = 'OPEN'", default=0) if await has_table("live_positions") else 0)

    # System health
    market_data_symbols = 0
    market_data_rows = 0
    last_market_data_sync = None
    if await has_table("market_data"):
        market_data_rows = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM market_data", default=0))
        market_data_symbols = int(await _admin_safe_scalar(db, "SELECT COUNT(DISTINCT instrument_id) FROM market_data", default=0))
        last_market_data_sync = await _admin_safe_scalar(db, "SELECT MAX(timestamp) FROM market_data", default=None)
    elif await has_table("live_market_candles"):
        market_data_rows = int(await _admin_safe_scalar(db, "SELECT COUNT(*) FROM live_market_candles", default=0))
        market_data_symbols = int(await _admin_safe_scalar(db, "SELECT COUNT(DISTINCT symbol) FROM live_market_candles", default=0))
        last_market_data_sync = await _admin_safe_scalar(db, "SELECT MAX(candle_time) FROM live_market_candles", default=None)
    latest_execution_log_at = await _admin_safe_scalar(db, "SELECT MAX(created_at) FROM live_trade_logs", default=None) if await has_table("live_trade_logs") else None

    # Recent data
    recent_users = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT id::text, email, fullname, role, created_at FROM users ORDER BY created_at DESC LIMIT 5")]
    recent_payments = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT p.id::text, p.user_id::text, u.email AS user_email, u.fullname AS user_name, p.amount_inr AS amount, p.currency, p.status, p.purpose, p.created_at FROM payments p LEFT JOIN users u ON u.id::text = p.user_id::text ORDER BY p.created_at DESC LIMIT 5") if payment_table]
    if orders_table:
        recent_orders = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT o.id::text, o.user_id::text, u.email AS user_email, u.fullname AS user_name, o.billing_order_id AS order_number, o.amount_inr AS amount, o.currency, o.status, o.purpose, o.created_at FROM billing_orders o LEFT JOIN users u ON u.id::text = o.user_id::text ORDER BY o.created_at DESC LIMIT 5")]
    elif payment_table:
        recent_orders = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT p.id::text, p.user_id::text, u.email AS user_email, u.fullname AS user_name, COALESCE(p.razorpay_order_id, p.id::text) AS order_number, p.amount_inr AS amount, p.currency, p.status, p.purpose, p.created_at FROM payments p LEFT JOIN users u ON u.id::text = p.user_id::text ORDER BY p.created_at DESC LIMIT 5")]
    else:
        recent_orders = []
    recent_backtests = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, f"SELECT b.id::text, b.user_id::text, u.email AS user_email, s.name AS strategy_name, b.status, b.return_pct, b.net_profit, b.created_at FROM {backtest_table} b LEFT JOIN users u ON u.id::text = b.user_id::text LEFT JOIN strategies s ON s.id::text = b.strategy_id::text ORDER BY b.created_at DESC LIMIT 5") if backtest_table]
    recent_live_deployments = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT d.id::text, d.user_id::text, u.email AS user_email, d.name, d.instrument, d.mode, d.status, d.created_at FROM strategy_deployments d LEFT JOIN users u ON u.id::text = d.user_id::text ORDER BY d.created_at DESC LIMIT 5") if await has_table("strategy_deployments")]
    recent_broker_connections = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT b.id::text, b.user_id::text, u.email AS user_email, b.broker_name, b.account_label, b.mode, b.status, b.last_connected_at, b.created_at FROM broker_accounts b LEFT JOIN users u ON u.id::text = b.user_id::text ORDER BY COALESCE(b.last_connected_at, b.created_at) DESC LIMIT 5") if await has_table("broker_accounts")]
    recent_strategy_requests = [_admin_serialize_row(row) for row in await _admin_safe_rows(db, "SELECT r.id::text, r.user_id::text, u.email AS user_email, r.title, r.strategy_type, r.market, r.timeframe, r.status, r.created_at FROM strategy_requests r LEFT JOIN users u ON u.id::text = r.user_id::text ORDER BY r.created_at DESC LIMIT 5") if await has_table("strategy_requests")]

    return success_response({
        "users": {
            "total_users": total_users,
            "active_users": active_users,
            "admin_users": admin_users,
            "new_users_today": new_users_today,
            "new_users_7d": new_users_7d,
        },
        "billing": {
            "total_revenue": total_revenue,
            "paid_revenue": paid_revenue,
            "refunded_amount": refunded_amount,
            "failed_amount": failed_amount,
            "total_orders": total_orders,
            "paid_orders": paid_orders,
            "failed_orders": failed_orders,
            "refunded_orders": refunded_orders,
            "active_subscriptions": active_subscriptions,
            "expired_subscriptions": expired_subscriptions,
            "total_credits_issued": int(total_credits_issued),
            "total_credits_used": int(total_credits_used),
        },
        "strategies": {
            "total_strategies": total_strategies,
            "published_strategies": published_strategies,
            "private_strategies": private_strategies,
            "pending_strategy_requests": pending_strategy_requests,
            "approved_strategy_requests": approved_strategy_requests,
            "rejected_strategy_requests": rejected_strategy_requests,
        },
        "backtests": {
            "total_backtests": total_backtests,
            "completed_backtests": completed_backtests,
            "failed_backtests": failed_backtests,
            "running_backtests": running_backtests,
            "backtests_today": backtests_today,
            "backtests_7d": backtests_7d,
        },
        "brokers": {
            "total_broker_accounts": total_broker_accounts,
            "connected_broker_accounts": connected_broker_accounts,
            "failed_broker_accounts": failed_broker_accounts,
            "broker_breakdown": broker_breakdown,
        },
        "live_trading": {
            "total_deployments": total_deployments,
            "running_deployments": running_deployments,
            "paused_deployments": paused_deployments,
            "stopped_deployments": stopped_deployments,
            "live_sync_enabled_users": live_sync_enabled_users,
            "approval_required_users": approval_required_users,
            "orders_today": orders_today,
            "orders_total": orders_total,
            "successful_orders": successful_orders,
            "failed_orders": failed_live_orders,
            "open_positions": open_positions,
        },
        "system": {
            "market_data_symbols": market_data_symbols,
            "market_data_rows": market_data_rows,
            "last_market_data_sync": _admin_iso(last_market_data_sync),
            "latest_execution_log_at": _admin_iso(latest_execution_log_at),
            "api_health": "ok",
        },
        "recent": {
            "recent_users": recent_users,
            "recent_payments": recent_payments,
            "recent_orders": recent_orders,
            "recent_backtests": recent_backtests,
            "recent_live_deployments": recent_live_deployments,
            "recent_broker_connections": recent_broker_connections,
            "recent_strategy_requests": recent_strategy_requests,
        },
        "generated_at": now.isoformat(),
    })


@router.get("/users")
async def get_admin_users(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    query = select(User)
    count_query = select(func.count()).select_from(User)
    if search:
        search_filter = or_(
            User.email.ilike(f"%{search}%"),
            User.fullname.ilike(f"%{search}%"),
            User.mobile.ilike(f"%{search}%"),
        )
        query = query.where(search_filter)
        count_query = count_query.where(search_filter)

    rows = (await db.execute(query.order_by(User.created_at.desc()).offset(skip).limit(limit))).scalars().all()
    total = (await db.execute(count_query)).scalar() or 0
    user_ids = [str(row.id) for row in rows]
    balances = await _get_credit_balance_map(db, user_ids)
    subs = await _get_subscription_map(db, user_ids)

    items = []
    for user in rows:
        uid = str(user.id)
        items.append(
            {
                "id": uid,
                "email": user.email,
                "role": user.role,
                "is_active": await _user_is_active_value(db, user),
                "fullname": user.fullname,
                "mobile": user.mobile,
                "plan": subs.get(uid, {}).get("plan", "FREE"),
                "billing_period": subs.get(uid, {}).get("billing_period", "NONE"),
                "subscription_status": subs.get(uid, {}).get("status"),
                "credits": balances.get(uid, 0),
                "created_at": _serialize(user.created_at),
            }
        )
    return success_response({"items": items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items else None)


@router.post("/users", status_code=201)
async def create_admin_user(
    payload: UserCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    exists = (await db.execute(select(User).where(User.email == payload.email))).scalar_one_or_none()
    if exists:
        raise HTTPException(status_code=400, detail="User with this email already exists")

    password_hash = bcrypt.hashpw(payload.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    user = User(
        email=payload.email,
        password_hash=password_hash,
        role=payload.role,
        fullname=payload.fullname,
        mobile=payload.mobile,
    )
    db.add(user)
    await db.flush()
    await _ensure_user_credit_row(db, str(user.id))
    await db.commit()
    await db.refresh(user)
    return success_response({"user": {"id": str(user.id), "email": user.email}}, "User created successfully")


@router.put("/users/{user_id}")
async def update_admin_user(
    user_id: str,
    payload: UserUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    user = (await db.execute(select(User).where(column_text(User.id) == str(user_id)))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, key, value)
    await db.commit()
    await db.refresh(user)
    return success_response({}, "User updated successfully")


@router.delete("/users/{user_id}")
async def delete_admin_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
    admin_user: dict = Depends(get_admin_user),
):
    user = (await db.execute(select(User).where(column_text(User.id) == str(user_id)))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if str(user.id) == str(current_user.get("user_id")):
        raise HTTPException(status_code=400, detail="You cannot delete your own admin account")

    await db.execute(delete(UserCredit).where(column_text(UserCredit.user_id) == str(user.id)))
    await db.execute(delete(UserSubscription).where(column_text(UserSubscription.user_id) == str(user.id)))
    await db.execute(delete(Payment).where(cast(Payment.user_id, String) == str(user.id)))
    await db.execute(delete(CreditTransaction).where(CreditTransaction.user_id == user.id))
    await db.execute(delete(StrategyRequest).where(StrategyRequest.user_id == user.id))
    await db.execute(delete(User).where(User.id == user.id))
    await db.commit()
    return success_response({}, "User deleted successfully")


@router.patch("/users/{user_id}/status")
async def patch_admin_user_status(
    user_id: str,
    payload: UserStatusRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    user = (await db.execute(select(User).where(column_text(User.id) == str(user_id)))).scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not await table_has_column(db, "users", "is_active"):
        raise HTTPException(status_code=400, detail="users.is_active column is missing in database")
    await db.execute(text("UPDATE users SET is_active = :is_active WHERE id = :user_id"), {"user_id": user_id, "is_active": payload.is_active})
    await db.commit()
    return success_response({}, f"User {'activated' if payload.is_active else 'deactivated'} successfully")


@router.patch("/users/{user_id}/role")
async def patch_admin_user_role(
    user_id: str,
    payload: UserRoleRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    user = await db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = payload.role
    await db.commit()
    return success_response({}, "User role updated successfully")


@router.post("/credits/add")
async def add_credits(payload: CreditAdjustRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    return await _adjust_credits(
        db,
        payload.user_id,
        payload.amount,
        payload.reason,
        CreditTransactionType.CREDIT,
        actor_user_id=str(current_user.get("user_id")) if current_user else None,
        source="admin_manual_add",
    )


@router.post("/credits/deduct")
async def deduct_credits(payload: CreditAdjustRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    return await _adjust_credits(
        db,
        payload.user_id,
        payload.amount,
        payload.reason,
        CreditTransactionType.DEBIT,
        actor_user_id=str(current_user.get("user_id")) if current_user else None,
        source="admin_manual_deduct",
    )


@router.get("/credits/balances")
async def get_credit_balances(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    stmt = (
        select(UserCredit, User.email, User.fullname)
        .outerjoin(User, cast(User.id, String) == cast(UserCredit.user_id, String))
        .order_by(UserCredit.updated_at.desc())
        .offset(skip)
        .limit(limit)
    )
    count_stmt = select(func.count()).select_from(UserCredit)

    if search:
        like = f"%{search}%"
        filters = or_(
            cast(UserCredit.user_id, String).ilike(like),
            User.email.ilike(like),
            User.fullname.ilike(like),
        )
        stmt = stmt.where(filters)
        count_stmt = count_stmt.outerjoin(User, cast(User.id, String) == cast(UserCredit.user_id, String)).where(filters)

    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = [
        {
            "user_id": str(credit.user_id),
            "user_email": email or "—",
            "user_name": fullname or email or "—",
            "balance": int(credit.balance or 0),
            "updated_at": _serialize(getattr(credit, "updated_at", None)),
        }
        for credit, email, fullname in rows
    ]
    return success_response({"items": items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items else None)


@router.get("/credits/ledger")
async def get_credit_ledger(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    transaction_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    has_actor_user_id = await table_has_column(db, "credit_transactions", "actor_user_id")
    has_source = await table_has_column(db, "credit_transactions", "source")

    source_expr = "CAST(tx.source AS TEXT)" if has_source else "NULL"
    actor_expr = "CAST(tx.actor_user_id AS TEXT)" if has_actor_user_id else "NULL"

    where_clauses: list[str] = []
    bind_params: dict[str, Any] = {"skip": skip, "limit": limit}

    if search:
        bind_params["search"] = f"%{search}%"
        where_clauses.append(
            "(u.email ILIKE :search OR u.fullname ILIKE :search OR tx.description ILIKE :search)"
        )

    if transaction_type:
        bind_params["txn_type"] = transaction_type.strip().lower()
        where_clauses.append("LOWER(CAST(tx.transaction_type AS TEXT)) = :txn_type")

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    rows = (
        await db.execute(
            text(
                f"""
                SELECT
                    tx.id,
                    CAST(tx.user_id AS TEXT) AS user_id,
                    CAST(tx.transaction_type AS TEXT) AS transaction_type,
                    tx.amount,
                    tx.balance_after,
                    tx.description,
                    tx.created_at,
                    {source_expr} AS source,
                    {actor_expr} AS actor_user_id,
                    u.email AS user_email,
                    u.fullname AS user_name
                FROM credit_transactions tx
                LEFT JOIN users u ON CAST(u.id AS TEXT) = CAST(tx.user_id AS TEXT)
                {where_sql}
                ORDER BY tx.created_at DESC
                OFFSET :skip
                LIMIT :limit
                """
            ),
            bind_params,
        )
    ).mappings().all()

    total = (
        await db.execute(
            text(
                f"""
                SELECT COUNT(*)
                FROM credit_transactions tx
                LEFT JOIN users u ON CAST(u.id AS TEXT) = CAST(tx.user_id AS TEXT)
                {where_sql}
                """
            ),
            {k: v for k, v in bind_params.items() if k not in {"skip", "limit"}},
        )
    ).scalar() or 0

    items = []
    for txn in rows:
        txn_type = str(txn.get("transaction_type") or "").strip().lower()
        balance_after = int(txn.get("balance_after") or 0)
        credit = int(txn.get("amount") or 0)
        is_debit = txn_type == CreditTransactionType.DEBIT.value
        debit_used = credit if is_debit else 0
        credit_added = credit if not is_debit else 0
        items.append(
            {
                "id": str(txn.get("id")),
                "user_id": str(txn.get("user_id")),
                "user_email": txn.get("user_email") or "—",
                "user_name": txn.get("user_name") or txn.get("user_email") or "—",
                "credits": credit_added if not is_debit else -credit,
                "credits_added": credit_added,
                "credits_used": debit_used,
                "remaining_credits": balance_after,
                "type": txn_type,
                "source": txn.get("source") or txn_type,
                "source_type": txn.get("source"),
                "actor_user_id": str(txn.get("actor_user_id")) if txn.get("actor_user_id") else None,
                "reason": txn.get("description"),
                "balance_after": balance_after,
                "created_at": _serialize(txn.get("created_at")),
            }
        )
    return success_response({"items": items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items else None)


@router.get("/payments")
async def get_payments(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    search: Optional[str] = None,
    method: Optional[str] = None,
    purpose: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    stmt = (
        select(Payment, User.email, User.fullname)
        .outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String))
        .order_by(Payment.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    count_stmt = select(func.count()).select_from(Payment)
    filters = []
    if status:
        filters.append(Payment.status == status)
    if search:
        like = f"%{search}%"
        filters.append(
            or_(
                Payment.razorpay_order_id.ilike(like),
                Payment.razorpay_payment_id.ilike(like),
                Payment.provider.ilike(like),
                Payment.purpose.ilike(like),
                User.email.ilike(like),
                User.fullname.ilike(like),
            )
        )
    if method:
        filters.append(func.lower(Payment.provider) == method.strip().lower())
    if purpose:
        filters.append(func.lower(Payment.purpose) == purpose.strip().lower())

    from_dt = _parse_iso_datetime(from_date, field_name="from_date")
    to_dt = _parse_iso_datetime(to_date, field_name="to_date")
    if from_dt:
        filters.append(Payment.created_at >= from_dt)
    if to_dt:
        filters.append(Payment.created_at <= to_dt)
    if filters:
        for flt in filters:
            stmt = stmt.where(flt)
        count_stmt = count_stmt.outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String)).where(*filters)
    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = []
    for payment, email, fullname in rows:
        items.append(
            {
                "id": str(payment.id),
                "user_id": str(payment.user_id),
                "user_email": email or "—",
                "user_name": fullname or email or "—",
                "amount": int(payment.amount_inr or 0),
                "currency": payment.currency or "INR",
                "status": payment.status,
                "payment_method": payment.provider,
                "purpose": payment.purpose,
                "transaction_id": payment.razorpay_payment_id,
                "razorpay_order_id": payment.razorpay_order_id,
                "razorpay_payment_id": payment.razorpay_payment_id,
                "billing_order_id": payment.billing_order_id,
                "verified_at": _serialize(getattr(payment, "verified_at", None)),
                "failure_reason": payment.failure_reason,
                "is_reconciled": bool((payment.status or "").upper() == "PAID" and getattr(payment, "verified_at", None)),
                "created_at": _serialize(payment.created_at),
                "updated_at": _serialize(getattr(payment, "updated_at", None)),
            }
        )
    return success_response({"items": items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items else None)


@router.get("/payments/{payment_id}")
async def get_payment_detail(payment_id: str, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    row = (
        await db.execute(
            select(Payment, User.email, User.fullname).outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String)).where(cast(Payment.id, String) == str(payment_id))
        )
    ).first()
    if not row:
        raise HTTPException(status_code=404, detail="Payment not found")
    payment, email, fullname = row
    return success_response({
        "id": str(payment.id),
        "user_id": str(payment.user_id),
        "user_email": email or "—",
        "user_name": fullname or email or "—",
        "amount": int(payment.amount_inr or 0),
        "currency": payment.currency or "INR",
        "status": payment.status,
        "payment_method": payment.provider,
        "purpose": payment.purpose,
        "transaction_id": payment.razorpay_payment_id,
        "razorpay_order_id": payment.razorpay_order_id,
        "razorpay_payment_id": payment.razorpay_payment_id,
        "billing_order_id": payment.billing_order_id,
        "verified_at": _serialize(getattr(payment, "verified_at", None)),
        "failure_reason": payment.failure_reason,
        "reconciliation": {
            "is_reconciled": bool((payment.status or "").upper() == "PAID" and getattr(payment, "verified_at", None)),
            "status": "reconciled" if ((payment.status or "").upper() == "PAID" and getattr(payment, "verified_at", None)) else "pending",
            "provider": payment.provider,
            "purpose": payment.purpose,
        },
        "created_at": _serialize(payment.created_at),
        "updated_at": _serialize(getattr(payment, "updated_at", None)),
    })


@router.post("/payments/{payment_id}/refund")
async def refund_payment(payment_id: str, payload: PaymentRefundRequest | None = None, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    payment = (await db.execute(select(Payment).where(cast(Payment.id, String) == str(payment_id)))).scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    if (payment.status or "").upper() == "REFUNDED":
        return success_response({}, "Payment already refunded")

    payment.status = "REFUNDED"
    if payload and payload.note:
        existing_reason = payment.failure_reason or ""
        note = f"Admin refund note: {payload.note.strip()}"
        payment.failure_reason = f"{existing_reason}\n{note}".strip()
    await db.commit()
    return success_response({}, "Payment marked as refunded")


@router.get("/subscriptions")
async def get_subscriptions(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    stmt = (
        select(UserSubscription, Plan, User.email, User.fullname)
        .outerjoin(Plan, Plan.id == UserSubscription.plan_id)
        .outerjoin(User, cast(User.id, String) == cast(UserSubscription.user_id, String))
        .order_by(UserSubscription.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    count_stmt = select(func.count()).select_from(UserSubscription)
    filters = []
    if status:
        filters.append(UserSubscription.status == status)
    if search:
        like = f"%{search}%"
        filters.append(or_(User.email.ilike(like), User.fullname.ilike(like), Plan.code.ilike(like)))
    if filters:
        stmt = stmt.where(*filters)
        count_stmt = count_stmt.outerjoin(User, cast(User.id, String) == cast(UserSubscription.user_id, String)).outerjoin(Plan, Plan.id == UserSubscription.plan_id).where(*filters)
    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = []
    for sub, plan, email, fullname in rows:
        items.append(
            {
                "id": str(sub.id),
                "user_id": str(sub.user_id),
                "user_email": email or "—",
                "user_name": fullname or email or "—",
                "plan_id": str(sub.plan_id),
                "plan": str(getattr(sub, "plan_code_snapshot", None) or getattr(plan, "code", None) or "FREE").upper(),
                "plan_code": str(getattr(sub, "plan_code_snapshot", None) or getattr(plan, "code", None) or "FREE").upper(),
                "billing_period": str(getattr(sub, "billing_period_snapshot", None) or getattr(plan, "billing_period", None) or "NONE").upper(),
                "amount": int(getattr(sub, "plan_price_inr", None) or getattr(plan, "price_inr", 0) or 0),
                "price_inr": int(getattr(sub, "plan_price_inr", None) or getattr(plan, "price_inr", 0) or 0),
                "included_credits": int(getattr(sub, "included_credits_total", None) or getattr(plan, "included_credits", 0) or 0),
                "included_credits_total": int(getattr(sub, "included_credits_total", None) or getattr(plan, "included_credits", 0) or 0),
                "included_credits_remaining": int(getattr(sub, "included_credits_remaining", None) or 0),
                "status": sub.status,
                "start_date": _serialize(sub.start_at),
                "end_date": _serialize(sub.end_at),
                "start_at": _serialize(sub.start_at),
                "end_at": _serialize(sub.end_at),
                "renews": sub.renews,
                "next_credit_refill_at": _serialize(getattr(sub, "next_credit_refill_at", None)),
                "last_credit_refill_at": _serialize(getattr(sub, "last_credit_refill_at", None)),
                "created_at": _serialize(sub.created_at),
            }
        )
    return success_response({"items": items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items else None)


@router.patch("/subscriptions/{subscription_id}")
async def update_subscription(subscription_id: str, payload: SubscriptionUpdateRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    subscription = (await db.execute(select(UserSubscription).where(cast(UserSubscription.id, String) == str(subscription_id)))).scalar_one_or_none()
    if not subscription:
        raise HTTPException(status_code=404, detail="Subscription not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(subscription, key, value)
    await db.commit()
    return success_response({}, "Subscription updated successfully")


@router.get("/orders")
async def get_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    search: Optional[str] = None,
    source_type: Optional[str] = None,
    method: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    has_billing_orders = await table_has_column(db, "billing_orders", "id")
    skip = (page - 1) * page_size
    if has_billing_orders:
        stmt = (
            select(BillingOrder, User.email, User.fullname)
            .outerjoin(User, cast(User.id, String) == cast(BillingOrder.user_id, String))
            .order_by(BillingOrder.created_at.desc())
            .offset(skip)
            .limit(page_size)
        )
        count_stmt = select(func.count()).select_from(BillingOrder)
    else:
        stmt = (
            select(Payment, User.email, User.fullname)
            .outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String))
            .order_by(Payment.created_at.desc())
            .offset(skip)
            .limit(page_size)
        )
        count_stmt = select(func.count()).select_from(Payment)

    filters = []
    if status:
        filters.append((BillingOrder.status if has_billing_orders else Payment.status) == status)
    if search:
        like = f"%{search}%"
        if has_billing_orders:
            filters.append(
                or_(
                    BillingOrder.billing_order_id.ilike(like),
                    BillingOrder.razorpay_order_id.ilike(like),
                    BillingOrder.razorpay_payment_id.ilike(like),
                    BillingOrder.purpose.ilike(like),
                    User.email.ilike(like),
                    User.fullname.ilike(like),
                )
            )
        else:
            filters.append(or_(Payment.razorpay_order_id.ilike(like), Payment.razorpay_payment_id.ilike(like), Payment.purpose.ilike(like), User.email.ilike(like), User.fullname.ilike(like)))
    if source_type:
        filters.append(func.lower(BillingOrder.purpose if has_billing_orders else Payment.purpose) == source_type.strip().lower())
    if method:
        filters.append(func.lower(BillingOrder.provider if has_billing_orders else Payment.provider) == method.strip().lower())

    from_dt = _parse_iso_datetime(from_date, field_name="from_date")
    to_dt = _parse_iso_datetime(to_date, field_name="to_date")
    if from_dt:
        filters.append((BillingOrder.created_at if has_billing_orders else Payment.created_at) >= from_dt)
    if to_dt:
        filters.append((BillingOrder.created_at if has_billing_orders else Payment.created_at) <= to_dt)

    if filters:
        stmt = stmt.where(*filters)
        if has_billing_orders:
            count_stmt = count_stmt.outerjoin(User, cast(User.id, String) == cast(BillingOrder.user_id, String)).where(*filters)
        else:
            count_stmt = count_stmt.outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String)).where(*filters)

    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = []
    if has_billing_orders:
        for order, email, fullname in rows:
            items.append(
                {
                    "id": str(order.id),
                    "user_id": str(order.user_id),
                    "user_email": email or "—",
                    "user_name": fullname or email or "—",
                    "order_number": order.billing_order_id or order.razorpay_order_id or str(order.id),
                    "order_type": order.purpose,
                    "source_type": order.purpose,
                    "status": order.status,
                    "total_amount": int(order.amount_inr or 0),
                    "currency": order.currency or "INR",
                    "payment_method": order.provider,
                    "transaction_id": order.razorpay_payment_id,
                    "linked_payment_id": order.payment_id,
                    "linked_payment_status": order.status,
                    "reconciliation_status": "reconciled" if ((order.status or "").upper() == "PAID" and getattr(order, "verified_at", None)) else "pending",
                    "created_at": _serialize(order.created_at),
                    "updated_at": _serialize(getattr(order, "updated_at", None)),
                }
            )
    else:
        for payment, email, fullname in rows:
            items.append(
                {
                    "id": str(payment.id),
                    "user_id": str(payment.user_id),
                    "user_email": email or "—",
                    "user_name": fullname or email or "—",
                    "order_number": payment.razorpay_order_id or str(payment.id),
                    "order_type": payment.purpose,
                    "source_type": payment.purpose,
                    "status": payment.status,
                    "total_amount": int(payment.amount_inr or 0),
                    "currency": payment.currency or "INR",
                    "payment_method": payment.provider,
                    "transaction_id": payment.razorpay_payment_id,
                    "linked_payment_id": str(payment.id),
                    "linked_payment_status": payment.status,
                    "reconciliation_status": "reconciled" if ((payment.status or "").upper() == "PAID" and getattr(payment, "verified_at", None)) else "pending",
                    "created_at": _serialize(payment.created_at),
                    "updated_at": _serialize(getattr(payment, "updated_at", None)),
                }
            )

    return success_response({"items": items, "total": total, "page": page, "page_size": page_size, "total_pages": (total + page_size - 1) // page_size}, "No data found" if not items else None)


@router.get("/orders/{order_id}")
async def get_order_detail(order_id: str, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    has_billing_orders = await table_has_column(db, "billing_orders", "id")
    if has_billing_orders:
        row = (
            await db.execute(
                select(BillingOrder, User.email, User.fullname)
                .outerjoin(User, cast(User.id, String) == cast(BillingOrder.user_id, String))
                .where(or_(cast(BillingOrder.id, String) == str(order_id), BillingOrder.billing_order_id == str(order_id)))
            )
        ).first()
        if row:
            order, email, fullname = row
            return success_response({
                "id": str(order.id),
                "user_id": str(order.user_id),
                "user_email": email or "—",
                "user_name": fullname or email or "—",
                "order_number": order.billing_order_id or order.razorpay_order_id or str(order.id),
                "order_type": order.purpose,
                "source_type": order.purpose,
                "status": order.status,
                "total_amount": int(order.amount_inr or 0),
                "currency": order.currency or "INR",
                "payment_method": order.provider,
                "transaction_id": order.razorpay_payment_id,
                "linked_payment_id": order.payment_id,
                "linked_payment_status": order.status,
                "billing_order_id": order.billing_order_id,
                "reconciliation": {
                    "status": "reconciled" if ((order.status or "").upper() == "PAID" and getattr(order, "verified_at", None)) else "pending",
                    "verified_at": _serialize(getattr(order, "verified_at", None)),
                    "failure_reason": order.failure_reason,
                },
                "created_at": _serialize(order.created_at),
                "updated_at": _serialize(getattr(order, "updated_at", None)),
                "items": [],
            })

    row = (
        await db.execute(
            select(Payment, User.email, User.fullname).outerjoin(User, cast(User.id, String) == cast(Payment.user_id, String)).where(cast(Payment.id, String) == str(order_id))
        )
    ).first()
    if not row:
        raise HTTPException(status_code=404, detail="Order not found")
    payment, email, fullname = row
    return success_response({
        "id": str(payment.id),
        "user_id": str(payment.user_id),
        "user_email": email or "—",
        "user_name": fullname or email or "—",
        "order_number": payment.razorpay_order_id or str(payment.id),
        "order_type": payment.purpose,
        "source_type": payment.purpose,
        "status": payment.status,
        "total_amount": int(payment.amount_inr or 0),
        "currency": payment.currency or "INR",
        "payment_method": payment.provider,
        "transaction_id": payment.razorpay_payment_id,
        "linked_payment_id": str(payment.id),
        "linked_payment_status": payment.status,
        "billing_order_id": payment.billing_order_id,
        "reconciliation": {
            "status": "reconciled" if ((payment.status or "").upper() == "PAID" and getattr(payment, "verified_at", None)) else "pending",
            "verified_at": _serialize(getattr(payment, "verified_at", None)),
            "failure_reason": payment.failure_reason,
        },
        "created_at": _serialize(payment.created_at),
        "updated_at": _serialize(getattr(payment, "updated_at", None)),
        "items": [],
    })


@router.patch("/orders/{order_id}/status")
async def update_order_status(order_id: str, payload: OrderStatusRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    has_billing_orders = await table_has_column(db, "billing_orders", "id")
    if has_billing_orders:
        order = (
            await db.execute(
                select(BillingOrder).where(or_(cast(BillingOrder.id, String) == str(order_id), BillingOrder.billing_order_id == str(order_id)))
            )
        ).scalar_one_or_none()
        if order:
            order.status = payload.status
            if order.payment_id:
                payment = (
                    await db.execute(select(Payment).where(cast(Payment.id, String) == str(order.payment_id)))
                ).scalar_one_or_none()
                if payment:
                    payment.status = payload.status
            await db.commit()
            return success_response({}, "Order status updated successfully")

    payment = (await db.execute(select(Payment).where(cast(Payment.id, String) == str(order_id)))).scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Order not found")
    payment.status = payload.status
    await db.commit()
    return success_response({}, "Order status updated successfully")


@router.get("/strategies")
async def get_admin_strategies(
    skip: int = 0,
    limit: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    stmt = (
        select(StrategyRequest, User.email, User.fullname)
        .join(User, User.id == StrategyRequest.user_id)
        .order_by(StrategyRequest.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    count_stmt = select(func.count()).select_from(StrategyRequest)
    filters = []
    if status:
        filters.append(StrategyRequest.status == status)
    if search:
        like = f"%{search}%"
        filters.append(or_(StrategyRequest.title.ilike(like), User.email.ilike(like), User.fullname.ilike(like), StrategyRequest.strategy_type.ilike(like)))
    if filters:
        stmt = stmt.where(*filters)
        count_stmt = count_stmt.join(User, User.id == StrategyRequest.user_id).where(*filters)
    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = []
    for req, email, fullname in rows:
        items.append(
            {
                "id": str(req.id),
                "title": req.title,
                "description": req.notes or req.entry_rules,
                "strategy_type": req.strategy_type,
                "market": req.market,
                "timeframe": req.timeframe,
                "status": req.status,
                "user_id": str(req.user_id),
                "user_email": email or "—",
                "user_name": fullname or email or "—",
                "admin_notes": req.admin_notes,
                "created_at": _serialize(req.created_at),
                "updated_at": _serialize(req.updated_at),
            }
        )
    implemented = (
        await db.execute(select(Strategy).order_by(Strategy.created_at.desc()).limit(50))
    ).scalars().all()
    implemented_items = [
        {
            "id": str(item.id),
            "name": item.name,
            "description": item.description,
            "code": item.parameters,
            "status": "ACTIVE",
            "created_at": _serialize(item.created_at),
        }
        for item in implemented
    ]
    return success_response({"items": items, "implemented": implemented_items, "total": total, "skip": skip, "limit": limit}, "No data found" if not items and not implemented_items else None)


@router.patch("/strategies/{request_id}")
async def update_admin_strategy(request_id: str, payload: StrategyDecisionRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    req = await db.get(StrategyRequest, request_id)
    if not req:
        raise HTTPException(status_code=404, detail="Strategy request not found")
    req.status = payload.status
    if payload.admin_notes is not None:
        req.admin_notes = payload.admin_notes
    await db.commit()
    return success_response({}, "Strategy request updated successfully")


class TicketStatusUpdateRequest(BaseModel):
    status: str


class TicketReplyRequest(BaseModel):
    message: str


@router.get("/backtests")
async def get_admin_backtests(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    status: Optional[str] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    strategy_id: Optional[str] = None,
    instrument_id: Optional[int] = None,
    timeframe: Optional[str] = None,
    user_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    filters = []

    if status:
        filters.append(func.lower(PerformanceMetric.status) == status.lower())
    if strategy_id:
        filters.append(PerformanceMetric.strategy_id == strategy_id)
    if instrument_id is not None:
        filters.append(PerformanceMetric.instrument_id == instrument_id)
    if timeframe:
        filters.append(PerformanceMetric.timeframe == timeframe)
    if user_id:
        filters.append(cast(PerformanceMetric.user_id, String) == str(user_id))
    if from_date:
        filters.append(PerformanceMetric.created_at >= from_date)
    if to_date:
        filters.append(PerformanceMetric.created_at <= to_date)

    stmt = (
        select(
            PerformanceMetric,
            Strategy.name.label("strategy_name"),
            Instrument.symbol.label("instrument_symbol"),
            User.email.label("user_email"),
            User.fullname.label("user_name"),
        )
        .outerjoin(Strategy, Strategy.id == PerformanceMetric.strategy_id)
        .outerjoin(Instrument, Instrument.id == PerformanceMetric.instrument_id)
        .outerjoin(User, cast(User.id, String) == cast(PerformanceMetric.user_id, String))
    )

    if search:
        like = f"%{search}%"
        filters.append(
            or_(
                cast(PerformanceMetric.id, String).ilike(like),
                Strategy.name.ilike(like),
                Instrument.symbol.ilike(like),
                User.email.ilike(like),
                User.fullname.ilike(like),
            )
        )

    if filters:
        stmt = stmt.where(*filters)

    count_stmt = select(func.count()).select_from(PerformanceMetric)
    if filters:
        count_stmt = (
            count_stmt
            .outerjoin(Strategy, Strategy.id == PerformanceMetric.strategy_id)
            .outerjoin(Instrument, Instrument.id == PerformanceMetric.instrument_id)
            .outerjoin(User, cast(User.id, String) == cast(PerformanceMetric.user_id, String))
            .where(*filters)
        )

    total = (await db.execute(count_stmt)).scalar() or 0
    offset = (page - 1) * page_size
    rows = (await db.execute(stmt.order_by(PerformanceMetric.created_at.desc()).offset(offset).limit(page_size))).all()

    backtest_ids = [str(metric.id) for metric, _, _, _, _ in rows]
    debit_map = await _get_backtest_billing_snapshot(db, backtest_ids)

    items = []
    for metric, strategy_name, instrument_symbol, user_email, user_name in rows:
        debit = debit_map.get(str(metric.id), {})
        initial_capital = float(metric.initial_capital or 0)
        final_capital = float(metric.final_capital or 0)
        net_profit = float(metric.net_profit or (final_capital - initial_capital))
        total_return = ((net_profit / initial_capital) * 100.0) if initial_capital > 0 else 0.0

        items.append(
            {
                "id": str(metric.id),
                "strategy_id": metric.strategy_id,
                "strategy_name": strategy_name or metric.strategy_id,
                "instrument_id": metric.instrument_id,
                "instrument_symbol": instrument_symbol,
                "timeframe": metric.timeframe,
                "user_id": str(metric.user_id),
                "user_email": user_email or "—",
                "user_name": user_name or user_email or "—",
                "initial_capital": initial_capital,
                "final_capital": final_capital,
                "net_profit": net_profit,
                "total_return": total_return,
                "sharpe_ratio": float(metric.sharpe_ratio or 0),
                "max_drawdown": float(metric.max_drawdown or 0),
                "win_rate": float(metric.win_rate or 0),
                "total_trades": int(metric.total_trades or 0),
                "credit_cost": debit.get("effective_credit_cost", debit.get("credit_cost")),
                "effective_credit_cost": debit.get("effective_credit_cost", debit.get("credit_cost")),
                "included_debited": debit.get("included_debited", 0.0),
                "wallet_debited": debit.get("wallet_debited", 0.0),
                "included_refunded": debit.get("included_refunded", 0.0),
                "wallet_refunded": debit.get("wallet_refunded", 0.0),
                "refund_total": debit.get("refund_total", 0.0),
                "charge_status": debit.get("charge_status", "not_charged"),
                "debit_transaction_id": debit.get("debit_transaction_id"),
                "refund_transaction_ids": debit.get("refund_transaction_ids", []),
                "status": metric.status,
                "created_at": _serialize(metric.created_at),
                "updated_at": _serialize(_safe_attr(metric, "updated_at")),
            }
        )

    total_pages = ceil(total / page_size) if total > 0 else 1
    return {
        "items": items,
        "total": int(total),
        "page": page,
        "page_size": page_size,
        "total_pages": int(total_pages),
    }


@router.get("/backtests/{backtest_id}")
async def get_admin_backtest_detail(
    backtest_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    metric = await db.get(PerformanceMetric, backtest_id)
    if not metric:
        raise HTTPException(status_code=404, detail="Backtest not found")

    strategy_name = (await db.execute(select(Strategy.name).where(Strategy.id == metric.strategy_id))).scalar_one_or_none()
    instrument_symbol = (await db.execute(select(Instrument.symbol).where(Instrument.id == metric.instrument_id))).scalar_one_or_none()

    billing = (await _get_backtest_billing_snapshot(db, [str(metric.id)])).get(str(metric.id), {})

    return success_response(
        {
            "id": str(metric.id),
            "strategy_id": metric.strategy_id,
            "strategy_name": strategy_name,
            "instrument_id": metric.instrument_id,
            "instrument_symbol": instrument_symbol,
            "user_id": str(metric.user_id),
            "timeframe": metric.timeframe,
            "start_date": metric.start_date.isoformat() if metric.start_date else None,
            "end_date": metric.end_date.isoformat() if metric.end_date else None,
            "initial_capital": float(metric.initial_capital or 0),
            "final_capital": float(metric.final_capital or 0),
            "net_profit": float(metric.net_profit or 0),
            "max_drawdown": float(metric.max_drawdown or 0),
            "sharpe_ratio": float(metric.sharpe_ratio or 0),
            "win_rate": float(metric.win_rate or 0),
            "total_trades": int(metric.total_trades or 0),
            "winning_trades": int(metric.winning_trades or 0),
            "losing_trades": int(metric.losing_trades or 0),
            "profit_factor": float(metric.profit_factor or 0),
            "credit_cost": billing.get("effective_credit_cost", billing.get("credit_cost")),
            "effective_credit_cost": billing.get("effective_credit_cost", billing.get("credit_cost")),
            "included_debited": billing.get("included_debited", 0.0),
            "wallet_debited": billing.get("wallet_debited", 0.0),
            "included_refunded": billing.get("included_refunded", 0.0),
            "wallet_refunded": billing.get("wallet_refunded", 0.0),
            "refund_total": billing.get("refund_total", 0.0),
            "charge_status": billing.get("charge_status", "not_charged"),
            "debit_transaction_id": billing.get("debit_transaction_id"),
            "refund_transaction_ids": billing.get("refund_transaction_ids", []),
            "status": metric.status,
            "created_at": _serialize(metric.created_at),
            "updated_at": _serialize(_safe_attr(metric, "updated_at")),
        }
    )


@router.get("/backtests/{backtest_id}/detail")
async def get_admin_backtest_detail_full(
    backtest_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    row = (await db.execute(
        select(PerformanceMetric).options(
            load_only(
                PerformanceMetric.id, PerformanceMetric.user_id, PerformanceMetric.strategy_id, PerformanceMetric.instrument_id,
                PerformanceMetric.timeframe, PerformanceMetric.start_date, PerformanceMetric.end_date,
                PerformanceMetric.initial_capital, PerformanceMetric.final_capital, PerformanceMetric.net_profit,
                PerformanceMetric.max_drawdown, PerformanceMetric.sharpe_ratio, PerformanceMetric.sortino_ratio,
                PerformanceMetric.calmar_ratio, PerformanceMetric.win_rate, PerformanceMetric.total_trades,
                PerformanceMetric.winning_trades, PerformanceMetric.losing_trades, PerformanceMetric.profit_factor,
                PerformanceMetric.period, PerformanceMetric.return_pct, PerformanceMetric.avg_win, PerformanceMetric.avg_loss,
                PerformanceMetric.expectancy, PerformanceMetric.status, PerformanceMetric.created_at
            )
        ).where(PerformanceMetric.id == backtest_id)
    )).scalars().first()
    if not row:
        raise HTTPException(status_code=404, detail="Backtest not found")

    trades = (await db.execute(
        select(Trade).where(cast(Trade.backtest_id, String) == str(backtest_id)).order_by(Trade.entry_time.asc())
    )).scalars().all()
    equity_rows = (await db.execute(
        select(EquityCurve).where(cast(EquityCurve.backtest_id, String) == str(backtest_id)).order_by(EquityCurve.timestamp.asc())
    )).scalars().all()
    pnl_rows = (await db.execute(
        select(PnLCalendar).where(cast(PnLCalendar.backtest_id, String) == str(backtest_id)).order_by(PnLCalendar.date.asc())
    )).scalars().all()

    strategy_name = (await db.execute(select(Strategy.name).where(Strategy.id == row.strategy_id))).scalar_one_or_none()
    instrument_symbol = (await db.execute(select(Instrument.symbol).where(Instrument.id == row.instrument_id))).scalar_one_or_none()
    billing = (await _get_backtest_billing_snapshot(db, [str(row.id)])).get(str(row.id), {})

    summary = {
        "id": str(row.id),
        "strategy_id": row.strategy_id,
        "strategy_name": strategy_name,
        "instrument_id": row.instrument_id,
        "instrument_symbol": instrument_symbol,
        "user_id": str(row.user_id),
        "timeframe": row.timeframe,
        "start_date": row.start_date.isoformat() if row.start_date else None,
        "end_date": row.end_date.isoformat() if row.end_date else None,
        "initial_capital": float(row.initial_capital or 0),
        "final_capital": float(row.final_capital or 0),
        "net_profit": float(row.net_profit or 0),
        "max_drawdown": float(row.max_drawdown or 0),
        "sharpe_ratio": float(row.sharpe_ratio or 0),
        "sortino_ratio": float(getattr(row, "sortino_ratio", 0) or 0),
        "calmar_ratio": float(getattr(row, "calmar_ratio", 0) or 0),
        "win_rate": float(row.win_rate or 0),
        "total_trades": int(row.total_trades or 0),
        "winning_trades": int(row.winning_trades or 0),
        "losing_trades": int(row.losing_trades or 0),
        "profit_factor": float(row.profit_factor or 0),
        "return_pct": float(getattr(row, "return_pct", 0) or 0),
        "avg_win": float(getattr(row, "avg_win", 0) or 0),
        "avg_loss": float(getattr(row, "avg_loss", 0) or 0),
        "expectancy": float(getattr(row, "expectancy", 0) or 0),
        "credit_cost": billing.get("effective_credit_cost", billing.get("credit_cost")),
        "effective_credit_cost": billing.get("effective_credit_cost", billing.get("credit_cost")),
        "included_debited": billing.get("included_debited", 0.0),
        "wallet_debited": billing.get("wallet_debited", 0.0),
        "included_refunded": billing.get("included_refunded", 0.0),
        "wallet_refunded": billing.get("wallet_refunded", 0.0),
        "refund_total": billing.get("refund_total", 0.0),
        "charge_status": billing.get("charge_status", "not_charged"),
        "debit_transaction_id": billing.get("debit_transaction_id"),
        "refund_transaction_ids": billing.get("refund_transaction_ids", []),
        "status": row.status,
        "created_at": _serialize(row.created_at),
        "updated_at": _serialize(_safe_attr(row, "updated_at")),
    }

    return success_response({
        "summary": summary,
        "trades": [
            {
                "id": str(t.id),
                "entry_time": t.entry_time.isoformat() if t.entry_time else None,
                "exit_time": t.exit_time.isoformat() if t.exit_time else None,
                "side": t.side,
                "quantity": _admin_to_int(t.quantity),
                "entry_price": _admin_to_float(t.entry_price),
                "exit_price": _admin_to_float(t.exit_price),
                "pnl": _admin_to_float(t.pnl),
                "exit_type": t.exit_type,
            }
            for t in trades
        ],
        "equity_curve": [
            {
                "timestamp": e.timestamp.isoformat() if e.timestamp else None,
                "equity": _admin_to_float(e.equity),
            }
            for e in equity_rows
        ],
        "pnl_calendar": [
            {
                "date": p.date.isoformat() if p.date else None,
                "pnl": _admin_to_float(p.pnl),
            }
            for p in pnl_rows
        ],
    })


@router.get("/backtests/pricing-config")
async def get_backtest_pricing_config(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    active = await BacktestPricingService.get_active_pricing_config(db)
    items = await BacktestPricingService.list_rule_sets(db)

    return success_response(
        {
            "active": {
                "id": active.get("id"),
                "name": active.get("name"),
                "version": active.get("version"),
                "description": active.get("description"),
                "is_active": active.get("is_active", True),
                "is_locked": active.get("is_locked", False),
                "base_cost": float(active.get("base_cost", 0)),
                "range_days_step": int(active.get("range_days_step", 1)),
                "min_credit_charge": int(active.get("min_credit_charge", 1)),
                "max_credit_charge": active.get("max_credit_charge"),
                "date_range_buckets": active.get("date_range_buckets") or [],
                "timeframe_multipliers": active.get("timeframe_multipliers") or [],
                "strategy_complexity_enabled": bool(active.get("strategy_complexity_enabled", False)),
                "strategy_complexity_step": float(active.get("strategy_complexity_step", 0) or 0),
                "strategy_complexity_cap": float(active.get("strategy_complexity_cap", 0) or 0),
                "plan_discounts": active.get("plan_discounts") or {},
                "is_db_configured": bool(active.get("is_db_configured", False)),
                "updated_at": _serialize(active.get("updated_at")),
            },
            "items": [
                {
                    **item,
                    "updated_at": _serialize(item.get("updated_at")),
                    "created_at": _serialize(item.get("created_at")),
                }
                for item in items
            ],
            "notes": "Backtest pricing is DB-driven. Edit active set or activate another set safely.",
        }
    )


@router.put("/backtests/pricing-config")
async def update_backtest_pricing_config(
    payload: BacktestPricingRuleSetUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    body = payload.model_dump(exclude_unset=True)
    if not body:
        raise HTTPException(status_code=400, detail="No pricing fields provided")

    if body.get("plan_discounts") is not None:
        normalized_plan_discounts: dict[str, float] = {}
        for key, value in dict(body["plan_discounts"]).items():
            try:
                pct = float(value)
            except Exception:
                continue
            if pct < 0:
                pct = 0.0
            if pct > 0.95:
                pct = 0.95
            normalized_plan_discounts[str(key).upper()] = pct
        body["plan_discounts"] = normalized_plan_discounts

    if body.get("strategy_complexity_step") is not None:
        body["strategy_complexity_step"] = float(body["strategy_complexity_step"])
    if body.get("strategy_complexity_cap") is not None:
        body["strategy_complexity_cap"] = float(body["strategy_complexity_cap"])

    actor_id = str(current_user.get("user_id")) if current_user and current_user.get("user_id") else None
    await BacktestPricingService.update_or_create_active_rule_set(
        db,
        body,
        actor_user_id=actor_id,
    )
    await db.commit()

    active = await BacktestPricingService.get_active_pricing_config(db)
    return success_response(
        {
            "id": active.get("id"),
            "name": active.get("name"),
            "version": active.get("version"),
            "base_cost": float(active.get("base_cost", 0)),
            "range_days_step": int(active.get("range_days_step", 1)),
            "min_credit_charge": int(active.get("min_credit_charge", 1)),
            "max_credit_charge": active.get("max_credit_charge"),
            "date_range_buckets": active.get("date_range_buckets") or [],
            "timeframe_multipliers": active.get("timeframe_multipliers") or [],
            "strategy_complexity_enabled": bool(active.get("strategy_complexity_enabled", False)),
            "strategy_complexity_step": float(active.get("strategy_complexity_step", 0) or 0),
            "strategy_complexity_cap": float(active.get("strategy_complexity_cap", 0) or 0),
            "plan_discounts": active.get("plan_discounts") or {},
        },
        "Backtest pricing config updated",
    )


@router.post("/backtests/pricing-config/activate")
async def activate_backtest_pricing_rule_set(
    payload: BacktestPricingRuleSetActivateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    target = await BacktestPricingService.activate_rule_set(db, payload.rule_set_id)
    if not target:
        raise HTTPException(status_code=404, detail="Pricing rule set not found")
    await db.commit()

    active = await BacktestPricingService.get_active_pricing_config(db)
    return success_response(
        {
            "id": active.get("id"),
            "name": active.get("name"),
            "version": active.get("version"),
            "is_active": bool(active.get("is_active", True)),
        },
        "Pricing rule set activated",
    )


@router.get("/market-data/supported")
async def get_admin_market_data_supported(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    instruments = (await db.execute(select(Instrument).order_by(Instrument.symbol.asc()))).scalars().all()
    timeframes = (
        await db.execute(select(MarketData.timeframe).distinct().order_by(MarketData.timeframe.asc()))
    ).scalars().all()

    return success_response(
        {
            "instruments": [
                {
                    "id": instrument.id,
                    "symbol": instrument.symbol,
                    "exchange": instrument.exchange,
                    "market": instrument.market,
                    "instrument_type": instrument.instrument_type,
                }
                for instrument in instruments
            ],
            "timeframes": [tf for tf in timeframes if tf],
        }
    )


@router.get("/market-data/coverage")
async def get_admin_market_data_coverage(
    instrument_id: Optional[int] = None,
    timeframe: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    stmt = (
        select(
            MarketData.instrument_id,
            Instrument.symbol.label("instrument_symbol"),
            MarketData.timeframe,
            func.min(MarketData.timestamp).label("min_timestamp"),
            func.max(MarketData.timestamp).label("max_timestamp"),
            func.count().label("candle_count"),
        )
        .join(Instrument, Instrument.id == MarketData.instrument_id)
        .group_by(MarketData.instrument_id, Instrument.symbol, MarketData.timeframe)
        .order_by(Instrument.symbol.asc(), MarketData.timeframe.asc())
    )

    if instrument_id is not None:
        stmt = stmt.where(MarketData.instrument_id == instrument_id)
    if timeframe:
        stmt = stmt.where(MarketData.timeframe == timeframe)

    rows = (await db.execute(stmt)).all()
    coverage = [
        {
            "instrument_id": row.instrument_id,
            "instrument_symbol": row.instrument_symbol,
            "timeframe": row.timeframe,
            "min_timestamp": row.min_timestamp.isoformat() if row.min_timestamp else None,
            "max_timestamp": row.max_timestamp.isoformat() if row.max_timestamp else None,
            "candle_count": int(row.candle_count or 0),
        }
        for row in rows
    ]

    return success_response({"items": coverage, "total": len(coverage)})


@router.get("/market-data/freshness")
async def get_admin_market_data_freshness(
    stale_after_hours: int = Query(24, ge=1, le=720),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    coverage_resp = await get_admin_market_data_coverage(db=db, current_user=current_user)
    items = coverage_resp["data"]["items"] if coverage_resp.get("success") else []

    now = datetime.utcnow()
    stale_threshold = now - timedelta(hours=stale_after_hours)
    stale_items = []
    fresh_items = []

    for item in items:
        max_ts_str = item.get("max_timestamp")
        max_ts = datetime.fromisoformat(max_ts_str) if max_ts_str else None
        freshness = {
            **item,
            "is_stale": True,
            "age_hours": None,
        }
        if max_ts:
            age_hours = max((now - max_ts.replace(tzinfo=None)).total_seconds() / 3600.0, 0.0)
            freshness["age_hours"] = round(age_hours, 2)
            freshness["is_stale"] = max_ts < stale_threshold

        if freshness["is_stale"]:
            stale_items.append(freshness)
        else:
            fresh_items.append(freshness)

    return success_response(
        {
            "summary": {
                "total_pairs": len(items),
                "stale_pairs": len(stale_items),
                "fresh_pairs": len(fresh_items),
                "stale_after_hours": stale_after_hours,
            },
            "stale": stale_items,
            "fresh": fresh_items,
        }
    )


@router.post("/market-data/refresh")
async def trigger_market_data_refresh(
    payload: MarketDataHookRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    job_id = str(uuid4())
    db.add(
        JobStatus(
            id=job_id,
            user_id=as_uuid_or_str(current_user["user_id"]),
            job_type="market_data_refresh",
            status="pending",
            progress=0,
            message="Refresh hook accepted",
            job_data=json.dumps(payload.model_dump(mode="json")),
            created_at=datetime.utcnow(),
        )
    )
    await db.commit()

    return success_response(
        {
            "job_id": job_id,
            "status": "pending",
            "hook": "market_data_refresh",
            "payload": payload.model_dump(mode="json"),
            "message": "Refresh hook accepted. Implement worker binding to process this job.",
        }
    )


@router.post("/market-data/upload")
async def trigger_market_data_upload(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_admin_user),
):
    job_id = str(uuid4())
    db.add(
        JobStatus(
            id=job_id,
            user_id=as_uuid_or_str(current_user["user_id"]),
            job_type="market_data_upload",
            status="pending",
            progress=0,
            message="Upload hook accepted",
            job_data=json.dumps(payload),
            created_at=datetime.utcnow(),
        )
    )
    await db.commit()

    return success_response(
        {
            "job_id": job_id,
            "status": "pending",
            "hook": "market_data_upload",
            "message": "Upload hook accepted. Implement parser/ingestion worker to process this job.",
        }
    )


@router.get('/support-tickets-legacy')
async def get_admin_support_tickets(skip: int = 0, limit: int = Query(20, ge=1, le=100), status: Optional[str] = None, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    stmt = select(SupportTicket, User.email, User.fullname).join(User, User.id == SupportTicket.user_id).order_by(SupportTicket.created_at.desc()).offset(skip).limit(limit)
    count_stmt = select(func.count()).select_from(SupportTicket)
    if status:
        stmt = stmt.where(SupportTicket.status == status)
        count_stmt = count_stmt.where(SupportTicket.status == status)
    rows = (await db.execute(stmt)).all()
    total = (await db.execute(count_stmt)).scalar() or 0
    items = [{
        'id': str(ticket.id), 'user_id': str(ticket.user_id), 'user_email': email, 'user_name': fullname or email, 'subject': ticket.subject,
        'message': ticket.message, 'status': ticket.status, 'priority': ticket.priority, 'created_at': _serialize(ticket.created_at), 'updated_at': _serialize(ticket.updated_at)
    } for ticket, email, fullname in rows]
    return success_response({'items': items, 'total': total, 'skip': skip, 'limit': limit}, 'No data found' if not items else None)


@router.patch('/support-tickets-legacy/{ticket_id}')
async def update_admin_support_ticket(ticket_id: str, payload: TicketStatusUpdateRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    ticket = (await db.execute(select(SupportTicket).where(cast(SupportTicket.id, String) == str(ticket_id)))).scalar_one_or_none()
    if not ticket:
        raise HTTPException(status_code=404, detail='Ticket not found')
    ticket.status = payload.status
    await db.commit()
    return success_response({}, 'Ticket updated successfully')


@router.post('/support-tickets-legacy/{ticket_id}/reply')
async def reply_admin_support_ticket(ticket_id: str, payload: TicketReplyRequest, db: AsyncSession = Depends(get_db), current_user: dict = Depends(get_admin_user)):
    ticket = (await db.execute(select(SupportTicket).where(cast(SupportTicket.id, String) == str(ticket_id)))).scalar_one_or_none()
    if not ticket:
        raise HTTPException(status_code=404, detail='Ticket not found')
    reply = SupportTicketReply(ticket_id=as_uuid_or_str(ticket_id), user_id=as_uuid_or_str(current_user['user_id']), message=payload.message)
    db.add(reply)
    ticket.status = 'in_progress'
    await db.commit()
    return success_response({'id': str(reply.id)}, 'Reply sent successfully')


class BacktestEngineUpdateRequest(BaseModel):
    source_code: str


@router.get("/backtest-engine/source")
async def get_admin_backtest_engine_source(
    current_user: dict = Depends(get_admin_user),
):
    engine_path = _project_root() / "engine" / "backtest_engine.py"
    metrics_path = _project_root() / "engine" / "metrics.py"
    trade_stats_path = _project_root() / "engine" / "trade_stats.py"
    return success_response({
        "engine_path": str(engine_path.relative_to(_project_root())),
        "source_code": _read_text_file(engine_path),
        "supporting_files": [
            {"path": str(metrics_path.relative_to(_project_root())), "content": _read_text_file(metrics_path)},
            {"path": str(trade_stats_path.relative_to(_project_root())), "content": _read_text_file(trade_stats_path)},
        ],
    })


@router.put("/backtest-engine/source")
async def update_admin_backtest_engine_source(
    payload: BacktestEngineUpdateRequest,
    current_user: dict = Depends(get_admin_user),
):
    engine_path = _project_root() / "engine" / "backtest_engine.py"
    if not payload.source_code.strip():
        raise HTTPException(status_code=400, detail="Source code cannot be empty")
    try:
        compile(payload.source_code, str(engine_path), "exec")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Engine syntax error: {exc}")
    _write_text_file(engine_path, payload.source_code)
    return success_response({"engine_path": str(engine_path.relative_to(_project_root()))}, "Backtest engine updated successfully")
